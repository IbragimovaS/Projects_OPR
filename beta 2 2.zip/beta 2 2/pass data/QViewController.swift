//
//  QViewController.swift
//  pass data
//
//  Created by John Doe on 10/20/19.
//  Copyright © 2019 Parth Changela. All rights reserved.
//

import UIKit
import MobileCoreServices
class QViewController: UIViewController {
var finalName = ""
var StatusCodeRes = Int()
var imageArray2 = [UIImage]()
var image2 = UIImage()
//var keys2 = [Any]()
var arrayj2 = [Any]()
var arrayS2 = [Double]()
let asd = DispatchQueue(label: "asd")
let zxc = DispatchQueue(label: "zxc")
    
    @IBOutlet var scrImg: UIScrollView!
        override func viewDidLoad() {
        super.viewDidLoad()
    var Fio = [String]()
    var IIN = [Double]()
    var nomudv = [Double]()
    var ver = [Double]()
    print("ARRAYJ2 = ",arrayj2)
    print("arrayS2 = ",arrayS2)
            for i in 0..<arrayS2.count{
                for j in 0..<arrayj2.count{
                    let xxx = arrayj2[j] as! Array<Any>
                    if arrayS2[i] == xxx[0] as! Double{
                        Fio.append(xxx[3] as! String)
                        IIN.append(xxx[1] as! Double)
                        nomudv.append(xxx[2] as! Double)
                        ver.append(xxx[0] as! Double)
                        
                    }
                }
            }
            
            
    let session = URLSession(configuration: URLSessionConfiguration.default)
        asd.sync {
        for i in 0..<Fio.count{
            guard let url = URL(string: "http://10.180.13.63:9002 z/get_photo_images?data="+(Fio[i])) else { return }//http://10.150.30.142:9000/get_photo_align?data=1
            usleep(200000)
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        session.dataTask(with: request) { (data, response, error) in
            
            if let response = response {
                print(response)
                if let http = response as? HTTPURLResponse{
                    print("123123123123 = ",http.statusCode)
                    self.StatusCodeRes = http.statusCode
                }
            }
            
            if let data = data {
                //self.imageArray2.append(UIImage(data: data)!)
                if self.StatusCodeRes == 200{
                    DispatchQueue.main.async {
                 
                let xPosition = self.view.frame.width * CGFloat(i)
                let screenSize: CGRect = UIScreen.main.bounds
                let scrn:Int = Int(screenSize.size.width)
                let frame1 = CGRect(x: scrn*i+10, y: 20, width: scrn-20, height: 480)
                let button = UIButton(frame: frame1)
                
                //button.setTitle( String(i), for: .normal)
                    let color1 = self.hexStringToUIColor(hex: "731D0A")
                    let color2 = self.hexStringToUIColor(hex: "D9CDBF")
                button.backgroundColor = color1
                self.scrImg.addSubview(button)
                
                let label = UILabel()
                label.frame = CGRect(x: scrn*i+10 , y:500, width: scrn-20, height: 200)
                    label.lineBreakMode = .byWordWrapping
                    label.numberOfLines = 4
                    label.textAlignment = .left
                label.text = " ФИО: \(Fio[i])\n ИИН: \(IIN[i]) \n №удостоверения: \(nomudv[i]) \n Вероятность: \(ver[i])"
                label.textColor = color2
                label.layer.borderColor = color1.cgColor
                label.layer.borderWidth = 3.0
                self.scrImg.addSubview(label)
                
                let imageView = UIImageView()
                imageView.image = (UIImage(data: data)!)
                imageView.contentMode = .scaleToFill
                
                imageView.frame = CGRect(x: xPosition+30, y:40, width: self.scrImg.frame.width-60, height: self.scrImg.frame.height-400)
                 
                self.scrImg.contentSize.width = self.scrImg.frame.width * CGFloat(i+1)
                self.scrImg.addSubview(imageView)
                    
               
                    
                    
                    }
                 }
                else{
                    DispatchQueue.main.async {
                                   
              let xPosition = self.view.frame.width * CGFloat(i)
              let screenSize: CGRect = UIScreen.main.bounds
              let scrn:Int = Int(screenSize.size.width)
              let frame1 = CGRect(x: scrn*i+10, y: 20, width: scrn-20, height: 480)
              let button = UIButton(frame: frame1)
              
              //button.setTitle( String(i), for: .normal)
                  let color1 = self.hexStringToUIColor(hex: "731D0A")
                  let color2 = self.hexStringToUIColor(hex: "D9CDBF")
              button.backgroundColor = color1
              self.scrImg.addSubview(button)
              
              let label = UILabel()
              label.frame = CGRect(x: scrn*i+10 , y:500, width: scrn-20, height: 200)
                  label.lineBreakMode = .byWordWrapping
                  label.numberOfLines = 4
                  label.textAlignment = .left
              label.text = " ФИО: \(Fio[i])\n ИИН: \(IIN[i]) \n №удостоверения: \(nomudv[i]) \n Вероятность: \(ver[i])"
              label.textColor = color2
              label.layer.borderColor = color1.cgColor
              label.layer.borderWidth = 3.0
              self.scrImg.addSubview(label)
              
              let imageView = UIImageView()
              imageView.image = nil
              imageView.contentMode = .scaleToFill
              
              imageView.frame = CGRect(x: xPosition+30, y:40, width: self.scrImg.frame.width-60, height: self.scrImg.frame.height-400)
               
              self.scrImg.contentSize.width = self.scrImg.frame.width * CGFloat(i+1)
              self.scrImg.addSubview(imageView)
                  
                
                        }
               
                    }
            
                }
            }.resume()
            }
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    }
