//
//  ViewController.swift
//  pass data
//
//  Created by Parth Changela on 01/01/17.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit
import MobileCoreServices

typealias Parameters = [String: String]
class ViewController: UIViewController {
    
    
    @IBOutlet weak var viewcntr: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewcntr.image = #imageLiteral(resourceName: "FR-logo")
        
        print("strart")
       
    }
    
    
    
    
    @IBAction func btnPassData(_ sender: Any) {

        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "Источник фото", message: "выберите источник", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Камера", style: .default, handler: {(ACTION:UIAlertAction)  in
            imagePickerController.allowsEditing = true
            imagePickerController.sourceType = .camera
            self.present(imagePickerController, animated: true, completion: nil)
            
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Фото галерея", style: .default, handler: {(ACTION:UIAlertAction)  in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Отмена", style: .default, handler: nil  ))
        self.present(actionSheet, animated: true, completion: nil)
       
        
    }

    
    @IBAction func StreamBtn(_ sender: Any) {
          DispatchQueue.main.async {
          let MainStory:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
          let desVC = MainStory.instantiateViewController(withIdentifier: "SViewController") as! SViewController
         // self.label1.text = "test 2"
          self.navigationController?.pushViewController(desVC, animated: true)
      }
        
        
    }
    func submit(image: UIImage) {

        guard let mediaImage = Media(withImage: image, forKey: "file") else { return }   
        guard let url = URL(string: "http://10.180.13.63:9002/get_photo_align_large_files/") else { return }
        // http://10.150.30.142:9000/get_photo_align_large_files
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let boundary = generateBoundary()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        let dataBody = createDataBody(withParameters: nil, media: [mediaImage], boundary: boundary)
        request.httpBody = dataBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
                print("*****************************")
            }
            
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options:JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    print(json)
                    if let ww = json["res"] as? [String:Any]{
                        print(ww)
                    }
                    if let dd = json["res"] as? NSArray{
                        var x: Int = 0
                        for qwe in (dd as NSArray)
                        {   x=x+1
                            print("qwe = ",qwe)
                            }
                        print(x)
                        DispatchQueue.main.async {
                            let MainStory:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let desVC = MainStory.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
                           // self.label1.text = "test 2"
                            desVC.xx = x
                            self.navigationController?.pushViewController(desVC, animated: true)
                        }
                    }
                    
                }catch{
                    print(error)
                }
            }
            }.resume()
    }
    
    func generateBoundary() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func createDataBody(withParameters params: Parameters?, media: [Media]?, boundary: String) -> Data {
        
        let lineBreak = "\r\n"
        var body = Data()
        
        if let media = media {
            for photo in media {
                body.append("--\(boundary + lineBreak)")
                body.append("Content-Disposition: form-data; name=\"\(photo.key)\"; filename=\"\(photo.filename)\"\(lineBreak)")
                body.append("Content-Type: \(photo.mimeType + lineBreak + lineBreak)")
                body.append(photo.data)
                body.append(lineBreak)
            }
        }
        
        body.append("--\(boundary)--\(lineBreak)")
        
        return body
    }
    
}
extension Data {
    mutating func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(){
        
    }
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {

        
        let image = info[.originalImage] as! UIImage
        submit(image: image)
        
        picker.dismiss(animated: true)

    }
}
