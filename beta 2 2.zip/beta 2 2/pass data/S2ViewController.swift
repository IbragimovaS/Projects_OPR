//
//  S2ViewController.swift
//  pass data
//
//  Created by Sholpan Ibragimova on 11/23/19.
//  Copyright © 2019 Parth Changela. All rights reserved.
//

import UIKit
import AVFoundation

class S2ViewController: UIViewController {

    
    @IBOutlet weak var scrollviewS2: UIScrollView!
    
    var player: AVAudioPlayer?
    var NameS2 = String()
    var arrayQWE2 = [Any?]()
    var imagearr1 = [UIImage]()
    var imagearr2 = [UIImage]()
  //  let serialPriorityQueue = DispatchQueue(label:"com.bestkora.serialPrority")
   // let qwerty = DispatchQueue(label: "asdasdasdasd")
    let radQueue = OperationQueue()
    override func viewDidLoad() {
        super.viewDidLoad()
       // playSound()
           

        //let op1 = BlockOperation{}
        //serialPriorityQueue.sync{
           // self.imagearr1 = []
           // self.imagearr2 = []
                for i in 0..<self.arrayQWE2.count{
                   // serialPriorityQueue.async{
                    let zx = self.arrayQWE2[i] as! Dictionary<String, Any>
                if let ff = zx["fio"] {
                    print("FF",ff)
                 let session = URLSession(configuration: URLSessionConfiguration.default)
                   guard let url = URL(string:"http://10.180.13.63:9002/get_photo_red/?data="+(ff as! String)) else { return }
                   var request = URLRequest(url: url)
                   request.httpMethod = "GET"
                   session.dataTask(with: request) { (data, response, error) in
                       
                       if let response = response {
                           print(response)
                       }
                       
                       if let data = data {
                        DispatchQueue.main.async {
                    
                        let imageView2 = UIImageView()
                        imageView2.image = UIImage(data: data)!
                        let xPosition = self.view.frame.width * CGFloat(i)+10
                        imageView2.contentMode = .scaleToFill
                        imageView2.frame = CGRect(x: xPosition, y:500, width:170, height:200)
                         
                        self.scrollviewS2.contentSize.width = self.scrollviewS2.frame.width * CGFloat(i+1)
                        self.scrollviewS2.addSubview(imageView2)
                        
                       
                        let frame1 = CGRect(x: Int(xPosition+170), y: 500, width: 185, height: 200)
                        let button = UIButton(frame: frame1)
                        
                        let zx = self.arrayQWE2[i] as! Dictionary<String, Any>
                        let fio = zx["fio"] as! String
                        let id = zx["id"]
                        let info = zx["info"] as! String
                        let red_id = zx["red_id"] as! Int
                        let score = zx["score"] as! Double
                        button.titleLabel?.lineBreakMode = .byWordWrapping
                        button.setTitle("fio = \(fio) id = \(id as! Int)\nifno = \(info)\nred_id = \(red_id)\nscore = \(score)" , for: .normal)
                           //button.backgroundColor = UIColor.black
                        let color2 = self.hexStringToUIColor(hex: "D9CDBF")
                        let color1 = self.hexStringToUIColor(hex: "731D0A")
                        button.setTitleColor(color2, for: .normal)
                        button.layer.borderColor = color1.cgColor
                        button.layer.borderWidth = 3.0
                            
                         self.scrollviewS2.addSubview(button)
                        
                        }
                           
                           print("DATA1 = ", data)
                       }
                       }.resume()
                    
                    }
                    
                    if let cc = zx["id"]{
                     let session = URLSession(configuration: URLSessionConfiguration.default)
                     guard let url = URL(string:"http://10.180.13.63:9002/get_photo_redbase/?data="+"\(cc)") else { return }//
                     var request = URLRequest(url: url)
                     request.httpMethod = "GET"
                     session.dataTask(with: request) { (data, response, error) in
                         
                         if let response = response {
                             print(response)
                         }
                        
                            
                        
                        if let data = data {
                            // self.imagearr1.append(UIImage(data: data)!)
                            DispatchQueue.main.async {
                               
                            let xPosition = self.view.frame.width * CGFloat(i)
                            let screenSize: CGRect = UIScreen.main.bounds
                            let scrn:Int = Int(screenSize.size.width)
                                let frame1 = CGRect(x: Int(xPosition+10), y: 20, width: scrn-20, height: 460)
                            let button = UIButton(frame: frame1)
                            
                            //button.setTitle( String(i), for: .normal)
                                let color1 = self.hexStringToUIColor(hex: "731D0A")
                                
                            button.backgroundColor = color1
                            self.scrollviewS2.addSubview(button)
                            
                             print("DATA1 = ", data)
                           let imageView = UIImageView()
                            imageView.image = (UIImage(data: data)!)
                            imageView.contentMode = .scaleToFill
                            imageView.frame = CGRect(x: xPosition+30, y:40, width:self.scrollviewS2.frame.width-60, height:self.scrollviewS2.frame.height-440)
                             
                            self.scrollviewS2.contentSize.width = self.scrollviewS2.frame.width * CGFloat(i+1)
                            self.scrollviewS2.addSubview(imageView)
                             
                            }
                            }
                         }.resume()
                        
                        
                    }
                    usleep(100000)
                }
        
        guard let url = Bundle.main.url(forResource: "Sound_17196", withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)

            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)

            /* iOS 10 and earlier require the following line:
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */

            guard let player = player else { return }

            player.play()
         usleep(1000000)
            player.stop()
        } catch let error {
            print(error.localizedDescription)
        }
           // }
        
      //  let op2 = BlockOperation{
       // if self.imagearr1.count == self.arrayQWE2.count && self.imagearr2.count == self.arrayQWE2.count {
        //        self.serialPriorityQueue.sync {
        //        print("SCROLL ",self.imagearr2.count)
        //         print("SCROLL2 ",self.imagearr1.count)
        //            scrollS2()
        //        }
    //  }
        
       // DispatchQueue.main.asyncAfter(deadline: .now()+1){
       // print("SCROLL ",self.imagearr2.count)
         //  print("SCROLL2 ",self.imagearr1.count)
          // self.scrollS2()
        //  }
            
           // op2.addDependency(op1)
           // radQ.addOperation(op1)
          //  radQ.addOperation(op2)
   
        
    }

    func scrollS2(){
        for i in 0..<arrayQWE2.count
          {
           
           let imageView = UIImageView()
          imageView.image = self.imagearr1[i]
          imageView.contentMode = .scaleToFill
          let xPosition = self.view.frame.width * CGFloat(i)+10
          imageView.frame = CGRect(x: xPosition, y:0, width:self.scrollviewS2.frame.width-20, height:self.scrollviewS2.frame.height-400)
           
          self.scrollviewS2.contentSize.width = self.scrollviewS2.frame.width * CGFloat(i+1)
          self.scrollviewS2.addSubview(imageView)
           
            let imageView2 = UIImageView()
            imageView2.image = self.imagearr2[i]
            imageView2.contentMode = .scaleToFill
            imageView2.frame = CGRect(x: xPosition, y:self.scrollviewS2.frame.height-400, width:200, height:200)
             
            self.scrollviewS2.contentSize.width = self.scrollviewS2.frame.width * CGFloat(i+1)
            self.scrollviewS2.addSubview(imageView2)
            
            //let screenSize: CGRect = UIScreen.main.bounds
            //let scrn:Int = Int(screenSize.size.width)
            
            let frame1 = CGRect(x: Int(xPosition+200), y: Int(self.scrollviewS2.frame.height-400), width: 180, height: 200)
             let button = UIButton(frame: frame1)
            
            let zx = self.arrayQWE2[i] as! Dictionary<String, Any>
            let fio = zx["fio"] as! String
            let id = zx["id"]
            let info = zx["info"] as! String
            let red_id = zx["red_id"] as! Int
            let score = zx["score"] as! Double
             button.titleLabel?.lineBreakMode = .byWordWrapping
            button.setTitle("fio = \(fio)\nid = \(id as! Int)\nifno = \(info)\nred_id = \(red_id)\nscore = \(score)" , for: .normal)
               //button.backgroundColor = UIColor.black
             button.setTitleColor(UIColor.black, for: .normal)
             self.scrollviewS2.addSubview(button)
            
          
        }
        
    }
     func playSound() {
           guard let url = Bundle.main.url(forResource: "Sound_17196", withExtension: "mp3") else { return }

           do {
               try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
               try AVAudioSession.sharedInstance().setActive(true)

               /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
               player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)

               /* iOS 10 and earlier require the following line:
               player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */

               guard let player = player else { return }

               player.play()
            usleep(1000000)
               player.stop()
           } catch let error {
               print(error.localizedDescription)
           }
       }
    
     func hexStringToUIColor (hex:String) -> UIColor {
           var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

           if (cString.hasPrefix("#")) {
               cString.remove(at: cString.startIndex)
           }

           if ((cString.count) != 6) {
               return UIColor.gray
           }

           var rgbValue:UInt64 = 0
           Scanner(string: cString).scanHexInt64(&rgbValue)

           return UIColor(
               red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
               green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
               blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
               alpha: CGFloat(1.0)
           )
       }
}
