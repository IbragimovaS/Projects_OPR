//
//  SViewController.swift
//  pass data
//
//  Created by Sholpan Ibragimova on 11/22/19.
//  Copyright © 2019 Parth Changela. All rights reserved.
//

import UIKit
import AVFoundation

protocol FrameExtractorDelegate: class {
    func captured(image: UIImage)
}
class SViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
   
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var cameraPreview: UIView!
   
    
    //@IBOutlet weak var imageView: UIImageView!
    
    var arrayQWE = [Any]()
    var arrayFio = [String]()
    var Name = String()
    var videoDataOutput: AVCaptureVideoDataOutput!
    var videoDataOutputQueue: DispatchQueue!
    var previewLayer:AVCaptureVideoPreviewLayer!
    var captureDevice : AVCaptureDevice!
    let session = AVCaptureSession()
    let context = CIContext()
    
    weak var delegate: FrameExtractorDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       // imageView.transform = imageView.transform.rotated(by: CGFloat(M_PI_2));
        view.addSubview(cameraPreview)
        //imageView.image = cameraPreview
        self.setUpAVCapture()
        
     
    }
    
   
    
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                  let vc = segue.destination as!  S2ViewController
                  //vc.keys2 = keys1
               vc.NameS2 = Name
               vc.arrayQWE2 = arrayQWE
              }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopCamera()
    }

    // To add the layer of your preview
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.previewLayer.frame = self.cameraPreview.layer.bounds
    }
    
    // To set the camera and its position to capture
    func setUpAVCapture() {
        session.sessionPreset = AVCaptureSession.Preset.iFrame960x540//hd1920x1080 //vga640x480
        guard let device = AVCaptureDevice
            .default(AVCaptureDevice.DeviceType.builtInWideAngleCamera,
                     for: .video,
                     position: AVCaptureDevice.Position.back) else {
                        return
        }
        captureDevice = device
        beginSession()
    }
    
    // Function to setup the beginning of the capture session
    func beginSession(){
        var deviceInput: AVCaptureDeviceInput!
        
        do {
            deviceInput = try AVCaptureDeviceInput(device: captureDevice)
            guard deviceInput != nil else {
                print("error: cant get deviceInput")
                return
            }
            
            if self.session.canAddInput(deviceInput){
                self.session.addInput(deviceInput)
            }
            
            videoDataOutput = AVCaptureVideoDataOutput()
            videoDataOutput.alwaysDiscardsLateVideoFrames=true
            videoDataOutputQueue = DispatchQueue(label: "VideoDataOutputQueue")
            videoDataOutput.setSampleBufferDelegate(self, queue:self.videoDataOutputQueue)
            
            if session.canAddOutput(self.videoDataOutput){
                session.addOutput(self.videoDataOutput)
            }
            
            videoDataOutput.connection(with: .video)?.isEnabled = true
            
            previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
            previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
            
            let rootLayer :CALayer = self.cameraPreview.layer
            rootLayer.masksToBounds = true
            
            rootLayer.addSublayer(self.previewLayer)
            session.startRunning()
        } catch let error as NSError {
            deviceInput = nil
            print("error: \(error.localizedDescription)")
        }
    }
    
    // Function to capture the frames again and again
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // do stuff here
        print("Got a frame")
        
        guard let uiImage = imageFromSampleBuffer(sampleBuffer: sampleBuffer) else { return };
        
            DispatchQueue.main.async { [unowned self] in
            guard self.imageFromSampleBuffer(sampleBuffer: sampleBuffer) != nil else { return }
                self.delegate?.captured(image: uiImage)
                //self.imageView.image = uiImage
                //self.submit(image: uiImage)
                let rotateImage = uiImage.rotate(radians: .pi/2)
                //self.imageView.image = rotateImage
                self.arrayQWE = []
                self.submit(image: rotateImage)
        }
        usleep(1000000)
        
    }
    
    // Function to process the buffer and return UIImage to be used
    func imageFromSampleBuffer(sampleBuffer : CMSampleBuffer) -> UIImage? {
        guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return nil }
        
        let ciImage = CIImage(cvPixelBuffer: imageBuffer)
        
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return nil }
        
        return UIImage(cgImage: cgImage)
        
    }
    
    // To stop the session
    func stopCamera(){
        session.stopRunning()
    }
        @IBAction func StreamBtn(_ sender: Any) {
              DispatchQueue.main.async {
              let MainStory:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
              let desVC = MainStory.instantiateViewController(withIdentifier: "SViewController") as! SViewController
             // self.label1.text = "test 2"
              self.navigationController?.pushViewController(desVC, animated: true)
          }
            
            
        }
        
        func submit(image: UIImage) {

            guard let mediaImage = Media(withImage: image, forKey: "file") else { return }
            guard let url = URL(string: "http://10.180.13.63:9002/get_red_people/") else { return }
            // http://10.150.30.142:9000/get_photo_align_large_files
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            let boundary = generateBoundary()
            
            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            let dataBody = createDataBody(withParameters: nil, media: [mediaImage], boundary: boundary)
            request.httpBody = dataBody
            
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                if let response = response {
                    print(response)
                    print("*****************************")
                }
                
                if let data = data {
                    do {
                        let json = try JSONSerialization.jsonObject(with: data, options:JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        print(json)
                        if let dd = json["person"] as? NSArray{
                            for qwe in (dd as Array)
                            {   self.arrayQWE.append(qwe)
                            if let ssss = qwe["fio"]{
                    
                                self.Name = ssss as! String
                                print("www = ",self.Name )
                                DispatchQueue.main.async {
                                    self.performSegue(withIdentifier:"name1", sender: self)
                                    
                                }
                            }
                            
                            }}
                    }catch{
                        print(error)
                    }
                }
                }.resume()
        }
       
    
    
        func generateBoundary() -> String {
            return "Boundary-\(NSUUID().uuidString)"
        }
        
        func createDataBody(withParameters params: Parameters?, media: [Media]?, boundary: String) -> Data {
            
            let lineBreak = "\r\n"
            var body = Data()
            
            if let media = media {
                for photo in media {
                    body.append("--\(boundary + lineBreak)")
                    body.append("Content-Disposition: form-data; name=\"\(photo.key)\"; filename=\"\(photo.filename)\"\(lineBreak)")
                    body.append("Content-Type: \(photo.mimeType + lineBreak + lineBreak)")
                    body.append(photo.data)
                    body.append(lineBreak)
                }
            }
            
            body.append("--\(boundary)--\(lineBreak)")
            
            return body
        }
    
    }
extension UIImage {
    func rotate(radians: CGFloat) -> UIImage {
        let rotatedSize = CGRect(origin: .zero, size: size)
            .applying(CGAffineTransform(rotationAngle: CGFloat(radians)))
            .integral.size
        UIGraphicsBeginImageContext(rotatedSize)
        if let context = UIGraphicsGetCurrentContext() {
            let origin = CGPoint(x: rotatedSize.width / 2.0,
                                 y: rotatedSize.height / 2.0)
            context.translateBy(x: origin.x, y: origin.y)
            context.rotate(by: radians)
            draw(in: CGRect(x: -origin.y, y: -origin.x,
                            width: size.width, height: size.height))
            let rotatedImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()

            return rotatedImage ?? self
        }

        return self
    }
}
