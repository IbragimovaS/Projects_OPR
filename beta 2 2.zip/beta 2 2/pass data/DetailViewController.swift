//
//  DetailViewController.swift
//  pass data
//
//  Created by Parth Changela on 01/01/17.
//  Copyright © 2017 Parth Changela. All rights reserved.
//

import UIKit
import Foundation

class DetailViewController: UIViewController {
    
    //var imageArray = [UIImage]()
    
    @IBOutlet var mainScrollView: UIScrollView!
    var getName = String()
    var xx = Int()
    var yy = Int()
    var  textQWE = ""
    var keys1 = [Any]()
    var image12 = [UIImage]()
    var arrayj1 = [Any]()
    var arrayS = [Double]()
    let serialPriorityQueue = DispatchQueue(label: "com.bestkora.serialPrority")
    let qwerty = DispatchQueue(label: "asdasdasdasd")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainScrollView.frame = view.frame
        
        //imageArray = [#imageLiteral(resourceName: "photo-3"),#imageLiteral(resourceName: "photo-2"),#imageLiteral(resourceName: "photo-4"),#imageLiteral(resourceName: "photo-1")]
        print(xx)
       // serialPriorityQueue.sync {
            
            for i in 0..<self.xx{
               let session = URLSession(configuration: URLSessionConfiguration.default)
               guard let url = URL(string: "http://10.180.13.63:9002/get_photo_align?data="+String(i)) else { return }// http://10.150.30.142:9000/get_photo_align?data=1
                usleep(200000)
               var request = URLRequest(url: url)
               request.httpMethod = "GET"
               session.dataTask(with: request) { (data, response, error) in
                   
                   if let response = response {
                       print(response)
                   }
                   
                   if let data = data {
                       //self.imageArray.append(UIImage(data: data)!)
                    DispatchQueue.main.async {
                    let xPosition = self.view.frame.width * CGFloat(i)
                        let screenSize: CGRect = UIScreen.main.bounds
                        let scrn:Int = Int(screenSize.size.width)
                        let frame1 = CGRect(x: scrn*i+10, y: 20 , width: scrn-20, height: 500)
                        let button = UIButton(frame: frame1)
                        
                        //button.setTitle( String(i), for: .normal)
                        let color1 = self.hexStringToUIColor(hex: "731D0A")
                        button.backgroundColor = color1
                        button.tag = i
                        button.addTarget(self, action: #selector(DetailViewController.bbb(_:)), for: .touchUpInside)
                        self.mainScrollView.addSubview(button)
                        
                        let label = UILabel()
                        let color2 = self.hexStringToUIColor(hex: "D9CDBF")
                        label.frame = CGRect(x: xPosition+30, y:460, width: self.mainScrollView.frame.width-60, height: 50)
                        label.text = "Лицо №\(i+1)"
                        label.textAlignment = .center
                        
                        label.textColor = color2
                        self.mainScrollView.addSubview(label)
                        
                        let imageView = UIImageView()
                        imageView.image = (UIImage(data: data)!)
                        imageView.contentMode = .scaleToFill
                        
                        imageView.frame = CGRect(x: xPosition+30, y:40, width: self.mainScrollView.frame.width-60, height: self.mainScrollView.frame.height-440)
                         
                        self.mainScrollView.contentSize.width = self.mainScrollView.frame.width * CGFloat(i+1)
                        self.mainScrollView.addSubview(imageView)
                        
                        
                    }
                    
                   }
                   }.resume()
                 }
            
       // }
       // qwerty.sync {
            doSyncTaskinSerialQueue()
       // }
}
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! QViewController
        //vc.keys2 = keys1
        vc.arrayj2 = arrayj1
        vc.arrayS2 = arrayS
    }
    func doSyncTaskinSerialQueue(){
        print("#######################################")
        if self.xx == 0{
          print("no face")
        let lblnf = UILabel()
            let screenSize: CGRect = UIScreen.main.bounds
            let scrn:Int = Int(screenSize.size.width)
            lblnf.frame = CGRect(x: 0, y: 0, width: scrn, height: 800)
            //lblnf.backgroundColor = .black
            let colorT = hexStringToUIColor(hex: "D9CDBF")
            lblnf.textColor = colorT
            lblnf.textAlignment = .center
            lblnf.text = "Лицо не обнаружено"
            self.view.addSubview(lblnf)
            //, lblnf.topAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 16.0)])
        }
           //for i in 0..<self.imageArray.count
           //{
            
            
        // }
    }
    
    @objc func bbb(_ sender: Any){
         
        print("QAZ = ", (sender as AnyObject).tag as Int )
        let zzz = (sender as AnyObject).tag as Int
        
      let session = URLSession(configuration: URLSessionConfiguration.default)
          
          guard let url = URL(string: "http://10.180.13.63:9002/get_photo_metadata/") else { return }
          var request = URLRequest(url: url)
          let param = ("data="+String(zzz)).data(using: .utf8)
          
          request.httpMethod = "POST"
          request.httpBody = param
          print(param as Any)
          session.dataTask(with: request ) { (data, response, error) in
              if let response = response {
                  print (response)
              }
              
              if let data = data {
                  do {
                      let json = try JSONSerialization.jsonObject(with: data, options:JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                      print("JSON = ",json)
                    self.keys1 = Array(json.allKeys)
                      print(self.keys1)
                    self.arrayj1 = Array(json.allObjects)
                    //print("ARRAYJ1 = ",self.arrayj1)
                      DispatchQueue.main.async {
                          self.performSegue(withIdentifier: "name", sender: self)
                      }
                      
                  }catch {
                      print(error)
                  }
                var arr = [Double]()
                for i in 0..<self.arrayj1.count{
                    let sdf = self.arrayj1[i] as! Array<Any>
                    arr.append(sdf[0] as! Double)
                         }
                self.arrayS = arr.sorted(by:{(v1:Double, v2:Double) -> Bool in return v1 > v2 } )
                print("ArrayS = ",self.arrayS)
            }
              }.resume()
      }
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
}





