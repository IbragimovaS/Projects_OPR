# How-to-Pass-Data-from-View-Controller
How to Pass Data from View Controller (Swift3 &amp; Xcode 8) || how to pass image form view controller
