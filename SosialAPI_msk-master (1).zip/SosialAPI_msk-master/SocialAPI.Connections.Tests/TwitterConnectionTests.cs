﻿using NUnit.Framework;
using SocialAPI.Controllers;
using SocialAPI.DataOperators;
using SocialAPI.Models;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.OK;
using SocialAPI.Models.SocialNetworks.Twitter;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace SocialAPI.Connections.Tests
{
    /// <summary>
    /// Класс для тестирования получения данных из Twitter
    /// </summary>
    public class TwitterConnectionTests
    {
        /// <summary>
        /// Получение текущего пользователя
        /// </summary>
        [Test]
        public void Test1()
        {
            var twitterAccount = MsSQLDataOperator.GetGoodAccountTwitter();

           Assert.IsNotNull(twitterAccount);
        }

        [Test]
        public void Test2()
        {
            var twitterAccount = MsSQLDataOperator.GetGoodAccountTwitter();
            List<UserTwitter> utw = TwitterConnection.getTwitterUsers("KimKardashian,VRSoloviev", ref twitterAccount);
            Assert.IsNotNull(utw);
        }

        /// <summary>
        /// Проверка метода PutTwitter
        /// </summary>
        [Test]
        public void Test3()
        {
            UsersController contr = new UsersController();
            GenericResponse<PutUserResponse> users = null;
            //users = contr.PutTwitter(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), "MLSj6sFxLy1VXhj",10000, false);//friends(Following) = 132, followers = 52
            //users = contr.PutTwitter(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), "VRSoloviev", 10000, false);   //friends(Following) = 433, followers = 1406037
            //users = contr.PutTwitter(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), "StatisticaOpen", 10000, false); //friends(Following) = 53, followers = 992
            users = contr.PutTwitter(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), "nezsssss");         //friends(Following) = 0, followers = 66169
            Assert.IsTrue(users != null, "Должен вернуть не нулевой результат");
            
        }

        /// <summary>
        /// Проверка метода GetTwitter
        /// </summary>
        [Test]
        public void Test4()
        {
            UsersController contr = new UsersController();
            GenericResponse<AbstractUser> users = contr.GetTwitter(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), "nezsssss");

            Assert.IsTrue(users != null, "Должен вернуть не нулевой результат");
        }
    }
}
