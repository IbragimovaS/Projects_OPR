﻿using NUnit.Framework;
using SocialAPI.Controllers;
using SocialAPI.DataOperators;
using SocialAPI.Models;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.OK;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace SocialAPI.Connections.Tests
{
    /// <summary>
    /// Класс для тестирования получения данных из OK
    /// </summary>
    public class OKConnectionTests
    {
        /// <summary>
        /// Получение текущего пользователя
        /// </summary>
        [Test]
        public void Test1()
        {
            var okAccount = MsSQLDataOperator.GetGoodAccountOK();
            Assert.IsNotNull(okAccount);
        }

        /// <summary>
        /// Получение друзей
        /// </summary>
        [Test]
        public void Test2()
        {
            var okAccount = MsSQLDataOperator.GetGoodAccountOK();

            var usersOK = OKConnection.getOKFriends(518269560330, okAccount);
            Assert.IsTrue(usersOK.Count > 0, "Пользователь с идентификатором 518269560330 должен иметь больше одного друга");
        }

        /// <summary>
        /// проверка получения данных по пользователю и запись их в БД
        /// </summary>
        [Test]
        public void Test3()
        {
            //var okAccount = MsSQLDataOperator.GetGoodAccountOK();
            UsersController contr = new UsersController();
            GenericResponse<AbstractUser> users = contr.GetOK(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 518269560330);
            Assert.IsTrue(((UserOK)users.Data).Friends.Count() > 0, "Количество друзей должно быть больше 0");

        }

        /// <summary>
        /// проверка получения данных по пользователю и запись их в БД
        /// </summary>
        [Test]
        public void Test4()
        {
            //var okAccount = MsSQLDataOperator.GetGoodAccountOK();
            UsersController contr = new UsersController();
            GenericResponse<PutUserResponse> users = contr.PutOK(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 577968743837);
            Assert.IsTrue(users.Data != null, "Должен вернуть не нулевой результат");
        }

        /// <summary>
        /// проверка получения данных по пользователю и запись их в БД
        /// </summary>
        [Test]
        public void Test5()
        {
            string responseJson = String.Empty;
            var okAccount = MsSQLDataOperator.GetGoodAccountOK();
            try
            {
                //HttpWebRequest timeLineRequest = (HttpWebRequest)WebRequest.Create("https://ok.ru/profile/518269560330/subscribers");
                HttpWebRequest timeLineRequest = (HttpWebRequest)WebRequest.Create("https://ok.ru/radioutkin/subscribers");
                //
                timeLineRequest.Proxy = HttpWebRequest.GetSystemWebProxy();
                timeLineRequest.Proxy.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
                timeLineRequest.UseDefaultCredentials = true;
                var timelineHeaderFormat = "{0} {1}";
                timeLineRequest.Headers.Add("Authorization", string.Format(timelineHeaderFormat, okAccount.token, okAccount.session_secret_key));
                timeLineRequest.Method = "Get";
                WebResponse myResponse = timeLineRequest.GetResponse();
                using (myResponse)
                {
                    using (var reader = new StreamReader(myResponse.GetResponseStream()))
                    {
                        responseJson = reader.ReadToEnd();
                    }
                }
            }
            catch (WebException ex)
            {
                string exception = ex.ToString();
            }

            Assert.IsTrue(true, "Проверка соединения через HttpWebRequest");
        }

        /// <summary>
        /// Проверка метода GetOK
        /// </summary>
        [Test]
        public void Test6()
        {
            //var okAccount = MsSQLDataOperator.GetGoodAccountOK();
            UsersController contr = new UsersController();
            GenericResponse<AbstractUser> users = contr.GetOK(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 518269560330);

            Assert.IsTrue(users != null, "Должен вернуть не нулевой результат");
        }

        /// <summary>
        /// проверка получения данных по пользователю и запись их в БД
        /// </summary>
        [Test]
        public void Test7()
        {
            //var okAccount = MsSQLDataOperator.GetGoodAccountOK();
            UsersController contr = new UsersController();
            GenericResponse<PutUserResponse> users = contr.PutOK(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 576526486961);
            Assert.IsTrue(users.Data != null, "Должен вернуть не нулевой результат");

        }


    }
}
