﻿using NUnit.Framework;
using SocialAPI.Controllers;
using SocialAPI.DataOperators;
using SocialAPI.Models;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.Facebook;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SocialAPI.Connections.Tests
{
    class FacebookConnectionTest
    {
        /// <summary>
        /// Получение текущего пользователя
        /// </summary>
        [Test]
        public void Test1()
        {
            //var url = "https://www.facebook.com/erchic";
            var url = "https://www.facebook.com/erchic/friends";




            //FacebookConnection facebookConnection = dotnet new classlib FacebookConnection();
            //var sss =  facebookConnection.GetUserWithFriends("https://www.facebook.com/erchic");
            //var getAccountTask = facebookService.GetFriendsFromUserIdAsync(accessToken, "100001621758319"); // 100001621758319 - алеся каленик

            //https://graph.facebook.com/100041586952882/picture?width=500&height=500   // получение аватара
            //https://graph.facebook.com/100001621758319/picture?width=500&height=500
            // 2386351434913051 vovan


            Assert.IsNotNull(1);
        }
       
    }
}
