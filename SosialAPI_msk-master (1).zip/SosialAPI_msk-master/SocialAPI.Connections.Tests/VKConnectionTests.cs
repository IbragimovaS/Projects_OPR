﻿using NUnit.Framework;
using SocialAPI.Controllers;
using SocialAPI.Models;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Connections.Tests
{
    /// <summary>
    /// Класс для тестирования получения данных из ВКонтакте
    /// </summary>
    public class VKConnectionTests
    {
        /// <summary>
        /// Получение текущего пользователя
        /// </summary>
        [Test]
        public void Test1()
        {
            UserVK userGood = VKConnection.getCurrentVKUser("83f12f451a00e3dac347d1b714e7783ed749857c2212992ae5803bfcc85299aea1559ec45e31f0eacfd80");//может упасть если отвалится токен
            Assert.IsNotNull(userGood);

            UserVK userBad = VKConnection.getCurrentVKUser("1111111111112222222222222222222222");
            Assert.IsNull(userBad);
        }

        /// <summary>
        /// Получение списка пользователей
        /// </summary>
        [Test]
        public void Test2()
        {
            string ids = "1";
            for (int i = 2; i < 1000; i++)
            {
                ids = $"{ids},{i}";
            }
            var users = VKConnection.getVKUsers(ids, "83f12f451a00e3dac347d1b714e7783ed749857c2212992ae5803bfcc85299aea1559ec45e31f0eacfd80").ToList();//может упасть если отвалится токен

            ids = "1100";
            for (int i = 1101; i < 2100; i++)
            {
                ids = $"{ids},{i}";
            }
            users.AddRange(VKConnection.getVKUsers(ids, "83f12f451a00e3dac347d1b714e7783ed749857c2212992ae5803bfcc85299aea1559ec45e31f0eacfd80"));//может упасть если отвалится токен

            checkUsersArray(users);
        }

        /// <summary>
        /// Получение списка друзей
        /// </summary>
        [Test]
        public void Test3()
        {
            var friends = VKConnection.getVKFriends("275265253", "e0993783fa0b67deeae729a9b351dd01c459ba15375e27029ff2f5d662a970cb251aca18b76d3a4737324");
            Assert.IsNotNull(friends);
            Assert.IsTrue(friends.Count() > 6000);

            friends.AddRange(VKConnection.getVKFriends("20020126", "e0993783fa0b67deeae729a9b351dd01c459ba15375e27029ff2f5d662a970cb251aca18b76d3a4737324"));//чтобы попался с верфицированной страницей

            checkUsersArray(friends);
        }

        /// <summary>
        /// Получение списка подписчиков
        /// </summary>
        [Test]
        public void Test4()
        {
            var followers = VKConnection.getVKFollowers("332409", "83f12f451a00e3dac347d1b714e7783ed749857c2212992ae5803bfcc85299aea1559ec45e31f0eacfd80");
            Assert.IsNotNull(followers);
            Assert.IsTrue(followers.Count() > 2500);
            checkUsersArray(followers, false);
        }

        /// <summary>
        /// Получение списка подписок
        /// </summary>
        [Test]
        public void Test5()
        {
            var followers = VKConnection.getVKSubscriptions("150914861", "83f12f451a00e3dac347d1b714e7783ed749857c2212992ae5803bfcc85299aea1559ec45e31f0eacfd80");
            Assert.IsNotNull(followers);
            Assert.IsTrue(followers.Count() > 20);
            checkUsersArray(followers.ToList(), false);
        }

        /// <summary>
        /// Массовое получение идентификаторов подписчиков
        /// </summary>
        [Test]
        public void Test6()
        {
            var followers = VKConnection.getFollowersIDs("32707600", "83f12f451a00e3dac347d1b714e7783ed749857c2212992ae5803bfcc85299aea1559ec45e31f0eacfd80");
            Assert.IsNotNull(followers);
            Assert.IsTrue(followers.Count() > 1000000);
        }

        /// <summary>
        /// Получение последнего id на текущий момент
        /// </summary>
        [Test]
        public void Test7()
        {
            //TODO: запрос на получение последнего идентификатора https://vk.com/catalog.php 
            Assert.IsTrue(true);
        }

        /// <summary>
        /// Получение списка пользователей
        /// </summary>
        [Test]
        public void Test8()
        {
            string ids = "vladtherock";
            
            var users = VKConnection.getVKUsers(ids, "e0993783fa0b67deeae729a9b351dd01c459ba15375e27029ff2f5d662a970cb251aca18b76d3a4737324").ToList();//может упасть если отвалится токен
        }

        /// <summary>
        /// Получение списка пользователей
        /// </summary>
        [Test]
        public void PutVK()
        {
            string ids = "vladtherock";
            UsersController controller = new UsersController();
            var resp = controller.PutVK(new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b"), ids);
        }

        /// <summary>
        /// Получение списка пользователей
        /// </summary>
        [Test]
        public void GetVK()
        {
            string ids = "vladtherock";
            UsersController controller = new UsersController();
            var resp = controller.GetVK(new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b"), ids);
        }

        /// <summary>
        /// Проверить массив пользователей
        /// </summary>
        /// <param name="users"></param>
        private static void checkUsersArray(List<UserVK> users, bool needVerified = true)
        {
            Assert.IsNotNull(users);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.bdate)).Count() > 0);
            Assert.IsTrue(users.Where(x => x.Career != null && x.Career.Count() > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => x.City != null && x.City.id > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => x.Country != null && x.Country.id > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.deactivated)).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.domain)).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.first_name)).Count() > 0);
            Assert.IsTrue(users.Where(x => x.followers_count > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => x.is_closed).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.last_name)).Count() > 0);
            Assert.IsTrue(users.Where(x => x.Last_seen != null && x.Last_seen.time > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.maiden_name)).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.nickname)).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.page)).Count() > 0);
            Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.photo_max_orig)).Count() > 0);
            Assert.IsTrue(users.Where(x => x.relation > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => x.Schools != null && x.Schools.Count() > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => x.sex > 0).Count() > 0);
            Assert.IsTrue(users.Where(x => x.Universities != null && x.Universities.Count() > 0).Count() > 0);
            if (needVerified)
                Assert.IsTrue(users.Where(x => x.verified).Count() > 0);

            //military возвращается только при запросе инфомации по одному пользователю - необходимо уточнить насколько целесообразно ее грузить - скорость упадет в 1000 раз

            //не возвращаются почему-то
            //Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.home_phone)).Count() > 0);
            //Assert.IsTrue(users.Where(x => !String.IsNullOrEmpty(x.mobile_phone)).Count() > 0);
        }

    }
}
