﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Botometr.Instagram.Client
{
    /// <summary>
    /// Класс ответа - бот или не бот
    /// </summary>
    public class BotResponse
    {
        /// <summary>
        /// Идентификатор пользователя
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// Признак "Является ботом"
        /// </summary>
        public bool isBot { get; set; }
    }
}
