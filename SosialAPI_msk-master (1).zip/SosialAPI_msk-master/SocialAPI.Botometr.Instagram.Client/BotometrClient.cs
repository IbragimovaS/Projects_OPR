﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;

namespace SocialAPI.Botometr.Instagram.Client
{
   public class BotometrClient
    {
        /// <summary>
        /// Парололь для доступа к функционалу наполнения обучающей выборки
        /// </summary>
        public static string password;

        /// <summary>
        /// Путь к файлу с данными для обучающей выборки
        /// </summary>
        public static string file_patch;

        /// <summary>
        /// Признак бота
        /// </summary>
        public static bool is_bot;

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Добавить данные в обучающий набор - t, проверка ботов - любая клавиша");
                switch (Console.ReadLine())
                {
                    case "t":
                        prepareData();
                        break;
                    default:
                        checkBots();
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }
            Console.WriteLine("Выполнение задачи завершено");
            Console.ReadLine();
        }

        /// <summary>
        /// Подготовить данные
        /// </summary>
        public static void prepareData()
        {
            Console.WriteLine("Введите пароль учителя");
            password = Console.ReadLine();
            Console.WriteLine("Введите путь к папке с идентификаторами");
            string dir_patch = Console.ReadLine();
            Console.WriteLine("Это боты? (1 - да, 2 - нет)");
            is_bot = Console.ReadLine() == "1";
            Console.WriteLine("Начинаю записывать данные");

            foreach (var item in Directory.GetFiles(dir_patch))
            {
                int currentLine = 0;
                var s = File.ReadLines(item).Skip(currentLine).Take(10);
                while (s != null && s.Count() > 0)
                {
                    string ids = string.Join(";", File.ReadLines(item).Skip(currentLine).Take(10));
    
                     string request = $"http://localhost:51399/api/training/insertinstagram?usernames={ids}&is_bot={is_bot}&password={password}"; //todo прописать адрес сервиса
                    //string request = $"http://botometr.analyze24.ru/api/training/insertinstagram?usernames={ids}&is_bot={is_bot}&password={password}";
                    File.AppendAllLines("log.txt", new string[] { request });
                    string resp = GetData(request);

                    if (resp != "{\"data\":200}")
                    {
                        Console.WriteLine(resp);
                        File.AppendAllLines("log.txt", new string[] { resp });
                        Console.WriteLine("Загрузка данных остановлена из-за ошибки - подробности в логе");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("ok");
                    }

                    currentLine = currentLine + 10;
                    s = File.ReadLines(item).Skip(currentLine).Take(10);
                }
            }


        }

        /// <summary>
        /// Проверить ботов
        /// </summary>
        public static void checkBots()
        {
            Console.WriteLine("Введите путь к файлу с идентификаторами");
            file_patch = Console.ReadLine();
            Console.WriteLine("Начинаю обрабатывать данные");
            int currentLine = 0;

            while (File.ReadLines(file_patch).Skip(currentLine).Take(10) != null)
            {
                string ids = string.Join(";", File.ReadLines(file_patch).Skip(currentLine).Take(10));

                string response = GetData($"http://SocialAPI/api/check/getinstagram?ids={ids}");//todo прописать адрес сервиса
                List<BotResponse> data = JsonConvert.DeserializeObject<List<BotResponse>>(response);

                foreach (var item in data)
                {
                    File.AppendAllLines(file_patch, new[] { $"{item.id}\t{item.isBot}" });
                }
                currentLine = currentLine + 10;
            }
        }

        protected static string GetData(string requestString)
        {
            string responseFromServer = string.Empty;
            Console.WriteLine(DateTime.Now + String.Format("Попытка выполнения запроса: {0}", requestString));
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestString);
                request.Proxy = HttpWebRequest.GetSystemWebProxy();
                request.Proxy.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
                request.UseDefaultCredentials = true;
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream dataStream = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream, Encoding.GetEncoding("UTF-8"));
                    responseFromServer = reader.ReadToEnd();
                    reader.Close();
                    dataStream.Close();
                    response.Close();
                }
            }
            catch (WebException e)
            {
                Console.WriteLine(DateTime.Now + String.Format("Ошибка метода AbstractMapper.GetData. Запрос {0}. Ответ {1}. Текст ошибки {2}",
                    requestString, responseFromServer, e.Message));
                Thread.Sleep(5000);//ждем 5 секунд восстановления сервиса
                return GetData(requestString);
            }
            return responseFromServer;
        }
    }
}
