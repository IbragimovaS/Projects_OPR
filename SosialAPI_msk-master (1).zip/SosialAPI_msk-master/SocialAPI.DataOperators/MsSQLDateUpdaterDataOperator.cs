﻿using SocialAPI.Connections;

using SocialAPI.Mappers.MsSQL;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.Facebook;
using SocialAPI.Models.SocialNetworks.OK;
using SocialAPI.Models.SocialNetworks.Twitter;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;

namespace SocialAPI.DataOperators
{
    /// <summary>
    /// Класс для работы с данными, хранящимися в MS SQL
    /// </summary>
    public static partial class MsSQLDataOperator
    {
        /// <summary>
        /// Устанавливаем дату обновления для каждого пользователя из списка
        /// </summary>
        /// <param name="userList"></param>
        /// <param name="updateDate"></param>
        public static void SetUpdateDate(List<AbstractUser> userList, DateTime updateDate)
        {
            if(userList != null)
            foreach (AbstractUser user in userList)
                user.updateDate = updateDate;
        }

        /// <summary>
        /// Получение токена и количества загружаемых пользователй из массива аргументов
        /// </summary>
        /// <param name="args"></param>
        /// <param name="usr_token"></param>
        /// <param name="count"></param>
        public static void ParseArgs(string[] args, ref Guid usr_token, ref int count)
        {
            if (1 <= args.Length)
            {
                bool tokenParsed = Guid.TryParse(args[0], out usr_token);
                if (!tokenParsed)
                    usr_token = Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B");
            }
            if (2 <= args.Length)
                int.TryParse(args[1], out count);
        }

        public static void InitCommon(Guid usr_token, int cnt, Type t, ref List<string> propNameList, ref PropertyInfo[] props, ref int count, ref Guid user_token, ref bool isRuning)
        {
            props = t.GetProperties();
            propNameList = new List<string>();
            propNameList.AddRange(props.Select(e => e.Name).Where(x => !String.Equals(x, "updateDate")).ToList());
            count = cnt;
            user_token = usr_token;
            isRuning = true;
        }
    }
}
