﻿using SocialAPI.Models.MsSQL.AccountManager;
using System;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.Selenium;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Reflection;
using SocialAPI.Models.SocialNetworks.Facebook;
using System.Threading;
using System.Diagnostics;
using SocialAPI.Models.SocialNetworks.Instagram;

namespace SocialAPI.DataOperators
{
    /// <summary>
    /// Класс для работы с данными, хранящимися в MS SQL
    /// </summary>
    public static partial class MsSQLDataOperator
    {
        /// <summary>
        /// Класс статуса использования логина в данный момент
        /// </summary>
        public class InstagramDriverSelenium : IDisposable
        {
            /// <summary>
            /// Привязанный к драйверу селениума аккаунт facebook
            /// </summary>
            public AccountManagerInstagram AccountInst { get; set; }

            /// <summary>
            /// Признак использования драйвера
            /// </summary>
            public bool IsUsing { get; set; }

            /// <summary>
            /// Экземпляр драйвера селениум
            /// </summary>
            public ChromeDriver driver { get; set; }

            /// <summary>
            /// Текущая страница - объект парсинга
            /// </summary>
            public string Url { get; set; }

            /// <summary>
            /// Признак того, что браузер запущен
            /// </summary>
            public bool IsRuning { get; set; }

            // Flag: Has Dispose already been called?
            bool disposed = false;

            // Public implementation of Dispose pattern callable by consumers.
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }

            // Protected implementation of Dispose pattern.
            protected virtual void Dispose(bool disposing)
            {
                if (disposed)
                    return;

                if (disposing)
                {
                    // Free any other managed objects here.
                    //
                }

                // Free any unmanaged objects here.
                driver.Quit();
                disposed = true;
            }

            ~InstagramDriverSelenium()
            {
                Dispose(false);
            }
        }

        public static List<InstagramDriverSelenium> instagramDriverSeleniumList;

        /// <summary>
        /// Заполнение актуальными аккаунтами и создание драйверов селениума
        /// </summary>
        public static void GetSeleniumInstagram()
        {

            instagramDriverSeleniumList = new List<InstagramDriverSelenium>();
            List<AccountManagerInstagram> fbAcs = AccountsInstagramGoodGet();
            CheckInstagramAccounts(fbAcs);
        }

        /// <summary>
        /// Заполнение актуальными аккаунтами и создание драйверов селениума
        /// </summary>
        public static void StopSeleniumInstagram()
        {
            if (instagramDriverSeleniumList != null)
                foreach (var driver in instagramDriverSeleniumList)
                {
                    driver.driver.Quit();
                }
        }


        /// <summary>
        /// Проверяет состояние аккаунтов
        /// </summary>
        /// <param name="fbAcs"></param>
        private static void CheckInstagramAccounts(List<AccountManagerInstagram> instAcs)
        {
            foreach (AccountManagerInstagram acc in instAcs)
            {
                InstagramDriverSelenium driver = new InstagramDriverSelenium() { AccountInst = acc, IsUsing = false, IsRuning = true };
                RunCheckingInstagramAccount(driver);
                instagramDriverSeleniumList.Add(driver);
            }
            while (instagramDriverSeleniumList.Where(x => x.IsRuning).Count() > 0)
            {
                Thread.Sleep(1000);
            }
            foreach (var acc in instagramDriverSeleniumList.Where(x => x.driver == null))
            {
                AccountSetBad(acc.AccountInst);
            }
            instagramDriverSeleniumList.RemoveAll(x => x.driver == null);
        }


        /// <summary>
        /// Актуализация аккунтов facebook 
        /// </summary>
        private static void InstagramSeleniumManagerRefresh()
        {
            List<AccountManagerInstagram> instAcs = AccountsInstagramGoodGet();
            var newAccaout = instagramDriverSeleniumList.Where(item => !instAcs.Any(item2 => item2.user_name == item.AccountInst.user_name)).Select(x => x.AccountInst).ToList();
            CheckInstagramAccounts(newAccaout);
        }


        /// <summary>
        /// Возвращает пользователя для переданной страницы
        /// </summary>
        static UserInstagram getInstagramUser(InstagramDriverSelenium SD, string username, int count)
        {
            UserInstagram userInstagram = InstagramSeleniumManager.GetUser(username, SD.driver, count);

            List<UserInstagram> AllFollowers = new List<UserInstagram>();
            List<UserInstagram> AllFollowings = new List<UserInstagram>();
            

            int currentCount = 0;
            string nextPage = null;
            string status = null;
            string st = null;
            do
            {
                st = null;
                status = null;
                st =  InstagramSeleniumManager.GetFollowers(userInstagram.id, SD.driver, ref currentCount, ref nextPage, ref AllFollowers, ref status, count);
                if (string.Equals(st, "rate limited"))
                {
                   
                    SD.IsUsing = false;

                    SD = GetInstagramDriveSelenium();
                    SD.IsUsing = true;
                    AccountSetUsageTime(SD.AccountInst);
                }
            }
            while (string.Equals(st, "rate limited"));

            userInstagram.Followers = AllFollowers;

            currentCount = 0;
            nextPage = null;
            status = null;
            do
            {
                st = null;
                status = null;
                InstagramSeleniumManager.GetFollowings(userInstagram.id, SD.driver, ref currentCount, ref nextPage, ref AllFollowings, ref status, count);
                if (string.Equals(status, "rate limited"))
                {

                    SD.IsUsing = false;

                    SD = GetInstagramDriveSelenium();
                    SD.IsUsing = true;
                    AccountSetUsageTime(SD.AccountInst);
                }
            }
            while (string.Equals(st, "rate limited"));

            userInstagram.Followings = AllFollowings;

            return userInstagram;

        }

        /// <summary>
        /// Проверка валидности аккаунта Instagram 
        /// </summary>
        /// <param name="DS"></param>
        private static void RunCheckingInstagramAccount(InstagramDriverSelenium DS)
        {
            try
            {
                ChromeOptions options = new ChromeOptions();
                options.AddArguments("--disable-notifications");
                options.AddArguments("--no-sandbox");
                options.AddUserProfilePreference("profile.default_content_setting_values.images", 2);
                ChromeDriver driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), options);
                //ChromeDriver driver = new ChromeDriver(@"C:\chromedriver\", options);
                DS.driver = driver;
                UserInstagram user = InstagramSeleniumManager.getCurrentInstagramUser(DS.AccountInst, DS.driver);
                if (user == null)
                {
                    DS.driver.Quit();
                    DS.driver = null;
                }
                DS.IsRuning = false;
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Selenium.RunCheckingAccount. Параметры DriverSelenium  DS.Url {0}. Текст ошибки {1}",
                     DS.Url, ex.ToString()));
            }
        }


        /// <summary>
        /// Возвращает свободный браузер и запускает процесс получения данных по запрашиваемой странице
        /// </summary>
        /// <returns></returns>
        public static UserInstagram RunParseUserInstagramPage(string username, int count)
        {
            InstagramDriverSelenium SD = GetInstagramDriveSelenium();
            SD.IsUsing = true;
            AccountSetUsageTime(SD.AccountInst);
            UserInstagram result = getInstagramUser(SD, username, count);
            SD.IsUsing = false;
            return result;
        }

        /// <summary>
        /// Возвращает неиспользуемый драйвер селениума
        /// </summary>
        /// <returns></returns>
        public static InstagramDriverSelenium GetInstagramDriveSelenium()
        {
            InstagramDriverSelenium SD = null;
            do
            {
                if (instagramDriverSeleniumList.Count() == 0)
                {
                    throw new ArgumentException("Отсутстуют рабочие аккаунты для парсинга страницы Instagram");
                }
                if (instagramDriverSeleniumList.Where(x => x.IsUsing == false).Count() > 0)
                    SD = instagramDriverSeleniumList.Where(x => x.IsUsing == false).OrderBy(x => x.AccountInst.last_usage).First();
                if (SD != null)
                    break;
                InstagramSeleniumManagerRefresh();
                Thread.Sleep(10000);
            }
            while (true);
            return SD;
        }

    }
}

