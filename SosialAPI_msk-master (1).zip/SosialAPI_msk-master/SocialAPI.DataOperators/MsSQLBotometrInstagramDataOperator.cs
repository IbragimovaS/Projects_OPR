﻿using System;
using SocialAPI.Mappers.MsSQL;
using SocialAPI.Models.MsSQL.BotometrModel;
using System.Collections.Generic;
using System.Linq;
using SocialAPIML.Model;
using SocialAPI.Models.MsSQL;
using SocialAPI.Connections;

namespace SocialAPI.DataOperators
{
    /// <summary>
    /// Класс для работы с данными, хранящимися в MS SQL
    /// </summary>
    public static partial class MsSQLDataOperator
    {
        /// <summary>
        /// Записать входные данные для нейронной сети ботометра
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static int WriteToDBBotometrTrainingSet(ModelInput model)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.BotometrTrainingSetUsers.Add(model);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Получить последний самый старый прокси
        /// </summary>
        /// <returns></returns>
        public static Proxy GetGoodProxy()
        {
            Proxy proxy = GetProxy();
            if (proxy != null)
            {
                ProxyUsageTime(proxy);
                bool is_Connected = ProxyConnection.TestingConnection(proxy);
                if (is_Connected)
                {
                    return proxy;
                }
                else
                {
                    ProxySetBad(proxy);
                    return GetGoodProxy();
                }
            }
            return proxy;
        }

        /// <summary>
        /// Получить список прокси
        /// </summary>
        /// <returns></returns>
        public static List<Proxy> ProxyGet()
        {
            List<Proxy> res = new List<Proxy>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.ProxySet.OrderBy(x => x.last_usage).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Найти прокси по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static Proxy ProxyFind(Guid rid)
        {
            Proxy res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.ProxySet.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Удалить параметры прокси
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int ProxyRemove(Proxy proxy)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.ProxySet.Remove(proxy);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Записать прокси
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static int ProxyAdd(Proxy model)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.ProxySet.Add(model);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        

        /// <summary>
        /// Установить время последнего использования прокси
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int ProxyUsageTime(Proxy proxy)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    proxy.last_usage = DateTime.Now;
                    modelContext.ProxySet.Update(proxy);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Получить хороший, годный прокси для использования
        /// </summary>
        /// <returns></returns>
        public static Proxy GetProxy()
        {
            Proxy res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.ProxySet.Where(x => x.is_good).OrderBy(x => x.last_usage).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Установить что прокси плохой
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int ProxySetBad(Proxy proxy)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    proxy.is_good = false;
                    modelContext.ProxySet.Update(proxy);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
    }
}

