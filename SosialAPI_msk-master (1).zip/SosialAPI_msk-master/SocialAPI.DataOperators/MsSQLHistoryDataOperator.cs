﻿using SocialAPI.Mappers.MsSQL;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.History;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using SocialAPI.Models.SocialNetworks.VK;
using System.Reflection;
using SocialAPI.Models.SocialNetworks.OK;
using SocialAPI.Models.SocialNetworks.Twitter;
using SocialAPI.Models.SocialNetworks.Facebook;
using SocialAPI.Models.SocialNetworks.Instagram;

namespace SocialAPI.DataOperators
{
    /// <summary>
    /// Класс для работы с данными, хранящимися в MS SQL
    /// </summary>
    public static partial class MsSQLDataOperator
    {
        #region HistoryVK
        /// <summary>
        /// Получить набор изменений атрибутов для пользователей ВКонтакте
        /// </summary>
        /// <returns></returns>
        public static List<HistoryVK> HistoryVKGet()
        {
            List<HistoryVK> res = new List<HistoryVK>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryVK.OrderBy(x => x.date_change).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить изменения атрибутов  пользователей ВКонтакте на дату
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static HistoryVK HistoryVKFind(DateTime dt)
        {
            HistoryVK res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryVK.Where(x => x.date_change == dt).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить историю изменения атрибутов для данного пользователя ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static HistoryVK HistoryVKFind(long id)
        {
            HistoryVK res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryVK.Where(x => x.id_user_vk == id).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Добавить запись изменения атрибута пользователя ВКонтакте
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryVKAdd(HistoryVK history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryVK.Add(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Добавить в историю записи для всех атрибутов при добавлении нового пользлователя ВКонтакте в БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int HistoryVKAdd(UserVK curentVK)
        {
            int res = 0;
            PropertyInfo[] props;
            Type t = (typeof(UserVK));
            props = t.GetProperties();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentVK);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentVK.Friends.Count().ToString());
                    }
                    else if (attrName.Equals("Followers"))
                    {
                        dic.Add(attrName, curentVK.Followers.Count().ToString());
                    }
                    else if (attrName.Equals("Subscriptions"))
                    {
                        dic.Add(attrName, curentVK.Subscriptions.Count().ToString());
                    }
                    else if (attrName.Equals("Universities"))
                    {
                        dic.Add(attrName, curentVK.universities_list);
                    }
                    else if (attrName.Equals("Country"))
                    {
                        dic.Add(attrName, curentVK.CountryName);
                    }
                    else if (attrName.Equals("Career"))
                    {
                        dic.Add(attrName, curentVK.career_list);
                    }
                    else if (attrName.Equals("Schools"))
                    {
                        dic.Add(attrName, curentVK.schools_list);
                    }
                    else if (attrName.Equals("Last_seen"))
                    {
                        dic.Add(attrName, curentVK.last_seen_platform.ToString());
                    }
                    else if (attrName.Equals("City"))
                    {
                        dic.Add(attrName, curentVK.CityName);
                    }
                    else if (attrName.Equals("Military"))
                    {
                        dic.Add(attrName, curentVK.military_list);
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);

                HistoryVK history = new HistoryVK();
                history.rid = Guid.NewGuid();
                history.id_user_vk = curentVK.id;
                history.attribute_name = attrName;
                history.old_value = null;
                history.new_value = dic[attrName];
                history.date_change = DateTime.Now;
                MsSQLDataOperator.HistoryVKAdd(history);
                res++;
            }
            return res;
        }

        /// <summary>
        /// Удалить запись изменения атрибута пользователя ВКонтакте
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryVKRemove(HistoryVK history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryVK.Remove(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
        #endregion

        #region HistoryOK
        /// <summary>
        /// Получить набор изменений атрибутов для пользователей "Одноклассники"
        /// </summary>
        /// <returns></returns>
        public static List<HistoryOK> HistoryOKGet()
        {
            List<HistoryOK> res = new List<HistoryOK>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryOK.OrderBy(x => x.date_change).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить изменения атрибутов  пользователей "Одноклассники" на дату
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static HistoryOK HistoryOKFind(DateTime dt)
        {
            HistoryOK res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryOK.Where(x => x.date_change == dt).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить историю изменения атрибутов для данного пользователя "Одноклассники"
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static HistoryOK HistoryOKFind(long uid)
        {
            HistoryOK res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryOK.Where(x => x.id_user_ok == uid).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Добавить запись изменения атрибута пользователя "Одноклассники"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryOKAdd(HistoryOK history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryOK.Add(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Добавить в историю записи для всех атрибутов при добавлении нового пользлователя "Одноклассники" в БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int HistoryOKAdd(UserOK curentOK)
        {
            int res = 0;
            PropertyInfo[] props;
            Type t = (typeof(UserOK));
            props = t.GetProperties();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentOK);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentOK.Friends.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);

                HistoryOK history = new HistoryOK();
                history.rid = Guid.NewGuid();
                history.id_user_ok = curentOK.uid;
                history.attribute_name = attrName;
                history.old_value = null;
                history.new_value = dic[attrName];
                history.date_change = DateTime.Now;
                MsSQLDataOperator.HistoryOKAdd(history);
                res++;
            }
            return res;
        }

        /// <summary>
        /// Удалить запись изменения атрибута пользователя "Одноклассники"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryOKRemove(HistoryOK history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryOK.Remove(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
        #endregion


        #region HistoryTwitter
        /// <summary>
        /// Получить набор изменений атрибутов для пользователей "Twitter"
        /// </summary>
        /// <returns></returns>
        public static List<HistoryTwitter> HistoryTwitterGet()
        {
            List<HistoryTwitter> res = new List<HistoryTwitter>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryTwitter.OrderBy(x => x.date_change).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить изменения атрибутов  пользователей "Twitter" на дату
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static HistoryTwitter HistoryTwitterFind(DateTime dt)
        {
            HistoryTwitter res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryTwitter.Where(x => x.date_change == dt).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить историю изменения атрибутов для данного пользователя "Twitter"
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static HistoryTwitter HistoryTwitterFind(long id)
        {
            HistoryTwitter res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryTwitter.Where(x => x.id_user_twitter == id).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Добавить запись изменения атрибута пользователя "Twitter"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryTwitterAdd(HistoryTwitter history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryTwitter.Add(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Добавить в историю записи для всех атрибутов при добавлении нового пользлователя "Facebook" в БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int HistoryTwitterAdd(UserTwitter curentTwitter)
        {
            int res = 0;
            PropertyInfo[] props;
            Type t = (typeof(UserTwitter));
            props = t.GetProperties();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentTwitter);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentTwitter.Friends.Count().ToString());
                    }
                    else if (attrName.Equals("Followers"))
                    {
                        dic.Add(attrName, curentTwitter.Followers.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);

                HistoryTwitter history = new HistoryTwitter();
                history.rid = Guid.NewGuid();
                history.id_user_twitter = curentTwitter.id;
                history.attribute_name = attrName;
                history.old_value = null;
                history.new_value = dic[attrName];
                history.date_change = DateTime.Now;
                MsSQLDataOperator.HistoryTwitterAdd(history);
                res++;
            }
            return res;
        }

        /// <summary>
        /// Удалить запись изменения атрибута пользователя "Twitter"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryTwitterRemove(HistoryTwitter history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryTwitter.Remove(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
        #endregion

        #region HistoryFacebook
        /// <summary>
        /// Получить набор изменений атрибутов для пользователей "Facebook"
        /// </summary>
        /// <returns></returns>
        public static List<HistoryFacebook> HistoryFacebookGet()
        {
            List<HistoryFacebook> res = new List<HistoryFacebook>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryFacebook.OrderBy(x => x.date_change).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить изменения атрибутов  пользователей "Facebook" на дату
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static HistoryFacebook HistoryFacebookFind(DateTime dt)
        {
            HistoryFacebook res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryFacebook.Where(x => x.date_change == dt).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить историю изменения атрибутов для данного пользователя "Facebook"
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static HistoryFacebook HistoryFacebookFind(string page)
        {
            HistoryFacebook res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryFacebook.Where(x => x.id_user_facebook == page).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Добавить запись изменения атрибута пользователя "Facebook"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryFacebookAdd(HistoryFacebook history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryFacebook.Add(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Добавить в историю записи для всех атрибутов при добавлении нового пользлователя "Facebook" в БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int HistoryFacebookAdd(UserFacebook curentFacebook)
        {
            int res = 0;
            PropertyInfo[] props;
            Type t = (typeof(UserFacebook));
            props = t.GetProperties();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentFacebook);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentFacebook.Friends.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);

                HistoryFacebook history = new HistoryFacebook();
                history.rid = Guid.NewGuid();
                history.id_user_facebook = curentFacebook.Page;
                history.attribute_name = attrName;
                history.old_value = null;
                history.new_value = dic[attrName];
                history.date_change = DateTime.Now;
                MsSQLDataOperator.HistoryFacebookAdd(history);
                res++;
            }
            return res;
        }

        /// <summary>
        /// Удалить запись изменения атрибута пользователя "Facebook"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryFacebookRemove(HistoryFacebook history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryFacebook.Remove(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
        #endregion

        #region HistoryInstagram
        /// <summary>
        /// Получить набор изменений атрибутов для пользователей "Instagram"
        /// </summary>
        /// <returns></returns>
        public static List<HistoryInstagram> HistoryInstagramGet()
        {
            List<HistoryInstagram> res = new List<HistoryInstagram>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryInstagram.OrderBy(x => x.date_change).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить изменения атрибутов  пользователей "Instagram" на дату
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static HistoryInstagram HistoryInstagramFind(DateTime dt)
        {
            HistoryInstagram res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryInstagram.Where(x => x.date_change == dt).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить историю изменения атрибутов для данного пользователя "Instagram"
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static HistoryInstagram HistoryInstagramFind(long id)
        {
            HistoryInstagram res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.HistoryInstagram.Where(x => x.id_user_instagram == id).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Добавить запись изменения атрибута пользователя "Instagram"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryInstagramAdd(HistoryInstagram history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryInstagram.Add(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Добавить в историю записи для всех атрибутов при добавлении нового пользлователя "Instagram" в БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int HistoryInstagramAdd(UserInstagram curentInstagram)
        {
            int res = 0;
            PropertyInfo[] props;
            Type t = (typeof(UserInstagram));
            props = t.GetProperties();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentInstagram);
                if (attrValue != null)
                {
                    if (attrName.Equals("Followers"))
                    {
                        dic.Add(attrName, curentInstagram.Followers.Count().ToString());
                    }
                    else if (attrName.Equals("Followings"))
                    {
                        dic.Add(attrName, curentInstagram.Followings.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);

                HistoryInstagram history = new HistoryInstagram();
                history.rid = Guid.NewGuid();
                history.id_user_instagram = curentInstagram.id;
                history.attribute_name = attrName;
                history.old_value = null;
                history.new_value = dic[attrName];
                history.date_change = DateTime.Now;
                MsSQLDataOperator.HistoryInstagramAdd(history);
                res++;
            }
            return res;
        }

        /// <summary>
        /// Удалить запись изменения атрибута пользователя "Instagram"
        /// </summary>
        /// <param name="history"></param>
        /// <returns></returns>
        public static int HistoryInstagramRemove(HistoryInstagram history)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.HistoryInstagram.Remove(history);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
        #endregion
    }
}
