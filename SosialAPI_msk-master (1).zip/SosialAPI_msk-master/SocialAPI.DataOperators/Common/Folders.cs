﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SocialAPI.Common
{
    /// <summary>
    /// В классе содержатся пути к папкам, используемым приложением
    /// </summary>
    public static class Folders
    {
        /// <summary>
        /// Путь к основной папке для хранения данных
        /// </summary>
        public static string MainDataFolder
        {
            get
            {
                string directoryName = String.Format(@"{0}\Glavcode\i4FindFace\", Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));
                if (!Directory.Exists(directoryName))
                    Directory.CreateDirectory(directoryName);
                return directoryName;
            }
        }
    }
}
