﻿using SocialAPI.Models.MsSQL.AccountManager;
using System;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.Selenium;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Reflection;
using SocialAPI.Models.SocialNetworks.Facebook;
using System.Threading;
using System.Diagnostics;
using SocialAPI.Mappers.MsSQL;
using System.Text;
using OpenQA.Selenium;

namespace SocialAPI.DataOperators
{
    /// <summary>
    /// Класс для работы с данными, хранящимися в MS SQL
    /// </summary>
    public static partial class MsSQLDataOperator
    {
        /// <summary>
        /// Класс статуса использования логина в данный момент
        /// </summary>
        public class FacebookDriverSelenium : IDisposable
        {
            /// <summary>
            /// Привязанный к драйверу селениума аккаунт facebook
            /// </summary>
            public AccountManagerFacebook AccountFB { get; set; }

            /// <summary>
            /// Признак использования драйвера
            /// </summary>
            public bool IsUsing { get; set; }

            /// <summary>
            /// Экземпляр драйвера селениум
            /// </summary>
            public ChromeDriver driver { get; set; }

            /// <summary>
            /// Текущая страница - объект парсинга
            /// </summary>
            public string Url { get; set; }

            /// <summary>
            /// Признак того, что браузер запущен
            /// </summary>
            public bool IsRuning { get; set; }

            // Flag: Has Dispose already been called?
            bool disposed = false;

            // Public implementation of Dispose pattern callable by consumers.
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }

            // Protected implementation of Dispose pattern.
            protected virtual void Dispose(bool disposing)
            {
                if (disposed)
                    return;

                if (disposing)
                {
                    // Free any other managed objects here.
                    //
                }

                // Free any unmanaged objects here.
                driver.Quit();
                disposed = true;
            }

            ~FacebookDriverSelenium()
            {
                Dispose(false);
            }
        }

        public static List<FacebookDriverSelenium> facebookDriverSeleniumList;

        /// <summary>
        /// Заполнение актуальными аккаунтами и создание драйверов селениума
        /// </summary>
        public static void GetSeleniumFacebook()
        {

            facebookDriverSeleniumList = new List<FacebookDriverSelenium>();
            List<AccountManagerFacebook> fbAcs = AccountsFacebookGoodGet();
            CheckFacebookAccounts(fbAcs);
        }

        /// <summary>
        /// Остановка всех драйверова селениума для аккаунтов facebook
        /// </summary>
        public static void StopSeleniumFacebook()
        {
            if (facebookDriverSeleniumList != null)
                foreach (var driver in facebookDriverSeleniumList)
                {
                    driver.driver.Quit();
                }
        }


        /// <summary>
        /// Проверяет состояние аккаунтов
        /// </summary>
        /// <param name="fbAcs"></param>
        private static void CheckFacebookAccounts(List<AccountManagerFacebook> fbAcs)
        {
            foreach (AccountManagerFacebook acc in fbAcs)
            {
                FacebookDriverSelenium driver = new FacebookDriverSelenium() { AccountFB = acc, IsUsing = false, IsRuning = true };
                RunCheckingFacebookAccount(driver);
                facebookDriverSeleniumList.Add(driver);
            }
            while (facebookDriverSeleniumList.Where(x => x.IsRuning).Count() > 0)
            {
                Thread.Sleep(1000);
            }
            foreach (var acc in facebookDriverSeleniumList.Where(x => x.driver == null))
            {
                AccountSetBad(acc.AccountFB);
            }
            facebookDriverSeleniumList.RemoveAll(x => x.driver == null);
        }


        /// <summary>
        /// Актуализация аккунтов facebook 
        /// </summary>
        private static void FacebookSeleniumManagerRefresh()
        {
            List<AccountManagerFacebook> fbAcs = AccountsFacebookGoodGet();
            var newAccaout = facebookDriverSeleniumList.Where(item => !fbAcs.Any(item2 => item2.user_name == item.AccountFB.user_name)).Select(x => x.AccountFB).ToList();
            CheckFacebookAccounts(newAccaout);
        }


        /// <summary>
        /// Возвращает пользователя для переданной страницы
        /// </summary>
        static UserFacebook getFacebookUser(FacebookDriverSelenium DS, string Url)
        {
            UserFacebook userFacebook = FacebookSeleniumManager.getUserFacebookWithFriends(Url, DS.driver);
            return userFacebook;
        }

        /// <summary>
        /// Проверка валидности аккаунта Facebook 
        /// </summary>
        /// <param name="DS"></param>
        private static void RunCheckingFacebookAccount(FacebookDriverSelenium DS)
        {
            try
            {
                ChromeOptions options = new ChromeOptions();
                options.AddArguments("--disable-notifications");
                options.AddArguments("--no-sandbox");
                options.AddUserProfilePreference("profile.default_content_setting_values.images", 2);
                var loc = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                ChromeDriver driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), options);
                DS.driver = driver;
                UserFacebook user = FacebookSeleniumManager.getCurrentFacebookUser(DS.AccountFB, DS.driver);
                if (user == null)
                {
                    DS.driver.Quit();
                    DS.driver = null;
                }
                else
                {
                    var cookie_string = GetCookieAsString(DS.driver);
                    AccountTwitterSetIsUsed(DS.AccountFB, cookie_string);
                }
                DS.IsRuning = false;
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Selenium.RunCheckingAccount. Параметры DriverSelenium  DS.Url {0}. Текст ошибки {1}",
                     DS.Url, ex.ToString()));
            }
        }


        /// <summary>
        /// Запускает процесс парсинга
        /// </summary>
        /// <returns></returns>
        public static UserFacebook RunParseUserFacebookPage(string url)
        {
            FacebookDriverSelenium SD = GetFacebookDriveSelenium();
            SD.IsUsing = true;
            AccountSetUsageTime(SD.AccountFB);
            UserFacebook result = getFacebookUser(SD, url);
            SD.IsUsing = false;
            return result;
        }

        /// <summary>
        /// Возвращает неиспользуемый драйвер селениума пригодный для парсинга
        /// </summary>
        /// <returns></returns>
        public static FacebookDriverSelenium GetFacebookDriveSelenium()
        {
            FacebookDriverSelenium SD = null;
            do
            {
                if (facebookDriverSeleniumList.Count() == 0)
                {
                    throw new ArgumentException("Отсутстуют рабочие аккаунты для парсинга страницы facebook");
                }

                if (facebookDriverSeleniumList.Where(x => x.IsUsing == false).Count() > 0)
                    SD = facebookDriverSeleniumList.Where(x => x.IsUsing == false).OrderBy(x => x.AccountFB.last_usage).First();
                if (SD != null)
                    break;
                FacebookSeleniumManagerRefresh();
                Thread.Sleep(10000);
            }
            while (true);
            return SD;
        }

        /// <summary>
        /// Установить признак использоватия аккаунта
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int AccountTwitterSetIsUsed(AccountManagerFacebook account, string cookie)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    account.cookie_string = cookie;
                    modelContext.AccountManagerFacebook.Update(account);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Записывает наименование куки и значение в строку (каждый куки соответствует своя строка)
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string GetCookieAsString(ChromeDriver driver)
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                foreach (Cookie ck in driver.Manage().Cookies.AllCookies)
                {
                    builder.AppendLine(ck.Name + ";" + ck.Value);
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return builder.ToString();
        }

    }
}

