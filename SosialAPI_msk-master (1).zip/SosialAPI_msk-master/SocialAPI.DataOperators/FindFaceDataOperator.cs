﻿using Newtonsoft.Json;
using SocialAPI.Common;
using SocialAPI.Models.FindFace;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using static SocialAPI.Models.FindFace.Search;

namespace SocialAPI.DataOperators
{
   public class FindFaceDataOperator
    {

        public static FindFaceResult RunSearch(byte[] file, string fileName, int deph)
        {
            FindFaceResult result = new FindFaceResult();

            result.VKResult = FindVK(file, fileName, deph);
            result.OKResult = FindOK(file, fileName, deph);

            return result;
        }

        /// <summary>
        /// Поиск пользователя в VK
        /// </summary>
        /// <param name="file"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private static List<SearchResult> FindVK(byte[] file, string fileName, int deph)
        {
            Search faceSearch = null;
            string resDetect = Detect("https://webapi.vkproxy.ru/v2/vk-api/detect", file, "image", "text/html", fileName);
            FaceDetect faceDetected = null;
            if (!String.IsNullOrEmpty(resDetect))
                faceDetected = JsonConvert.DeserializeObject<FaceDetect>(resDetect);
            if (faceDetected == null)
                return null;

            for (int i = 0; i < faceDetected.bboxes.Count; i++)
            {
                
                string resSerch = String.Empty;
                resSerch = Search("https://webapi.vkproxy.ru/v2/vk-api/search?", i, faceDetected, "vk");
                try
                {

                    if (!String.IsNullOrEmpty(resSerch))
                        faceSearch = JsonConvert.DeserializeObject<Search>(resSerch);
                }
                catch (Exception ex)
                {
                }
                faceSearch.results = faceSearch.results.Take(deph).ToList();
               
            }

            return faceSearch.results;
        }

        /// <summary>
        /// Поиск пользователя в ОК
        /// </summary>
        /// <param name="file"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private static List<SearchResult> FindOK(byte[] file, string fileName, int deph)
        {
            Search faceSearch = null;
            string resDetect = Detect("https://webapi.vkproxy.ru/v2/vk-api/detect", file, "image", "text/html", fileName);
            FaceDetect faceDetected = null;
            if (!String.IsNullOrEmpty(resDetect))
                faceDetected = JsonConvert.DeserializeObject<FaceDetect>(resDetect);
            if (faceDetected == null)
                return null;

            for (int i = 0; i < faceDetected.bboxes.Count; i++)
            {
                
                string resSerch = String.Empty;
                resSerch = Search("https://webapi.vkproxy.ru/v2/vk-api/search?", i, faceDetected, "ok");
                try
                {

                    if (!String.IsNullOrEmpty(resSerch))
                        faceSearch = JsonConvert.DeserializeObject<Search>(resSerch);
                }
                catch (Exception ex)
                {
                }
                faceSearch.results = faceSearch.results.Take(deph).ToList();
            }

            return faceSearch.results;
        }

        /// <summary>
        /// Определяет наличие лиц в базе 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="file"></param>
        /// <param name="paramName"></param>
        /// <param name="contentType"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private static string Detect(string url, byte[] file, string paramName, string contentType, string fileName)
        {

            string result = "";
            string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
            byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(url);
            string token = String.Empty;
            try
            {
                string[] autData = File.ReadAllLines(String.Format(@"{0}\token.txt", Folders.MainDataFolder));
                token = autData[0];
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
            wr.Headers.Add("authorization", String.Format("Token {0}", token));
            wr.ContentType = "multipart/form-data; boundary=" + boundary;
            wr.Method = "POST";
            wr.KeepAlive = true;
            wr.Credentials = System.Net.CredentialCache.DefaultCredentials;
            Stream rs = wr.GetRequestStream();
            string formdataTemplate = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";

            rs.Write(boundarybytes, 0, boundarybytes.Length);
            string headerTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";
            string header = string.Format(headerTemplate, paramName, "pictures", contentType);
            byte[] headerbytes = System.Text.Encoding.UTF8.GetBytes(header);
            rs.Write(headerbytes, 0, headerbytes.Length);


            foreach (var b in file)
                rs.WriteByte(b);

            byte[] trailer = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
            rs.Write(trailer, 0, trailer.Length);
            rs.Close();
            WebResponse wresp = null;
            try
            {
                wresp = wr.GetResponse();
                Stream stream2 = wresp.GetResponseStream();
                StreamReader reader2 = new StreamReader(stream2);
                result = reader2.ReadToEnd();
            }
            catch (Exception ex)
            {
                if (String.Equals("Удаленный сервер возвратил ошибку: (413) Request Entity Too Large.", ex.Message))
                {

                }
                return null;
                if (wresp != null)
                {
                    wresp.Close();
                    wresp = null;
                }
            }
            finally
            {
                wr = null;
            }
            return result;
        }

        /// <summary>
        /// Находит лицо в базе
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string Search(string url, int i, FaceDetect faceDetect, string where)
        {
            int x1 = faceDetect.bboxes[i][0];
            int y1 = faceDetect.bboxes[i][1];
            int x2 = faceDetect.bboxes[i][2];
            int y2 = faceDetect.bboxes[i][3];

            url = String.Format("{0}image_hash={1}&x1={2}&y1={3}&x2={4}&y2={5}&where={6}", url, faceDetect.image_hash, x1, y1, x2, y2, where);

            string result = "";
            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(url);
            string token = String.Empty;
            try
            {
                string[] autData = File.ReadAllLines(String.Format(@"{0}\token.txt", Folders.MainDataFolder));
                token = autData[0];
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message);
            }
            wr.Headers.Add("authorization", String.Format("Token {0}", token));

            wr.Method = "POST";
            wr.KeepAlive = true;
            wr.Credentials = System.Net.CredentialCache.DefaultCredentials;

            WebResponse wresp = null;
            try
            {
                wresp = wr.GetResponse();
                Stream stream2 = wresp.GetResponseStream();
                StreamReader reader2 = new StreamReader(stream2);
                result = reader2.ReadToEnd();
            }
            catch (Exception ex)
            {
                if (String.Equals("Удаленный сервер возвратил ошибку: (413) Request Entity Too Large.", ex.Message))
                {

                }
                return null;
                if (wresp != null)
                {
                    wresp.Close();
                    wresp = null;
                }
            }
            finally
            {
                wr = null;
            }
            return result;
        }
    }
}
