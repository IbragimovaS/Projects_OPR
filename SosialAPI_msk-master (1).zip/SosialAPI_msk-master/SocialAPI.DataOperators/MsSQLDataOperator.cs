﻿using SocialAPI.Connections;

using SocialAPI.Mappers.MsSQL;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks.Facebook;
using SocialAPI.Models.SocialNetworks.OK;
using SocialAPI.Models.SocialNetworks.Twitter;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace SocialAPI.DataOperators
{
    /// <summary>
    /// Класс для работы с данными, хранящимися в MS SQL
    /// </summary>
    public static partial class MsSQLDataOperator
    {
        #region Users
        /// <summary>
        /// Получить набор пользователей из БД
        /// </summary>
        /// <returns></returns>
        public static List<User> UsersGet()
        {
            List<User> res = new List<User>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.Users.OrderBy(x => x.user_name).ToList();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Получить пользователя по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static User UsersFind(Guid rid)
        {
            User res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.Users.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
            }
            return res;
        }

        /// <summary>
        /// Добавить пользователя в БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int UsersAdd(User user)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.Users.Add(user);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Удалить пользователя из БД
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int UsersRemove(User user)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.Users.Remove(user);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Обновить данные о пользователе SocialAPI
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static int UsersUpdate(User user)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    modelContext.Update(user);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }
        #endregion

        #region AccountManager
        /// <summary>
        /// Добавить учетную запись по социальной сети
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int AccountAdd(AccountManagerAbstract account)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    switch (account)
                    {
                        case AccountManagerFacebook a:
                            modelContext.AccountManagerFacebook.Add(a);
                            break;
                        case AccountManagerInstagram a:
                            modelContext.AccountManagerInstagram.Add(a);
                            break;
                        case AccountManagerOK a:
                            modelContext.AccountManagerOK.Add(a);
                            break;
                        case AccountManagerTwitter a:
                            modelContext.AccountManagerTwitter.Add(a);
                            break;
                        case AccountManagerVK a:
                            modelContext.AccountManagerVK.Add(a);
                            break;
                    }
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Удалить параметры доступа к социальной сети
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int AccountRemove(AccountManagerAbstract account)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    switch (account)
                    {
                        case AccountManagerFacebook a:
                            modelContext.AccountManagerFacebook.Remove(a);
                            break;
                        case AccountManagerInstagram a:
                            modelContext.AccountManagerInstagram.Remove(a);
                            break;
                        case AccountManagerOK a:
                            modelContext.AccountManagerOK.Remove(a);
                            break;
                        case AccountManagerTwitter a:
                            modelContext.AccountManagerTwitter.Remove(a);
                            break;
                        case AccountManagerVK a:
                            modelContext.AccountManagerVK.Remove(a);
                            break;
                    }
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Получить параметры доступа к фейсбук
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerFacebook> AccountsFacebookGet()
        {
            List<AccountManagerFacebook> res = new List<AccountManagerFacebook>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerFacebook.OrderBy(x => x.user_name).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Получить параметры доступа к фейсбук для хороших аккаунтов
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerFacebook> AccountsFacebookGoodGet()
        {
            List<AccountManagerFacebook> res = AccountsFacebookGet().Where(x => x.is_good).ToList();
         
            return res;
        }

        /// <summary>
        /// Найти аккаунт Facebook по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static AccountManagerFacebook AccountFacebookFind(Guid rid)
        {
            AccountManagerFacebook res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerFacebook.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Получить параметры доступа к Инстаграм
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerInstagram> AccountsInstagramGet()
        {
            List<AccountManagerInstagram> res = new List<AccountManagerInstagram>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerInstagram.OrderBy(x => x.user_name).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Получить параметры доступа к Инстаграм для хороших аккаунтов
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerInstagram> AccountsInstagramGoodGet()
        {
            List<AccountManagerInstagram> res = AccountsInstagramGet().Where(x => x.is_good).ToList();
            return res;
        }

        /// <summary>
        /// Найти аккаунт Instagram по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static AccountManagerInstagram AccountInstagramFind(Guid rid)
        {
            AccountManagerInstagram res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerInstagram.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Получить параметры доступа к одноклассникам
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerOK> AccountsOKGet()
        {
            List<AccountManagerOK> res = new List<AccountManagerOK>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerOK.OrderBy(x => x.last_usage).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Найти аккаунт Одноклассники по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static AccountManagerOK AccountOKFind(Guid rid)
        {
            AccountManagerOK res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerOK.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Получить параметры достуа к Twitter
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerTwitter> AccountsTwitterGet()
        {
            List<AccountManagerTwitter> res = new List<AccountManagerTwitter>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerTwitter.OrderBy(x => x.last_usage).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Найти аккаунт Twitter по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static AccountManagerTwitter AccountsTwitterFind(Guid rid)
        {
            AccountManagerTwitter res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerTwitter.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Получить параметры доступа к ВК
        /// </summary>
        /// <returns></returns>
        public static List<AccountManagerVK> AccountsVKGet()
        {
            List<AccountManagerVK> res = new List<AccountManagerVK>();
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerVK.OrderBy(x => x.last_usage).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Найти аккаунт ВКонтакте по идентификатору
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public static AccountManagerVK AccountVKFind(Guid rid)
        {
            AccountManagerVK res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    res = modelContext.AccountManagerVK.Where(x => x.rid == rid).First();
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.ToString());
            }
            return res;
        }

        /// <summary>
        /// Установить что аккаунт заблокирован
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int AccountSetBad(AccountManagerAbstract account)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    account.is_good = false;
                    switch (account)
                    {
                        case AccountManagerFacebook a:
                            modelContext.AccountManagerFacebook.Update(a);
                            break;
                        case AccountManagerInstagram a:
                            modelContext.AccountManagerInstagram.Update(a);
                            break;
                        case AccountManagerOK a:
                            modelContext.AccountManagerOK.Update(a);
                            break;
                        case AccountManagerTwitter a:
                            modelContext.AccountManagerTwitter.Update(a);
                            break;
                        case AccountManagerVK a:
                            modelContext.AccountManagerVK.Update(a);
                            break;
                    }
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Установить время последнего использования аккаунта
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int AccountSetUsageTime(AccountManagerAbstract account)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    account.last_usage = DateTime.Now;
                    switch (account)
                    {
                        case AccountManagerFacebook a:
                            modelContext.AccountManagerFacebook.Update(a);
                            break;
                        case AccountManagerInstagram a:
                            modelContext.AccountManagerInstagram.Update(a);
                            break;
                        case AccountManagerOK a:
                            modelContext.AccountManagerOK.Update(a);
                            break;
                        case AccountManagerTwitter a:
                            modelContext.AccountManagerTwitter.Update(a);
                            break;
                        case AccountManagerVK a:
                            modelContext.AccountManagerVK.Update(a);
                            break;
                    }
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        /// <summary>
        /// Получить хороший, годный аккаунт для использования
        /// </summary>
        /// <returns></returns>
        static AccountManagerAbstract AccountsGetGood(Type type)
        {
            AccountManagerAbstract res = null;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    switch (type.Name)
                    {
                        case "AccountManagerFacebook":
                            res = modelContext.AccountManagerFacebook.Where(x => x.is_good).OrderBy(x => x.last_usage).First();
                            break;
                        case "AccountManagerInstagram":
                            res = modelContext.AccountManagerInstagram.Where(x => x.is_good).OrderBy(x => x.last_usage).First();
                            break;
                        case "AccountManagerOK":
                            res = modelContext.AccountManagerOK.Where(x => x.is_good).OrderBy(x => x.last_usage).First();
                            break;
                        case "AccountManagerTwitter":
                            do
                            {
                                if (modelContext.AccountManagerTwitter.Where(x => x.is_good).Count() == 0)
                                {
                                    throw new ArgumentException(String.Format(@"Отсутствуют хорошие аккаунты для Twitter"));
                                }

                                var tempAccTwList = modelContext.AccountManagerTwitter.Where(x => x.is_good && !x.is_used).OrderBy(x => x.last_usage);
                                if (tempAccTwList.Count() > 0)
                                {
                                    res = tempAccTwList.First();
                                }
                                if (res == null) Thread.Sleep(1000);
                            }
                            while (res == null);
                            AccountTwitterSetIsUsed(res as AccountManagerTwitter, true);//Резервирование аккаунта 
                            TimeSpan tsp = DateTime.Now - res.last_usage;
                            if (tsp.TotalMinutes < 15)
                            {
                                Thread.Sleep(tsp);
                            }

                            break;
                        case "AccountManagerVK":
                            res = modelContext.AccountManagerVK.Where(x => x.is_good).OrderBy(x => x.last_usage).First();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                { throw new ArgumentException(
                    String.Format(@"Ошибка в методе MsSQLDataOperator.AccountsGetGood( AccountManager = {0}), \n Exception = {1}",
                    type.Name, ex.Message));
                }

            }
            return res;
        }

        /// <summary>
        /// Получить хороший аккаунт ВКонтакте
        /// </summary>
        /// <returns></returns>
        public static AccountManagerVK GetGoodAccountVK()
        {
            AccountManagerVK vkAccount = AccountsGetGood(typeof(AccountManagerVK)) as AccountManagerVK;
            if (vkAccount != null && !String.IsNullOrEmpty(vkAccount.token))
            {
                AccountSetUsageTime(vkAccount);
                UserVK currentUserVK = VKConnection.getCurrentVKUser(vkAccount.token);
                if (currentUserVK != null)
                {
                    return vkAccount;
                }
                else
                {
                    AccountSetBad(vkAccount);
                    return GetGoodAccountVK();
                }
            }
            return vkAccount;
        }

        /// <summary>
        /// Получить хороший аккаунт OK
        /// </summary>
        /// <returns></returns>
        public static AccountManagerOK GetGoodAccountOK()
        {
            AccountManagerOK okAccount = AccountsGetGood(typeof(AccountManagerOK)) as AccountManagerOK;

            if (okAccount != null && !String.IsNullOrEmpty(okAccount.token))
            {
                AccountSetUsageTime(okAccount);
                UserOK currentUserOK = OKConnection.GetCurrentOKUser(okAccount);
                if (currentUserOK != null && currentUserOK.uid != 0)
                {
                    return okAccount;
                }
                else
                {
                    AccountSetBad(okAccount);
                    return GetGoodAccountOK();
                }
            }
            return okAccount;
        }


        private static void TwitterAccount_TimeIsComeEvent(AccountManagerTwitter sender, out AccountManagerTwitter newOb)
        {
            sender.last_usage = DateTime.Now;
            AccountTwitterSetIsUsed(sender, false);
            newOb = GetGoodAccountTwitter();
        }

        /// <summary>
        /// Получить хороший аккаунт Twitter
        /// </summary>
        /// <returns></returns>
        public static AccountManagerTwitter GetGoodAccountTwitter()
        {
            AccountManagerTwitter twitterAccount = AccountsGetGood(typeof(AccountManagerTwitter)) as AccountManagerTwitter;
            twitterAccount.TimeIsComeEvent += TwitterAccount_TimeIsComeEvent;
            if (twitterAccount != null && !String.IsNullOrEmpty(twitterAccount.access_token))
            {
                AccountSetUsageTime(twitterAccount);
                UserTwitter currentUserTwitter = TwitterConnection.getCurrentTwitterUser(ref twitterAccount);
                if (currentUserTwitter != null)
                {
                    return twitterAccount;
                }
                else
                {
                    AccountSetBad(twitterAccount);
                    AccountTwitterSetIsUsed(twitterAccount, false);
                    return GetGoodAccountTwitter();
                }
            }
            return twitterAccount;
        }

        /// <summary>
        /// Установить признак использоватия аккаунта
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static int AccountTwitterSetIsUsed(AccountManagerTwitter account, bool is_used)
        {
            int res = 0;
            try
            {
                using (MsSQLContext modelContext = new MsSQLContext())
                {
                    account.is_used = is_used;
                    modelContext.AccountManagerTwitter.Update(account);
                    modelContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                res = -1;
            }
            return res;
        }

        
        #endregion
    }
}
