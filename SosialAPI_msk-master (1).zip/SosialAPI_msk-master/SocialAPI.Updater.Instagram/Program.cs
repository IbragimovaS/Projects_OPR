﻿using SocialAPI.Mappers.Neo4j;
using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.DataOperators;
using SocialAPI.Models.MsSQL.History;
using SocialAPI.Mappers.Neo4j.Instagram;
using System.Threading;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using SocialAPI.Models.SocialNetworks.Instagram;
using SocialAPI.Models.SocialNetworks;
using System.Diagnostics;

namespace SocialAPI.Updater.Instagram
{
    class UserInstagramData
    {
        public UserInstagram data { get; set; }
    }

    /// <summary>
    /// При настройке запуска приложения по времени,  необходимо открыть вкладку действия
    /// в поле "Программа или сценарий" ввести dotnet
    /// В поле "Добавить аргументы" прописать путь к SocialAPI.Updater.Instagram.dll
    /// C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\SocialAPI.Updater.Instagram.dll 07DD29FF-1BF8-48DA-0272-08D729F8DF1B 1000 http://localhost:52147/
    /// При необходимости в поле "Рабочая папка" прописать путь к папке содержащей SocialAPI.Updater.Instagram.dll НАПРИМЕР - C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Служебное поле - массив полей Reflection
        /// </summary>
        public static PropertyInfo[] props;
        /// <summary>
        /// Служебное поле - массив наименований полей
        /// </summary>
        public static List<string> propNameList;

        /// <summary>
        /// Как в АПИ - количество подписчиков (друзья получаются все)
        /// </summary>
        public static int count;

        /// <summary>
        /// Токен для доступа к БД
        /// </summary>
        public static Guid user_token;

        /// <summary>
        /// Клиент для получения пользователей по средством Http запросов
        /// </summary>
        public static HttpClient client = new HttpClient();

        /// <summary>
        /// базовый адрес универсального идентификатора ресурса (URI) Интернета
        /// </summary>
        public static Uri baseAddress;

        /// <summary>
        /// Признак запуска обновления данных
        /// </summary>
        public static bool isRuning;

        /// <summary>
        /// Список полей, изменение значений которых не нужно сохранять в истории 
        /// </summary>
        public static List<string> notUpdatePropNameList;


        static void Main(string[] args)
        {
            MsSQLDataOperator.ParseArgs(args, ref user_token, ref count);

            if (3 <= args.Length)
                baseAddress = new Uri(args[2]);
            else
                baseAddress = new Uri("http://localhost:64195/");
            Init(user_token, count, baseAddress);

            Run();
        }

        /// <summary>
        /// Инициализация всех установок
        /// </summary>
        public static void Init(Guid usr_token, int cnt, Uri baseAddress)
        {
            Type t = (typeof(UserInstagram));
            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            notUpdatePropNameList = new List<string>() {
                "edge_followed_by"
                ,"edge_follow"
            };

            client.BaseAddress = baseAddress;
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// Инициализация всех установок (для интеграционного тестирования)
        /// </summary>
        public static void Init(Guid usr_token, int cnt, HttpClient _client)
        {
            Type t = (typeof(UserInstagram));
            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            notUpdatePropNameList = new List<string>() {
                "edge_followed_by"
                ,"edge_follow"
            };


            client = _client;
        }

        /// <summary>
        /// Основная процедура
        /// </summary>
        public static void Run()
        {
            //Проверить токен пользователя в БД
            Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
            if (currentUser == null)
            {
                throw new Exception("Для пользователя user_token = \"" + user_token.ToString() + "\" не выполнен вход.");
            }

            using (UserInstagramMapper mapper = new UserInstagramMapper(Neo4jClientSource.CreateClient()))
            {
                using (FollowersInstagramMapper followersMapper = new FollowersInstagramMapper(Neo4jClientSource.CreateClient()))
                {

                    while (isRuning)
                    {
                        Dictionary<string, string> instance_values_db = new Dictionary<string, string>();
                        Dictionary<string, string> instance_values_socialNet = new Dictionary<string, string>();
                        UserInstagram curentInstagram_db = getLastValue();
                        UserInstagram curentInstagram_socialNet = null;

                        if (curentInstagram_db == null) //Если в базе отсутствует запись т ждем 5 минут 
                        {
                            Thread.Sleep(5000 * 60);
                            continue;
                        }

                        #region Получение данных из БД
                        if (curentInstagram_db != null)
                        {
                            curentInstagram_db.Followers = followersMapper.GetFollowers(curentInstagram_db).ToList();
                            curentInstagram_db.Followings = followersMapper.GetSubscriptions(curentInstagram_db).ToList();
                            fillDictionaty(curentInstagram_db, ref instance_values_db);
                        }

                        #endregion

                        #region Получение данных из социальной сети

                        var url = String.Format(@"/api/users/findinstagram?user_token={0}&username={1}", user_token, curentInstagram_db.username);

                        var getData = FindUserInInstagramAsync(url);
                        if (getData.Result == null)
                            throw new Exception("Запрос по странице Page = \"" + curentInstagram_db.username + "\" не вернул результат.");
                        curentInstagram_socialNet = getData.Result;

                        DateTime updateDate = DateTime.Now;
                        if (curentInstagram_socialNet != null)
                        {
                            curentInstagram_socialNet.updateDate = updateDate;
                            if (curentInstagram_socialNet.Followers != null)
                                MsSQLDataOperator.SetUpdateDate(curentInstagram_socialNet.Followers.ToList<AbstractUser>(), updateDate);
                            if (curentInstagram_socialNet.Followings != null)
                                MsSQLDataOperator.SetUpdateDate(curentInstagram_socialNet.Followings.ToList<AbstractUser>(), updateDate);

                            fillDictionaty(curentInstagram_socialNet, ref instance_values_socialNet);
                        }

                        #endregion

                        #region Пользователь есть в БД - сравниваем

                        if (curentInstagram_db != null && curentInstagram_socialNet != null)
                        {
                            bool isNeedMerge_Followers = false;
                            bool isNeedMerge_Subscriptions = false;
                            foreach (string propName in propNameList.Where(item => !notUpdatePropNameList.Any(item2 => item2 == item)))
                            {
                                string oldValue = instance_values_db[propName] == null ? String.Empty : instance_values_db[propName];
                                string newValue = instance_values_socialNet[propName] == null ? String.Empty : instance_values_socialNet[propName];

                                if (!oldValue.Equals(newValue))
                                {
                                    AddHistory(curentInstagram_db.id, propName, oldValue, newValue, updateDate);

                                    if (propName.Equals("Followers"))
                                        isNeedMerge_Followers = true;
                                    else if (propName.Equals("Followings"))
                                        isNeedMerge_Subscriptions = true;
                                }
                            }
                            #region Если есть необходимость - обновляем данные БД Neo
                            List<UserInstagram> followers = null;
                            List<UserInstagram> subscriptions = null;
                            if (curentInstagram_socialNet.Followers != null && curentInstagram_db.Followers != null)
                                followers = curentInstagram_socialNet.Followers.Where(item => !curentInstagram_db.Followers.Any(item2 => item2.id == item.id)).ToList();
                            else if (curentInstagram_socialNet.Followers != null) followers = curentInstagram_socialNet.Followers.ToList();

                            if (curentInstagram_socialNet.Followings != null && curentInstagram_db.Followings != null)
                                subscriptions = curentInstagram_socialNet.Followings.Where(item => !curentInstagram_db.Followings.Any(item2 => item2.id == item.id)).ToList();
                            else if (curentInstagram_socialNet.Followings != null) subscriptions = curentInstagram_socialNet.Followings.ToList();


                            curentInstagram_socialNet.Followers = null;
                            curentInstagram_socialNet.Followings = null;

                            //обновляем текущего пользователя всегда, так как нужно записать новую ubdateDate
                            mapper.UpdateMerge(curentInstagram_socialNet);
                            if (isNeedMerge_Followers)
                            {
                                if (followers != null && followers.Count() > 0)
                                {
                                    mapper.Merge(followers);
                                    followersMapper.SaveInstagramFollowers(curentInstagram_socialNet.id, followers);
                                }
                            }

                            if (isNeedMerge_Subscriptions)
                            {
                                if (subscriptions != null && subscriptions.Count() > 0)
                                {
                                    mapper.Merge(subscriptions);
                                    followersMapper.SaveInstagramSubscriptions(curentInstagram_socialNet.id, subscriptions);
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }

                }
            }
        }

        /// <summary>
        /// Делает запрос к Instagram и возвращает экземпляр класса UserInstagram
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        static async Task<UserInstagram> FindUserInInstagramAsync(string path)
        {
            UserInstagramData userInstagram = null;
            try
            {
                HttpResponseMessage response = await client.GetAsync(path);
                if (response.IsSuccessStatusCode)
                {
                    userInstagram = await response.Content.ReadAsAsync<UserInstagramData>();
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка TSocialAPI.Updater.Instagram.Program.FindUserInInstagramAsync. Текст ошибки {0}", ex.ToString()));
            }
            if (userInstagram != null)
                return userInstagram.data;
            else return null;
        }

        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public static UserInstagram getLastValue()
        {
            UserInstagramMapper mapper = new UserInstagramMapper(Neo4jClientSource.CreateClient());
            UserInstagram oldestUser = mapper.FindOldestRecord();
            return oldestUser;
        }

        /// <summary>
        /// Заполняет список пар "атрибут"-"значение" для указанного пользователя
        /// </summary>
        /// <param name="props"></param>
        /// <param name="curentInstagram"></param>
        /// <param name="dic"></param>
        static void fillDictionaty(UserInstagram curentInstagram, ref Dictionary<string, string> dic)
        {
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentInstagram);
                if (attrValue != null)
                {
                    if (attrName.Equals("Followers"))
                    {
                        dic.Add(attrName, curentInstagram.Followers.Count().ToString());
                    }
                    else if (attrName.Equals("Followings"))
                    {
                        dic.Add(attrName, curentInstagram.Followings.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);//!!! TODO: Проверить значение 
            }
        }


        /// <summary>
        /// Добавляет запись истории изменений атрибута
        /// </summary>
        /// <param name="inst_id">id пользователя в instagram</param>
        /// <param name="propName">имя поля</param>
        /// <param name="oldValue">старое значение</param>
        /// <param name="newValue">новое значение</param>
        /// <param name="updateDate">дата обновления</param>
        static void AddHistory(long inst_id, string propName, string oldValue, string newValue, DateTime updateDate)
        {
            HistoryInstagram history = new HistoryInstagram();
            history.rid = Guid.NewGuid();
            history.id_user_instagram = inst_id;
            history.attribute_name = propName;
            history.old_value = oldValue;
            history.new_value = newValue;
            history.date_change = updateDate;
            MsSQLDataOperator.HistoryInstagramAdd(history);
        }

    }
}
