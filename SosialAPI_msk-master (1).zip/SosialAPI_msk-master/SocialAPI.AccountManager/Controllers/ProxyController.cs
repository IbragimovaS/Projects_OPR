﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialAPI.DataOperators;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;

namespace SocialAPI.AccountManager.Controllers
{
    /// <summary>
    /// Контроллер - список прокси
    /// </summary>
    public class ProxyController : Controller
    {
        /// <summary>
        /// Список прокси
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View(MsSQLDataOperator.ProxyGet());
        }

        /// <summary>
        /// Отображение формы создания прокси
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Создание аккаунта
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Proxy model)
        {
            try
            {
                model.is_good = true;
                model.last_usage = DateTime.Now;
                if (MsSQLDataOperator.ProxyAdd(model) == 0)
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction("Error", "Users");
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        /// Отображение формы удаления аккаунта
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public ActionResult Delete(Guid rid)
        {
            return View(MsSQLDataOperator.ProxyFind(rid));
        }

        /// <summary>
        /// Удаление аккаунта
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(Proxy model)
        {
            try
            {
                if (MsSQLDataOperator.ProxyRemove(model) == 0)
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction("Error", "Users");
            }
            catch
            {
                return View();
            }
        }
    }
}