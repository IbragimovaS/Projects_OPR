﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialAPI.DataOperators;
using SocialAPI.Models.MsSQL.AccountManager;

namespace SocialAPI.AccountManager.Controllers
{
    /// <summary>
    /// Контроллер - аккаунты Твиттер
    /// </summary>
    public class AccountTwitterController : Controller
    {
        /// <summary>
        /// Список аккаунтов
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View(MsSQLDataOperator.AccountsTwitterGet());
        }

        /// <summary>
        /// Отображение формы создания аккаунта
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Создание аккаунта
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AccountManagerTwitter model)
        {
            try
            {
                model.is_good = true;
                model.last_usage = DateTime.Now;
                if (MsSQLDataOperator.AccountAdd(model) == 0)
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction("Error", "Users");
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        /// Отображение формы удаления аккаунта
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        public ActionResult Delete(Guid rid)
        {
            return View(MsSQLDataOperator.AccountsTwitterFind(rid));
        }

        /// <summary>
        /// Удаление аккаунта
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(AccountManagerTwitter model)
        {
            try
            {
                if (MsSQLDataOperator.AccountRemove(model) == 0)
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction("Error", "Users");
            }
            catch
            {
                return View();
            }
        }
    }
}