﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialAPI.AccountManager.Models;
using SocialAPI.DataOperators;

namespace SocialAPI.AccountManager.Controllers
{
    /// <summary>
    /// Контроллер "Пользователи SocialAPI"
    /// </summary>
    public class UsersController : Controller
    {
        /// <summary>
        /// Отображение грида с пользователями
        /// </summary>
        /// <returns></returns>
        // GET: Users
        public ActionResult Index()
        {
            return View(MsSQLDataOperator.UsersGet());
        }

        /// <summary>
        /// Отображение формы создания пользователя
        /// </summary>
        /// <returns></returns>
        // GET: Users/Create
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Создание пользователя
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        // POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(SocialAPI.Models.MsSQL.User model)//(IFormCollection collection)
        {
            try
            {
                if (MsSQLDataOperator.UsersAdd(model) == 0)
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction(nameof(Error));
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        /// Отображение формы редактирования пользователя
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        // GET: Users/Edit/5
        public ActionResult Edit(Guid rid)
        {
            return View(MsSQLDataOperator.UsersFind(rid));
        }

        /// <summary>
        /// Редактирование пользователя
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        // POST: Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(SocialAPI.Models.MsSQL.User model)
        {
            try
            {
                if (MsSQLDataOperator.UsersUpdate(model) == 0) 
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction(nameof(Error));
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        /// Отображение формы удаления пользователя
        /// </summary>
        /// <param name="rid"></param>
        /// <returns></returns>
        // GET: Users/Delete/5
        public ActionResult Delete(Guid rid)
        {
            return View(MsSQLDataOperator.UsersFind(rid));
        }

        /// <summary>
        /// Удаление пользователя
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        // POST: Users/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(SocialAPI.Models.MsSQL.User model)
        {
            try
            {
                // TODO: Add delete logic here
                if (MsSQLDataOperator.UsersRemove(model) == 0)
                    return RedirectToAction(nameof(Index));
                else
                    return RedirectToAction(nameof(Error));
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        /// страница с ошибкой
        /// </summary>
        /// <returns></returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}