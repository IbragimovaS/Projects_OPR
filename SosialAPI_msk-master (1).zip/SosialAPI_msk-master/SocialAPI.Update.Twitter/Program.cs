﻿using SocialAPI.Mappers.Neo4j;
using System;
using SocialAPI.Models.SocialNetworks.Twitter;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using SocialAPI.DataOperators;
using SocialAPI.Connections;
using SocialAPI.Models.MsSQL.History;
using SocialAPI.Mappers.Neo4j.OK;
using System.Threading;
using SocialAPI.Mappers.Neo4j.Twitter;
using SocialAPI.Models.SocialNetworks;
using System.Diagnostics;
using SocialAPI.Models.MsSQL.AccountManager;

namespace SocialAPI.Updater.Twitter
{
    /// <summary>
    /// При настройке запуска приложения по времени,  необходимо открыть вкладку действия
    /// в поле "Программа или сценарий" ввести dotnet
    /// В поле "Добавить аргументы" прописать путь к SocialAPI.Updater.Twitter.dll
    /// C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\SocialAPI.Updater.Twitter.dll 07DD29FF-1BF8-48DA-0272-08D729F8DF1B 203 false
    /// При необходимости в поле "Рабочая папка" прописать путь к папке содержащей SocialAPI.Updater.Twitter.dll НАПРИМЕР - C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Служебное поле - массив полей Reflection
        /// </summary>
        public static PropertyInfo[] props;
        /// <summary>
        /// Служебное поле - массив наименований полей
        /// </summary>
        public static List<string> propNameList;
        /// <summary>
        /// Как в АПИ - количество подписчиков (друзья получаются все)
        /// </summary>
        public static int count;

        /// <summary>
        /// Токен для доступа к БД
        /// </summary>
        public static Guid user_token;

        /// <summary>
        /// Как в АПИ - быстрое получение подписчиков (получаются только идентификаторы подписчиков, если true - параметр count игнорируется)
        /// </summary>
        public static bool fast_followers;

        /// <summary>
        /// Признак запуска обновления данных
        /// </summary>
        public static bool isRuning;

        static void Main(string[] args)
        {
            MsSQLDataOperator.ParseArgs(args, ref user_token, ref count);

            if (3 <= args.Length)
                bool.TryParse(args[2], out fast_followers);

            Init(user_token, count, fast_followers);

            Run();
        }

        /// <summary>
        /// Инициализация всех установок
        /// </summary>
        public static void Init(Guid usr_token, int cnt, bool fastF)
        {
            Type t = (typeof(UserTwitter));

            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            fast_followers = fastF;
        }

        /// <summary>
        /// Основная процедура
        /// </summary>
        public static void Run()
        {
            AccountManagerTwitter twitterAccount = null;
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                if (currentUser == null)
                {
                    throw new Exception("Для пользователя user_token = \"" + user_token.ToString() + "\" не выполнен вход.");
                }
                twitterAccount = MsSQLDataOperator.GetGoodAccountTwitter();//получаем токен twitter
                using (UserTwitterMapper mapper = new UserTwitterMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsTwitterMapper friendsMapper = new FriendsTwitterMapper(Neo4jClientSource.CreateClient()))
                    {
                        using (FollowersTwitterMapper followersMapper = new FollowersTwitterMapper(Neo4jClientSource.CreateClient()))
                        {
                            while (isRuning)
                            {

                                Dictionary<string, string> instance_values_db = new Dictionary<string, string>();
                                Dictionary<string, string> instance_values_socialNet = new Dictionary<string, string>();
                                UserTwitter curentTwitter_db = getLastValue();
                                UserTwitter curentTwitter_socialNet = null;

                                if (curentTwitter_db == null) //Если в базе отсутствует запись т ждем 5 минут 
                                {
                                    Thread.Sleep(5000 * 60);
                                    continue;
                                }

                                #region Получение данных из БД
                                if (curentTwitter_db != null)
                                {

                                    curentTwitter_db.Friends = friendsMapper.GetFriends(curentTwitter_db).ToList();
                                    curentTwitter_db.Followers = followersMapper.GetFollowers(curentTwitter_db).ToList();
                                    fillDictionaty(curentTwitter_db, ref instance_values_db);
                                }

                                #endregion

                                #region Получение данных из социальной сети

                                var getData = TwitterConnection.getTwitterUsers(curentTwitter_db.screen_name, ref twitterAccount);

                                if (getData == null || getData.Count() == 0)
                                    throw new Exception("Запрос по странице id = \"" + curentTwitter_db.screen_name + "\" не вернул результат.");
                                curentTwitter_socialNet = getData.First();
                                DateTime updateDate = DateTime.Now;
                                if (curentTwitter_socialNet != null)
                                {
                                    curentTwitter_socialNet.updateDate = updateDate;
                                    var friends = TwitterConnection.getTwitterFriends(curentTwitter_db, ref twitterAccount);
                                    if (friends != null && friends.Count > 0)
                                    {
                                        curentTwitter_socialNet.Friends = friends;
                                        MsSQLDataOperator.SetUpdateDate(curentTwitter_socialNet.Friends.ToList<AbstractUser>(), updateDate);
                                    }
                                    List<UserTwitter> followers = null;
                                    if (fast_followers)
                                    {
                                        var ids = TwitterConnection.getTwitterFollowersIDs(curentTwitter_socialNet, ref twitterAccount);
                                        if (ids != null && ids.Count() > 0)
                                        {
                                            followers = ids.Select(x => new UserTwitter { id = x }).ToList();
                                        }
                                    }
                                    else
                                    {
                                        followers = TwitterConnection.getTwitterFollowers(curentTwitter_socialNet, ref twitterAccount, count);
                                    }
                                    if (followers != null && followers.Count > 0)
                                    {
                                        curentTwitter_socialNet.Followers = followers;
                                        MsSQLDataOperator.SetUpdateDate(curentTwitter_socialNet.Followers.ToList<AbstractUser>(), updateDate);
                                    }
                                    fillDictionaty(curentTwitter_socialNet, ref instance_values_socialNet);
                                }

                                #endregion

                                #region Пользователь есть в БД - сравниваем

                                if (curentTwitter_db != null && curentTwitter_socialNet != null)
                                {
                                    bool isNeedMerge_Friends = false;
                                    bool isNeedMerge_Followers = false;
                                    foreach (string propName in propNameList)
                                    {
                                        string oldValue = instance_values_db[propName] == null ? String.Empty : instance_values_db[propName];
                                        string newValue = instance_values_socialNet[propName] == null ? String.Empty : instance_values_socialNet[propName];

                                        if (!oldValue.Equals(newValue))
                                        {
                                            AddHistory(curentTwitter_db.id, propName, oldValue, newValue, updateDate);

                                            if (propName.Equals("Friends"))
                                                isNeedMerge_Friends = true;
                                            else if (propName.Equals("Followers"))
                                                isNeedMerge_Followers = true;
                                        }
                                    }
                                    #region Если есть необходимость - обновляем данные БД Neo
                                    List<UserTwitter> friends = null;
                                    List<UserTwitter> followers = null;
                                    if (curentTwitter_socialNet.Friends != null && curentTwitter_db.Friends != null)
                                        friends = curentTwitter_socialNet.Friends.Where(item => !curentTwitter_db.Friends.Any(item2 => item2.id == item.id)).ToList();
                                    else if (curentTwitter_socialNet.Friends != null) friends = curentTwitter_socialNet.Friends.ToList();

                                    if (curentTwitter_socialNet.Followers != null && curentTwitter_db.Followers != null)
                                        followers = curentTwitter_socialNet.Followers.Where(item => !curentTwitter_db.Followers.Any(item2 => item2.id == item.id)).ToList();
                                    else if (curentTwitter_socialNet.Followers != null) followers = curentTwitter_socialNet.Followers.ToList();


                                    curentTwitter_socialNet.Friends = null;
                                    curentTwitter_socialNet.Followers = null;

                                    //обновляем текущего пользователя всегда, так как нужно записать новую ubdateDate в neo4j
                                    mapper.UpdateMerge(curentTwitter_socialNet);
                                    if (isNeedMerge_Friends)
                                    {
                                        if (friends != null && friends.Count() > 0)
                                        {
                                            mapper.Merge(friends);
                                            friendsMapper.SaveTwitterFriend(curentTwitter_socialNet.id, friends);
                                        }
                                    }
                                    if (isNeedMerge_Followers)
                                    {
                                        if (followers != null && followers.Count() > 0)
                                        {
                                            mapper.Merge(followers);
                                            followersMapper.SaveTwitterFollowers(curentTwitter_socialNet.id, followers);
                                        }
                                    }
                                    #endregion
                                }
                                #endregion
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Updater.Twitter.Run. Текст ошибки {0}", ex.ToString()));
            }
            finally
            {
                if (twitterAccount != null)
                {
                    MsSQLDataOperator.AccountTwitterSetIsUsed(twitterAccount, false); //устанавливаем для теущего аккаунта признак - неиспользуется
                }
            }
        }

       
        ///// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public static UserTwitter getLastValue()
        {
            UserTwitterMapper mapper = new UserTwitterMapper(Neo4jClientSource.CreateClient());
            UserTwitter oldestUser = mapper.FindOldestRecord();
            return oldestUser;
        }

        /// <summary>
        /// Заполняет список пар "атрибут"-"значение" для указанного пользователя
        /// </summary>
        /// <param name="props"></param>
        /// <param name="curentTwitter"></param>
        /// <param name="dic"></param>
        static void fillDictionaty(UserTwitter curentTwitter, ref Dictionary<string, string> dic)
        {
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentTwitter);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentTwitter.Friends.Count().ToString());
                    }
                    else if (attrName.Equals("Followers"))
                    {
                        dic.Add(attrName, curentTwitter.Followers.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);//!!! TODO: Проверить значение 
            }
        }

        /// <summary>
        /// Добавляет запись истории изменений атрибута
        /// </summary>
        /// <param name="tw_id">id пользователя twitter</param>
        /// <param name="propName">имя поля</param>
        /// <param name="oldValue">старое значение</param>
        /// <param name="newValue">новое значение</param>
        /// <param name="updateDate">дата обновления</param>
        static void AddHistory(long tw_id, string propName, string oldValue, string newValue,DateTime updateDate)
        {
            HistoryTwitter history = new HistoryTwitter();
            history.rid = Guid.NewGuid();
            history.id_user_twitter = tw_id;
            history.attribute_name = propName;
            history.old_value = oldValue;
            history.new_value = newValue;
            history.date_change = updateDate;
            MsSQLDataOperator.HistoryTwitterAdd(history);
        }

    }
}
