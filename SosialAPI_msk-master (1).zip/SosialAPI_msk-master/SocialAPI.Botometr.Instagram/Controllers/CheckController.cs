﻿using Microsoft.AspNetCore.Mvc;
using SocialAPI.Connections;
using SocialAPI.DataOperators;
using SocialAPIML.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SocialAPI.Botometr.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CheckController : ControllerBase
    {
        // GET: api/Users
        [HttpGet]
        public GenericResponse<BotResponse> Get()
        {
            return new GenericResponse<BotResponse>("не реализовано");
        }

        // GET: api/Check/CheckBot?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&usernames=1;2
        [HttpGet("CheckBot")]
        public GenericResponse<List<BotResponse>> CheckBot(Guid user_token, string usernames)
        {
            GenericResponse<List<BotResponse>> response;
            List<BotResponse> result = new List<BotResponse>();
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                if (currentUser == null)
                {
                    return new GenericResponse<List<BotResponse>>("доступ запрещен");
                }

                if (usernames.Split(';').Count() > 10)
                    return new GenericResponse<List<BotResponse>>("the number of identifiers can not be more than 10");

                foreach (var item in usernames.Split(';'))
                {
                    result.Add(GetInstagramBotResponse(item));
                }

                response = new GenericResponse<List<BotResponse>>(result);
            }
            catch (Exception ex)
            {
                response = new GenericResponse<List<BotResponse>>(ex.Message);
            }
            
            return response;
        }

        /// <summary>
        /// Получить ответ - бот или не бот
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private static BotResponse GetInstagramBotResponse(string username)
        {
            var proxy = MsSQLDataOperator.GetGoodProxy();
            if (proxy == null)
                return null;

            //получить данные из Instagram
            var profile = InstagramConnection.GetInstagramUser(username, ref proxy);
           
            //преобразовать в модель для анализа
            var input = InstagramConnection.GetModelInput(profile);

            // Load model and predict output of sample data
            ModelOutput result = ConsumeModel.Predict(input);

            return new BotResponse { username = username, isBot = result.Prediction };
        }
    }
}
