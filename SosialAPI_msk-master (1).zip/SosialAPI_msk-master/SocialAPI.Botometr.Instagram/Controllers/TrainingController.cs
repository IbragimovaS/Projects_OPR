﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SocialAPI.Connections;
using SocialAPI.DataOperators;
using System.IO;

namespace SocialAPI.Botometr.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainingController : ControllerBase
    {
        /// <summary>
        /// Добавить данные к обучающей выборке
        /// </summary>
        /// <param name="user_token">токен пользователя сервиса SocialAPI</param>
        /// <param name="usernames">имя пользователя</param>
        /// <param name="is_bot">признака того, что бот</param>
        /// <param name="password">пароль</param>
        /// <returns></returns>
        [HttpGet("Insertinstagram")]
        public GenericResponse<Enum> Insertinstagram(Guid user_token, string usernames, bool is_bot, string password)
        {
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                if (currentUser == null)
                {
                    return new GenericResponse<Enum>("доступ запрещен");
                }

                if (password == "wwFdm2")
                {
                    if (usernames.Split(';').Count() > 10)
                        return new GenericResponse<Enum>("the number of identifiers can not be more than 10");
                    foreach (var name in usernames.Split(';'))
                    {
                        processID(name, is_bot);
                    }
                }
                else
                {
                    return new GenericResponse<Enum>("incorrect password");
                }
            }
            catch (Exception ex)
            {
                return new GenericResponse<Enum>(ex.Message);
            }
            return new GenericResponse<Enum>(HttpStatusCode.OK);

        }

        /// <summary>
        /// Обработать данные
        /// </summary>
        /// <param name="item"></param>
        /// <param name="is_bot"></param>
        /// <param name="vk_token"></param>
        private void processID(string item, bool is_bot, int count = 0)
        {
            var proxy = MsSQLDataOperator.GetGoodProxy();
            if (proxy == null)
                return;
            //получить данные из Instagram
            var profile = InstagramConnection.GetInstagramUser(item, ref proxy);
            if(proxy.is_good == false)
            {
                MsSQLDataOperator.ProxySetBad(proxy);
                processID(item, is_bot);
            }
            if (profile != null && proxy.is_good == true)
            {
                //преобразовать в модель для БД
                var model = InstagramConnection.GetModelInputForTraining(profile, is_bot);

                //записать в БД
                MsSQLDataOperator.WriteToDBBotometrTrainingSet(model);
                System.IO.File.AppendAllLines(@"C:\test\BotsSetLoaded.txt", new List<string>().Append(item));
            }
            else if(profile == null && proxy.is_good == true)
                System.IO.File.AppendAllLines(@"C:\test\BotsSet404.txt", new List<string>().Append(item));



        }
    }
}
