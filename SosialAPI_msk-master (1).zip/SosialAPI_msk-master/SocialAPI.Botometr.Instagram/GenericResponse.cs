﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SocialAPI.Botometr
{
    /// <summary>
    /// Класс общего ответа сервера
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class GenericResponse<T>
    {
        private GenericResponse() { }

        public GenericResponse(T data)
        {
            this.Data = data;
            this.Error = null;
        }

        public GenericResponse(string errorMessage)
        {
            this.Data = default(T);
            this.Error = errorMessage;
        }

        public T Data { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Error { get; set; }
    }
}
