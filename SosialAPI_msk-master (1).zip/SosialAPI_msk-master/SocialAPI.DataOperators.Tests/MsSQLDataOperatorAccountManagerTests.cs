﻿using NUnit.Framework;
using SocialAPI.Models.MsSQL.AccountManager;
using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.DataOperators.Tests
{
    /// <summary>
    /// Класс для тестирования операций чтения-записи по параметрам подключения в соц сети
    /// </summary>
    public class MsSQLDataOperatorAccountManagerTests
    {
        /// <summary>
        /// Чтение-запись данных из таблицы с учетками Фейсбук
        /// </summary>
        [Test]
        public void Test1()
        {
            AccountManagerFacebook model = new AccountManagerFacebook
            {
                is_good = true,
                last_usage = System.Data.SqlTypes.SqlDateTime.MinValue.Value,
                rid = Guid.NewGuid(),
                user_name = "test user",
                user_password = "test password"
            };

            Assert.AreEqual(0, MsSQLDataOperator.AccountAdd(model));

            Assert.IsTrue(MsSQLDataOperator.AccountsFacebookGoodGet().Count > 0);            

            Assert.AreEqual(0, MsSQLDataOperator.AccountRemove(model));
        }

        /// <summary>
        /// Чтение-запись данных из таблицы с учетками Инстаграмм
        /// </summary>
        [Test]
        public void Test2()
        {
            AccountManagerInstagram model = new AccountManagerInstagram
            {
                is_good = true,
                last_usage = System.Data.SqlTypes.SqlDateTime.MinValue.Value,
                rid = Guid.NewGuid(),
                user_name = "test user",
                user_password = "test password"
            };

            Assert.AreEqual(0, MsSQLDataOperator.AccountAdd(model));

            Assert.IsTrue(MsSQLDataOperator.AccountsInstagramGet().Count > 0);

            Assert.AreEqual(0, MsSQLDataOperator.AccountRemove(model));
        }

        /// <summary>
        /// Чтение-запись данных из таблицы с учетками Одноклассники
        /// </summary>
        [Test]
        public void Test3()
        {
            AccountManagerOK model = new AccountManagerOK
            {
                is_good = true,
                last_usage = System.Data.SqlTypes.SqlDateTime.MinValue.Value,
                rid = Guid.NewGuid(),
                token = "test token"
            };

            Assert.AreEqual(0, MsSQLDataOperator.AccountAdd(model));

            Assert.IsTrue(MsSQLDataOperator.AccountsOKGet().Count > 0);

            Assert.AreEqual(0, MsSQLDataOperator.AccountRemove(model));
        }

        /// <summary>
        /// Чтение-запись данных из таблицы с учетками Твиттер
        /// </summary>
        [Test]
        public void Test4()
        {
            AccountManagerTwitter model = new AccountManagerTwitter
            {
                is_good = true,
                last_usage = System.Data.SqlTypes.SqlDateTime.MinValue.Value,
                rid = Guid.NewGuid(),
                access_token = "test token"
            };

            Assert.AreEqual(0, MsSQLDataOperator.AccountAdd(model));

            Assert.IsTrue(MsSQLDataOperator.AccountsTwitterGet().Count > 0);

            Assert.AreEqual(0, MsSQLDataOperator.AccountRemove(model));
        }

        /// <summary>
        /// Чтение-запись данных из таблицы с учетками ВКонтакте
        /// </summary>
        [Test]
        public void Test5()
        {
            AccountManagerVK model = new AccountManagerVK
            {
                is_good = true,
                last_usage = System.Data.SqlTypes.SqlDateTime.MinValue.Value,
                rid = Guid.NewGuid(),
                token = "test token"
            };

            Assert.AreEqual(0, MsSQLDataOperator.AccountAdd(model));

            Assert.IsTrue(MsSQLDataOperator.AccountsVKGet().Count > 0);

            Assert.AreEqual(0, MsSQLDataOperator.AccountRemove(model));
        }
    }
}
