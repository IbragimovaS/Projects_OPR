﻿using NUnit.Framework;
using SocialAPI.Models.MsSQL;
using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.DataOperators.Tests
{
    /// <summary>
    /// Класс для тестирования операций чтения-записи по пользователям SocialAPI
    /// </summary>
    public class MsSQLDataOperatorUsersTests
    {
        User user;

        [SetUp]
        public void Setup()
        {
            user = new User
            {
                allowed_count = 50,
                allowed_from = DateTime.Now,
                allowed_to = DateTime.Now,
                current_count = 11,
                rid = new Guid(),
                user_name = "test user",
                user_org = "тестовая организация"
            };
        }

        [Test]
        public void Test1()
        {
            Assert.AreEqual(0, MsSQLDataOperator.UsersAdd(user));

            Assert.IsTrue(MsSQLDataOperator.UsersGet().Count > 0);

            user.allowed_count = 55;
            user.current_count = 1;
            user.user_name = "test user 1";
            user.user_org = "тестовая организация1";
            Assert.AreEqual(0, MsSQLDataOperator.UsersUpdate(user));

            Assert.AreEqual(0, MsSQLDataOperator.UsersRemove(user));
        }

    }
}
