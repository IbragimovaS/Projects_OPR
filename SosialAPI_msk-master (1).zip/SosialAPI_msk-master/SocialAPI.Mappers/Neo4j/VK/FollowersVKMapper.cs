﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.VK
{
    /// <summary>
    /// Класс для работы с подписчиками в Neo4j
    /// </summary>
    public class FollowersVKMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public FollowersVKMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Сохранить подписки ВКонтакте
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveVKSubscriptions(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserVK)", "(user2:UserVK)")
                .Where((UserVK user1) => user1.id == id1)
                .AndWhere((UserVK user2) => user2.id == id2)
                .CreateUnique("(user1)-[:Follower]->(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписки ВКонтакте
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveVKSubscriptions(long id1, IEnumerable<UserVK> fUsers)
        {
            var newData = fUsers.First().updateDate;

            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });

            Client.Cypher
               .Unwind(fUsers, "users")
               .Match("(user1:UserVK)", "(user2:UserVK {id: users.id})")
               .Where((UserVK user1) => user1.id == id1)
               .Merge("(user1)-[rel:Follower]->(user2)")
             .OnCreate()
              .Set("rel.updateDate = {dat}")
               .WithParam("dat", newData)
               .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков ВКонтакте
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveVKFollowers(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserVK)", "(user2:UserVK)")
                .Where((UserVK user1) => user1.id == id1)
                .AndWhere((UserVK user2) => user2.id == id2)
                .CreateUnique("(user1)<-[:Follower]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков ВКонтакте
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveVKFollowers(long id1, IEnumerable<UserVK> fUsers)
        {
            var newData = fUsers.First().updateDate;
            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });
            //Client.Cypher
            //    .Unwind(fUsers, "users")
            //    .Match("(user1:UserVK)", "(user2:UserVK {id: users.id})")
            //    .Where((UserVK user1) => user1.id == id1)
            //    .CreateUnique("(user1)<-[:Follower {updateDate:'" + fUsers.First().updateDate + "'}]-(user2)")
            //    .ExecuteWithoutResults();

            Client.Cypher
               .Unwind(fUsers, "users")
               .Match("(user1:UserVK)", "(user2:UserVK {id: users.id})")
               .Where((UserVK user1) => user1.id == id1)
               .Merge("(user1)<-[rel:Follower]-(user2)")
             .OnCreate()
              .Set("rel.updateDate = {dat}")
               .WithParam("dat", newData)
               //.CreateUnique("(user1)-[:Friends {updateDate:'" + fUsers.First().updateDate + "'}]-(user2)")
               .ExecuteWithoutResults();
        }

        /// <summary>
        /// /Получить подписчиков ВКонтакте
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserVK> GetFollowers(UserVK model)
        {
            return GetFollowers(model.id);
        }

        /// <summary>
        /// Получить подписчиков ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserVK> GetFollowers(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserVK)<-[:Follower]-(user2:UserVK)")
            .Where((UserVK user1) => user1.id == id)
            .Return((user2) => user2.As<UserVK>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserVK>();
            return res;
        }

        /// <summary>
        /// /Получить подписчиков ВКонтакте
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserVK> GetSubscriptions(UserVK model)
        {
            return GetSubscriptions(model.id);
        }

        /// <summary>
        /// Получить подписчиков ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserVK> GetSubscriptions(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserVK)-[:Follower]->(user2:UserVK)")
            .Where((UserVK user1) => user1.id == id)
            .Return((user2) => user2.As<UserVK>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserVK>();
            return res;
        }
    }
}
