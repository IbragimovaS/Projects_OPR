﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.VK
{
    /// <summary>
    /// Класс для работы с пользователями ВК в БД Neo4j
    /// </summary>
    public class UserVKMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="sesssion"></param>
        public UserVKMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Найти по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserVK Find(long id)
        {
            try
            {
                var results = Client.Cypher
                   .Match("(userVK:UserVK)")
                   .Where((UserVK userVK) => userVK.id == id)
                   .Return(userVK => userVK.As<UserVK>())
                   .Results;
                if (results.Count() > 0)
                    return results.First();
                else return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Найти по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserVK FindByName(string name)
        {
            try
            {
                var page = @"https://vk.com/" + name;
                return Client.Cypher
                   .Match("(userVK:UserVK)")
                   .Where((UserVK userVK) => userVK.page == page)
                   .Return(userVK => userVK.As<UserVK>())
                   .Results.First();
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void Merge(UserVK newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userVK:UserVK { id: {id} })")
                //.OnCreate()
                .Set("userVK = {userVK}")
                .WithParams(new
                {
                    id = newModel.id,
                    userVK = newModel
                })
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Добавить список пользователей
        /// </summary>
        /// <param name="users"></param>
        public void Merge(IEnumerable<UserVK> users)
        {
            users = users.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(users, "UserVK")
                .Merge("(n:UserVK { id: UserVK.id })")
                .OnCreate()
                .Set("n = UserVK")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void UpdateMerge(UserVK newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userVK:UserVK { id: {id} })")
                .Set("userVK = {userVK}")
                .WithParams(new
                {
                    id = newModel.id,
                    userVK = newModel
                })
                .ExecuteWithoutResults();
        }
    }
}
