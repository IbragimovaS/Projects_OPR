﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.VK
{
    /// <summary>
    /// Класс для работы с друзьями ВК в бд neo4j
    /// </summary>
    public class FriendsVKMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public FriendsVKMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Сохранить друзей ВКонтакте
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveVKFriend(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserVK)", "(user2:UserVK)")
                .Where((UserVK user1) => user1.id == id1)
                .AndWhere((UserVK user2) => user2.id == id2)
                .CreateUnique("(user1)-[:Friends]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить друзей ВКонтакте
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="fUsers"></param>
        public void SaveVKFriend(long id1, IEnumerable<UserVK> fUsers)
        {
            var newData = fUsers.First().updateDate;

            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(fUsers, "users")
                .Match("(user1:UserVK)", "(user2:UserVK {id: users.id})")
                .Where((UserVK user1) => user1.id == id1)
                .Merge("(user1)-[rel:Friends]-(user2)")
              .OnCreate()
               .Set("rel.updateDate = {dat}")
                .WithParam("dat", newData)
                .ExecuteWithoutResults();
        }    

        /// <summary>
        /// /Получить друзей ВКонтакте
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserVK> GetFriends(UserVK model)
        {
            return GetFriends(model.id);
        }

        /// <summary>
        /// Получить друзей ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserVK> GetFriends(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserVK)-[:Friends]-(user2:UserVK)")
            .Where((UserVK user1) => user1.id == id)
            .Return((user2) => user2.As<UserVK>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserVK>();
            return res;
        }
    }
}
