﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.Instagram;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SocialAPI.Mappers.Neo4j.Instagram
{
    public class UserInstagramMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="sesssion"></param>
        public UserInstagramMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Найти по идентификатору
        /// </summary>
        /// <param name="id">идентификатор пользователя</param>
        /// <returns></returns>
        public UserInstagram Find(string id)
        {
            try
            {
                var results = Client.Cypher
                   .Match("(userInstagram:UserInstagram)")
                   .Where((UserInstagram userInstagram) => userInstagram.username == id)
                   .Return(userInstagram => userInstagram.As<UserInstagram>())
                   .Results;
                if (results.Count() > 0)
                    return results.First();
                else return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void Merge(UserInstagram newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userInstagram:UserInstagram { id: {id} })")
                //.OnCreate()
                .Set("userInstagram = {userInstagram}")
                .WithParams(new
                {
                    id = newModel.id,
                    userInstagram = newModel
                })
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Добавить список пользователей
        /// </summary>
        /// <param name="users"></param>
        public void Merge(IEnumerable<UserInstagram> users)
        {
            users = users.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(users, "UserInstagram")
                .Merge("(n:UserInstagram { id: UserInstagram.id })")
                .OnCreate()
                .Set("n = UserInstagram")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public UserInstagram FindOldestRecord()
        {
            return Client.Cypher
          .Match("(userInstagram:UserInstagram)")
          .With("min(userInstagram.updateDate) as update_date")
          .Match("(userInstagram2:UserInstagram{ updateDate: update_date})")
          .Return(userInstagram2 => userInstagram2.As<UserInstagram>())
          .Results.First();
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void UpdateMerge(UserInstagram newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userInstagram:UserInstagram { id: {id} })")
                .Set("userInstagram = {userInstagram}")
                .WithParams(new
                {
                    id = newModel.id,
                    userInstagram = newModel
                })
                .ExecuteWithoutResults();
        }
    }
}
