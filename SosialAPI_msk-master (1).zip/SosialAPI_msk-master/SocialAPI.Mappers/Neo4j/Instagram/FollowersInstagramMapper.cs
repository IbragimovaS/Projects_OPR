﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.Instagram;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.Instagram
{
    /// <summary>
    /// Класс для работы с подписчиками в Neo4j
    /// </summary>
    public class FollowersInstagramMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public FollowersInstagramMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Сохранить подписки Instagram
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveInstagramSubscriptions(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserInstagram)", "(user2:UserInstagram)")
                .Where((UserInstagram user1) => user1.id == id1)
                .AndWhere((UserInstagram user2) => user2.id == id2)
                .CreateUnique("(user1)-[:Follower]->(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписки Instagram
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveInstagramSubscriptions(long id1, IEnumerable<UserInstagram> fUsers)
        {
            var newData = fUsers.First().updateDate;

            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });

            Client.Cypher
               .Unwind(fUsers, "users")
               .Match("(user1:UserInstagram)", "(user2:UserInstagram {id: users.id})")
               .Where((UserInstagram user1) => user1.id == id1)
               .Merge("(user1)-[rel:Follower]->(user2)")
             .OnCreate()
              .Set("rel.updateDate = {dat}")
               .WithParam("dat", newData)
               .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков Instagram
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveInstagramFollowers(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserInstagram)", "(user2:UserInstagram)")
                .Where((UserInstagram user1) => user1.id == id1)
                .AndWhere((UserInstagram user2) => user2.id == id2)
                .CreateUnique("(user1)<-[:Follower]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков Instagram
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveInstagramFollowers(long id1, IEnumerable<UserInstagram> fUsers)
        {
            var newData = fUsers.First().updateDate;

            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });

            Client.Cypher
               .Unwind(fUsers, "users")
               .Match("(user1:UserInstagram)", "(user2:UserInstagram {id: users.id})")
               .Where((UserInstagram user1) => user1.id == id1)
               .Merge("(user1)<-[rel:Follower]-(user2)")
             .OnCreate()
              .Set("rel.updateDate = {dat}")
               .WithParam("dat", newData)
               .ExecuteWithoutResults();
        }

        /// <summary>
        /// /Получить подписчиков Instagram
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserInstagram> GetFollowers(UserInstagram model)
        {
            return GetFollowers(model.id);
        }

        /// <summary>
        /// Получить подписчиков Instagram
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserInstagram> GetFollowers(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserInstagram)<-[:Follower]-(user2:UserInstagram)")
            .Where((UserInstagram user1) => user1.id == id)
            .Return((user2) => user2.As<UserInstagram>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserInstagram>();
            return res;
        }

        /// <summary>
        /// /Получить подписчиков Instagram
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserInstagram> GetSubscriptions(UserInstagram model)
        {
            return GetSubscriptions(model.id);
        }

        /// <summary>
        /// Получить подписчиков Instagram
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserInstagram> GetSubscriptions(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserInstagram)-[:Follower]->(user2:UserInstagram)")
            .Where((UserInstagram user1) => user1.id == id)
            .Return((user2) => user2.As<UserInstagram>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserInstagram>();
            return res;
        }
    }
}
