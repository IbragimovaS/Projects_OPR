﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.OK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.OK
{
    /// <summary>
    /// Класс для работы с подписчиками в Neo4j
    /// </summary>
    public class FollowersOKMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public FollowersOKMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Сохранить подписки OK
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveOKSubscriptions(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserOK)", "(user2:UserOK)")
                .Where((UserOK user1) => user1.uid == id1)
                .AndWhere((UserOK user2) => user2.uid == id2)
                .CreateUnique("(user1)-[:Follower]->(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписки OK
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveOKSubscriptions(long id1, IEnumerable<UserOK> fUsers)
        {
            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(fUsers, "users")
                .Match("(user1:UserOK)", "(user2:UserOK {uid: users.uid})")
                .Where((UserOK user1) => user1.uid == id1)
                .CreateUnique("(user1)-[:Follower {updateDate:'" + fUsers.First().updateDate + "'}]->(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков OK
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveOKFollowers(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserOK)", "(user2:UserOK)")
                .Where((UserOK user1) => user1.uid == id1)
                .AndWhere((UserOK user2) => user2.uid == id2)
                .CreateUnique("(user1)<-[:Follower]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков OK
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveOKFollowers(long id1, IEnumerable<UserOK> fUsers)
        {
            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(fUsers, "users")
                .Match("(user1:UserOK)", "(user2:UserOK {uid: users.uid})")
                .Where((UserOK user1) => user1.uid == id1)
                .CreateUnique("(user1)<-[:Follower {updateDate:'" + fUsers.First().updateDate + "'}]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// /Получить подписчиков OK
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserOK> GetFollowers(UserOK model)
        {
            return GetFollowers(model.uid);
        }

        /// <summary>
        /// Получить подписчиков OK
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserOK> GetFollowers(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserOK)<-[:Follower]-(user2:UserOK)")
            .Where((UserOK user1) => user1.uid == id)
            .Return((user2) => user2.As<UserOK>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserOK>();
            return res;
        }

        /// <summary>
        /// /Получить подписчиков ОК
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserOK> GetSubscriptions(UserOK model)
        {
            return GetSubscriptions(model.uid);
        }

        /// <summary>
        /// Получить подписчиков Instagram
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserOK> GetSubscriptions(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserInstagram)-[:Follower]->(user2:UserInstagram)")
            .Where((UserOK user1) => user1.uid == id)
            .Return((user2) => user2.As<UserOK>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserOK>();
            return res;
        }
    }
}
