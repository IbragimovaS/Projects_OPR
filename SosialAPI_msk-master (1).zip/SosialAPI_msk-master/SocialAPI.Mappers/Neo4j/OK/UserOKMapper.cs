﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.OK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.OK
{
    /// <summary>
    /// Класс для работы с пользователями OK в БД Neo4j
    /// </summary>
    public class UserOKMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="sesssion"></param>
        public UserOKMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Найти по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserOK Find(long id)
        {
            try
            {
                var results = Client.Cypher
                   .Match("(userOK:UserOK)")
                   .Where((UserOK userOK) => userOK.uid == id)
                   .Return(userOK => userOK.As<UserOK>())
                   .Results;
                if (results.Count() > 0)
                    return results.First();
                else return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void Merge(UserOK newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userOK:UserOK { uid: {uid} })")
                //.OnCreate()
                .Set("userOK = {userOK}")
                .WithParams(new
                {
                    uid = newModel.uid,

                    userOK = newModel
                })
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Добавить список пользователей
        /// </summary>
        /// <param name="users"></param>
        public void Merge(IEnumerable<UserOK> users)
        {
            users = users.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(users, "UserOK")
                .Merge("(n:UserOK { uid: UserOK.uid })")
                .OnCreate()
                .Set("n = UserOK")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public UserOK FindOldestRecord()
        {
                 return Client.Cypher
               .Match("(userOK:UserOK)")
               .With("min(userOK.updateDate) as update_date")
               .Match("(userOK2:UserOK{ updateDate: update_date})")
               .Return(userOK2 => userOK2.As<UserOK>())
               .Results.First();
        }

        /// <summary>
        /// Обновляет данные о пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void UpdateMerge(UserOK newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userOK:UserOK { uid: {uid} })")
                .Set("userOK = {userOK}")
                .WithParams(new
                {
                    uid = newModel.uid,

                    userOK = newModel
                })
                .ExecuteWithoutResults();
        }

    }
}
