﻿using Neo4jClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;

namespace SocialAPI.Mappers.Neo4j
{
    /// <summary>
    /// Класс для получения клиента для взаимодействия с БД
    /// </summary>
    public static class Neo4jClientSource
    {
        /// <summary>
        /// Строка подключения
        /// </summary>
        static string ClientString
        {
            get
            {
                //return "http://localhost:7474/db/data";
                return "http://192.168.252.131:7474/db/data";
            }
        }

        static GraphClient _client;

        /// <summary>
        /// Получить клиента для взаимодействия с БД
        /// </summary>
        /// <returns></returns>
        public static GraphClient CreateClient()
        {
            if (_client == null)
                _client = new GraphClient(new Uri(ClientString),
                    new HttpClientWrapper(
                    new HttpClient() { Timeout = TimeSpan.FromMinutes(30) }));
            if (!_client.IsConnected)
                _client.Connect();
            return _client;
        }
    }
}
