﻿using Neo4jClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Mappers.Neo4j
{
    /// <summary>
    /// Абстрактный класс для взаимодействия с БД
    /// </summary>
    public abstract class Repository : IDisposable
    {
        GraphClient client;

        /// <summary>
        /// Клиент Neo4j
        /// </summary>
        public GraphClient Client
        {
            get { return client; }
            set { client = value; }
        }

        public void Dispose()
        {
            if (client != null)
            {
                client.Dispose();
                client = null;
            }
        }

        public void Delete(object model)
        {
            Client.Delete((NodeReference)model, DeleteMode.NodeAndRelationships);
        }
    }
}
