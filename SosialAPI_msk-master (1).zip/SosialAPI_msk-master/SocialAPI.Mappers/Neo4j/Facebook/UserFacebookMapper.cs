﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.Facebook;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SocialAPI.Mappers.Neo4j.Facebook
{
    public class UserFacebookMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="sesssion"></param>
        public UserFacebookMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Найти по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserFacebook Find(string Page)
        {
            try
            {
                var results = Client.Cypher
                   .Match("(userFacebook:UserFacebook)")
                   .Where((UserFacebook userFacebook) => userFacebook.Page == Page)
                   .Return(userFacebook => userFacebook.As<UserFacebook>())
                   .Results;
                if (results.Count() > 0)
                    return results.First();
                else return null;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void Merge(UserFacebook newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userFacebook:UserFacebook { Page: {Page} })")
                //.OnCreate()
                .Set("userFacebook = {userFacebook}")
                .WithParams(new
                {
                    Page = newModel.Page,
                    userFacebook = newModel
                })
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Добавить список пользователей
        /// </summary>
        /// <param name="users"></param>
        public void Merge(IEnumerable<UserFacebook> users)
        {
            users = users.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(users, "UserFacebook")
                .Merge("(n:UserFacebook { Page: UserFacebook.Page })")
                .OnCreate()
                .Set("n = UserFacebook")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public UserFacebook FindOldestRecord()
        {
            return Client.Cypher
          .Match("(userFacebook:UserFacebook)")
          .With("min(userFacebook.updateDate) as update_date")
          .Match("(userFacebook2:UserFacebook{ updateDate: update_date})")
          .Return(userFacebook2 => userFacebook2.As<UserFacebook>())
          .Results.First();
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void UpdateMerge(UserFacebook newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userFacebook:UserFacebook { Page: {Page} })")
                .Set("userFacebook = {userFacebook}")
                .WithParams(new
                {
                    Page = newModel.Page,
                    userFacebook = newModel
                })
                .ExecuteWithoutResults();
        }
    }
}
