﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.Facebook;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.Facebook
{
    public class FriendsFacebookMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public FriendsFacebookMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Сохранить друзей Facebook
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveFacebookFriend(string id1, string id2)
        {
            Client.Cypher
                .Match("(user1:UserFacebook)", "(user2:UserFacebook)")
                .Where((UserFacebook user1) => user1.Page == id1)
                .AndWhere((UserFacebook user2) => user2.Page == id2)
                .CreateUnique("(user1)-[:Friends]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить друзей Facebook
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="fUsers"></param>
        public void SaveFacebookFriend(string id1, IEnumerable<UserFacebook> fUsers)
        {
            var newData = fUsers.First().updateDate;

            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });

            Client.Cypher
                .Unwind(fUsers, "users")
                .Match("(user1:UserFacebook)", "(user2:UserFacebook {Page: users.Page})")
                .Where((UserFacebook user1) => user1.Page == id1)
                .Merge("(user1)-[rel:Friends]-(user2)")
              .OnCreate()
               .Set("rel.updateDate = {dat}")
                .WithParam("dat", newData)
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// /Получить друзей Facebook
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserFacebook> GetFriends(UserFacebook model)
        {
            return GetFriends(model.Page);
        }

        /// <summary>
        /// Получить друзей Facebook
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserFacebook> GetFriends(string id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserFacebook)-[:Friends]-(user2:UserFacebook)")
            .Where((UserFacebook user1) => user1.Page == id)
            .Return((user2) => user2.As<UserFacebook>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserFacebook>();
            return res;
        }
    }
}
