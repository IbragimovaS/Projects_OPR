﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.Twitter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.Twitter
{
    public class FollowersTwitterMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public FollowersTwitterMapper(GraphClient client)
        {
            Client = client;
        }

        ///// <summary>
        ///// Сохранить подписки Twitter
        ///// </summary>
        ///// <param name="uid1"></param>
        ///// <param name="uid2"></param>
        //public void SaveTwitterSubscriptions(string id1, string id2)
        //{
        //    Client.Cypher
        //        .Match("(user1:UserTwitter)", "(user2:UserTwitter)")
        //        .Where((UserTwitter user1) => user1.id == id1)
        //        .AndWhere((UserTwitter user2) => user2.id == id2)
        //        .CreateUnique("(user1)-[:Follower]->(user2)")
        //        .ExecuteWithoutResults();
        //}

        ///// <summary>
        ///// Сохранить подписки Twitter
        ///// </summary>
        ///// <param name="id1"></param>
        ///// <param name="fUsers"></param>
        //public void SaveTwitterSubscriptions(string id1, IEnumerable<UserTwitter> fUsers)
        //{
        //    fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });
        //    Client.Cypher
        //        .Unwind(fUsers, "users")
        //        .Match("(user1:UserTwitter)", "(user2:UserTwitter {id: users.id})")
        //        .Where((UserTwitter user1) => user1.id == id1)
        //        .CreateUnique("(user1)-[:Follower]->(user2)")
        //        .ExecuteWithoutResults();
        //}

        /// <summary>
        /// Сохранить подписчиков Twitter
        /// </summary>
        /// <param name="uid1"></param>
        /// <param name="uid2"></param>
        public void SaveTwitterFollowers(long id1, long id2)
        {
            Client.Cypher
                .Match("(user1:UserTwitter)", "(user2:UserTwitter)")
                .Where((UserTwitter user1) => user1.id == id1)
                .AndWhere((UserTwitter user2) => user2.id == id2)
                .CreateUnique("(user1)<-[:Follower]-(user2)")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Сохранить подписчиков Twitter
        /// </summary>
        /// <param name="id1"></param>
        /// <param name="fUsers"></param>
        public void SaveTwitterFollowers(long id1, IEnumerable<UserTwitter> fUsers)
        {
            var newData = fUsers.First().updateDate;

            fUsers = fUsers.Select(x => { x.ShouldSerialize = false; return x; });

            Client.Cypher
                .Unwind(fUsers, "users")
                .Match("(user1:UserTwitter)", "(user2:UserTwitter {id: users.id})")
                .Where((UserTwitter user1) => user1.id == id1)
                .Merge("(user1)<-[rel:Follower]-(user2)")
              .OnCreate()
               .Set("rel.updateDate = {dat}")
                .WithParam("dat", newData)
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// /Получить подписчиков Twitter
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public IEnumerable<UserTwitter> GetFollowers(UserTwitter model)
        {
            return GetFollowers(model.id);
        }

        /// <summary>
        /// Получить подписчиков Twitter
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<UserTwitter> GetFollowers(long id)
        {
            var res = Client.Cypher
            .OptionalMatch("(user1:UserTwitter)<-[:Follower]-(user2:UserTwitter)")
            .Where((UserTwitter user1) => user1.id == id)
            .Return((user2) => user2.As<UserTwitter>())
            .Results;
            if (res.Count() == 1 && res.First() == null)
                res = new List<UserTwitter>();
            return res;
        }

        ///// <summary>
        ///// /Получить подписчиков Twitter
        ///// </summary>
        ///// <param name="model"></param>
        ///// <returns></returns>
        //public IEnumerable<UserTwitter> GetSubscriptions(UserTwitter model)
        //{
        //    return GetSubscriptions(model.id);
        //}

        ///// <summary>
        ///// Получить подписчиков Twitter
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //public IEnumerable<UserTwitter> GetSubscriptions(long id)
        //{
        //    var res = Client.Cypher
        //    .OptionalMatch("(user1:UserTwitter)-[:Follower]->(user2:UserTwitter)")
        //    .Where((UserTwitter user1) => user1.id == id)
        //    .Return((user2) => user2.As<UserTwitter>())
        //    .Results;
        //    if (res.Count() == 1 && res.First() == null)
        //        res = new List<UserTwitter>();
        //    return res;
        //}
    }
}
