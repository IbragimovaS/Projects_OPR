﻿using Neo4jClient;
using SocialAPI.Models.SocialNetworks.Twitter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Mappers.Neo4j.Twitter
{
    public class UserTwitterMapper : Repository
    {
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="sesssion"></param>
        public UserTwitterMapper(GraphClient client)
        {
            Client = client;
        }

        /// <summary>
        /// Найти по идентификатору
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserTwitter Find(long id)
        {
            try
            {
                var results = Client.Cypher
                   .Match("(userTwitter:UserTwitter)")
                   .Where((UserTwitter userTwitter) => userTwitter.id == id)
                   .Return(userTwitter => userTwitter.As<UserTwitter>())
                   .Results;
                if (results.Count() > 0)
                    return results.First();
                else return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Найти по идентифицирующему полю screen name
        /// </summary>
        /// <param name="sc_nm"></param>
        /// <returns></returns>
        public UserTwitter FindScreen_name(string sc_nm)
        {
            try
            {
                var results = Client.Cypher
               .Match("(userTwitter:UserTwitter)")
               .Where((UserTwitter userTwitter) => userTwitter.screen_name == sc_nm)
               .Return(userTwitter => userTwitter.As<UserTwitter>())
               .Results;
                if (results == null)
                    return null;
                if (results.Count() > 0)
                    return results.First();
                else return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void Merge(UserTwitter newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userTwitter:UserTwitter { id: {id} })")
                //.OnCreate()
                .Set("userTwitter = {userTwitter}")
                .WithParams(new
                {
                    id = newModel.id,
                    userTwitter = newModel
                })
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Добавить список пользователей
        /// </summary>
        /// <param name="users"></param>
        public void Merge(IEnumerable<UserTwitter> users)
        {
            users = users.Select(x => { x.ShouldSerialize = false; return x; });
            Client.Cypher
                .Unwind(users, "UserTwitter")
                .Merge("(n:UserTwitter { id: UserTwitter.id })")
                .OnCreate()
                .Set("n = UserTwitter")
                .ExecuteWithoutResults();
        }

        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public UserTwitter FindOldestRecord()
        {
            return Client.Cypher
          .Match("(userTwitter:UserTwitter)")
          .With("min(userTwitter.updateDate) as update_date")
          .Match("(userTwitter2:UserTwitter{ updateDate: update_date})")
          .Return(userTwitter2 => userTwitter2.As<UserTwitter>())
          .Results.First();
        }

        /// <summary>
        /// Добавить пользователя
        /// </summary>
        /// <param name="newModel"></param>
        public void UpdateMerge(UserTwitter newModel)
        {
            newModel.ShouldSerialize = false;
            Client.Cypher
                .Merge("(userTwitter:UserTwitter { id: {id} })")
                .Set("userTwitter = {userTwitter}")
                .WithParams(new
                {
                    id = newModel.id,
                    userTwitter = newModel
                })
                .ExecuteWithoutResults();
        }

    }
}
