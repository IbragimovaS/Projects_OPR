﻿using Microsoft.EntityFrameworkCore;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialAPI.Models.MsSQL.History;
using SocialAPI.Models.MsSQL.BotometrModel;
using SocialAPIML.Model;

namespace SocialAPI.Mappers.MsSQL
{
    /// <summary>
    /// В классе определен контекст данных для взаимодействия с БД
    /// </summary>
    public class MsSQLContext : DbContext
    {
        public static string ConnectionString
        {
            get
            {
                return @"Data Source=192.168.252.131\SQLEXPRESS;Initial Catalog=SocialAPI;User ID=sa;Password=p@ssw0rd";
            }
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
#if DEBUG
            optionsBuilder.UseLazyLoadingProxies().UseSqlServer(
                ConnectionString);
#else
            optionsBuilder.UseLazyLoadingProxies().UseSqlServer(
             @"Data Source=(local)\SQLEXPRESS;Initial Catalog=SocialAPI;User ID=sa;Password=p@ssw0rd");
#endif
        }

        /// <summary>
        /// Пользователи SocialAPI
        /// </summary>
        public DbSet<Models.MsSQL.User> Users { get; set; }

        /// <summary>
        /// Параметры доступа к Фейсбук
        /// </summary>
        public DbSet<AccountManagerFacebook> AccountManagerFacebook { get; set; }

        /// <summary>
        /// Параметры доступа для Инстаграм
        /// </summary>
        public DbSet<AccountManagerInstagram> AccountManagerInstagram { get; set; }

        /// <summary>
        /// Параметры доступа для Одноклассников
        /// </summary>
        public DbSet<AccountManagerOK> AccountManagerOK { get; set; }

        /// <summary>
        /// Параметры доступа для Твиттер
        /// </summary>
        public DbSet<AccountManagerTwitter> AccountManagerTwitter { get; set; }


        /// <summary>
        /// Параметры доступа для ВКонтакте
        /// </summary>
        public DbSet<AccountManagerVK> AccountManagerVK { get; set; }

        #region Таблицы истории изменений

        /// <summary>
        /// Параметры доступа для истории изменений для ВКонтакте
        /// </summary>
        public DbSet<HistoryVK> HistoryVK { get; set; }

        /// <summary>
        /// Параметры доступа для истории изменений для Твиттер
        /// </summary>
        public DbSet<HistoryTwitter> HistoryTwitter { get; set; }

        /// <summary>
        /// Параметры доступа для истории изменений для Одноклассников
        /// </summary>
        public DbSet<HistoryOK> HistoryOK { get; set; }

        /// <summary>
        /// Параметры доступа для истории изменений для Инстаграм
        /// </summary>
        public DbSet<HistoryInstagram> HistoryInstagram { get; set; }

        /// <summary>
        /// Параметры доступа для истории изменений для Фейсбук
        /// </summary>
        public DbSet<HistoryFacebook> HistoryFacebook { get; set; }

        #endregion

        /// <summary>
        /// Набор тестовых данных нейронной сети для instagram
        /// </summary>
        public DbSet<ModelInput> BotometrTrainingSetUsers { get; set; }

        /// <summary>
        /// Набор прокси для загрузки из инстаграм
        /// </summary>
        public DbSet<Proxy> ProxySet { get; set; }
    }
}
