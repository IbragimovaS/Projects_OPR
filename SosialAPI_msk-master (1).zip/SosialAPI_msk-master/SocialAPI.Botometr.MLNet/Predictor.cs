﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Data;
using static Microsoft.ML.DataOperationsCatalog;
using Microsoft.ML.Trainers;
using Microsoft.ML.Transforms.Text;
using SocialAPI.DataOperators;
using SocialAPI.Models.MsSQL.BotometrModel;
using System.Data.SqlClient;
using SocialAPI.Mappers.MsSQL;

namespace SocialAPI.Botometr.MLNet
{
    public class Predictor
    {
        //private static string AppPath => Path.GetDirectoryName(Environment.GetEnvironmentVariable)

        //private string string TrainDataPath =>

        //private static string TestDataPath=>

        //private static string ModelPath =>

        //private static PredictionModel<SentimentData, SentimentPrediction> _model

        public Predictor()
        {
            MLContext mlContext = new MLContext();

            TrainTestData splitDataView = LoadData(mlContext);

            ITransformer model = BuildAndTrainModel(mlContext, splitDataView.TrainSet);

            Evaluate(mlContext, model, splitDataView.TestSet);

            UseModelWithSingleItem(mlContext, model);

            UseModelWithBatchItems(mlContext, model);

            //if (_model == null)
            //{
            //    try
            //    {
            //        _model = PredictionModel.ReadAsync<SentimentData, SentimentPrediction>
            //    }
            //}
            //_model = TrainAsunc().Result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mlContext"></param>
        /// <returns></returns>
        public TrainTestData LoadData(MLContext mlContext)
        {

            DatabaseLoader loader = mlContext.Data.CreateDatabaseLoader<ModelInput>();

            string sqlCommand = @"[biography_Length]
                                  ,[country_block_Sign]
                                  ,[external_url_Sign]
                                  ,[external_url_linkshimmed_Sign]
                                  ,[has_channel_Sign]
                                  ,[edge_followed_by_Count]
                                  ,[edge_follow_Count]
                                  ,[full_name_Sign]
                                  ,[highlight_reel_Count]
                                  ,[business_category_name_Sign]
                                  ,[is_joined_recently_Sign]
                                  ,[is_private_Sign]
                                  ,[is_verified_Sign]
                                  ,[profile_pic_url_Sign]
                                  ,[profile_pic_url_hd_Sign]
                                  ,[connected_fb_page_Sign]
                                  ,[edge_felix_video_timeline_Count]
                                  ,[edge_felix_video_timeline_Comment_Count]
                                  ,[edge_felix_video_timeline_Like_Count]
                                  ,[edge_felix_comments_disabled_Percent]
                                  ,[edge_felix_location_null_Percent]
                                  ,[edge_felix_gating_info_null_Percent]
                                  ,[edge_felix_fact_check_overall_rating_null_Percent]
                                  ,[edge_felix_fact_check_information_null_Percent]
                                  ,[edge_felix_is_video_Percent]
                                  ,[edge_felix_is_published_Percent]
                                  ,[edge_felix_title_notEmpty_Percent]
                                  ,[edge_felix_video_view_Count]
                                  ,[edge_owner_to_timeline_media_Count]
                                  ,[edge_owner_media_to_comment_Count]
                                  ,[edge_owner_comments_disabled_Percent]
                                  ,[edge_owner_edge_liked_by_Count]
                                  ,[edge_owner_location_null_Percent]
                                  ,[edge_owner_gating_info_null_Percent]
                                  ,[edge_owner_fact_check_overall_rating_null_Percent]
                                  ,[edge_owner_fact_check_information_null_Percent]
                                  ,[edge_owner_is_video_Percent]
                                  ,[edge_saved_media_Count]
                                  ,[edge_media_collections_Count]
                                  ,[is_bot]
                              FROM[dbo].[BotometrTrainingSetUsers]";

            DatabaseSource dbSource = new DatabaseSource(SqlClientFactory.Instance, MsSQLContext.ConnectionString, sqlCommand);

            IDataView dataView = loader.Load(dbSource);

            TrainTestData splitDataView = mlContext.Data.TrainTestSplit(dataView, testFraction: 0.2);

            return splitDataView;
        }

        /// <summary>
        /// извлечение и преобразование данных;
        ///обучение модели
        /// прогноз тональности на основе тестовых данных
        /// возвращение модели
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="splitTrainSet"></param>
        /// <returns></returns>
        public static ITransformer BuildAndTrainModel(MLContext mlContext, IDataView splitTrainSet)
        {
            var dataProcessPipeline = mlContext.Transforms.Concatenate("Features", new[] { "V0", "V1", "V2", "V3", "V4", "V5", "V6", "V7", "V8", "V9", "V10", "V11",
                "V12", "V13", "V14", "V15", "V16", "V17", "V18", "V19", "V20", "V21", "V22", "V23", "V24", "V25", "V26", "V27", "V28", "V29", "V30", "V31", "V32", "V33", "V34","V35",
            "V36", "V37", "V38"});
            // Choosing algorithm
            var trainer = mlContext.BinaryClassification.Trainers.LightGbm(labelColumnName: "is_bot", featureColumnName: "Features");
            // Appending algorithm to pipeline
            var trainingPipeline = dataProcessPipeline.Append(trainer);

            ITransformer model = trainingPipeline.Fit(splitTrainSet);
            mlContext.Model.Save(model, splitTrainSet.Schema, @"C:\test\trainedModel.zip);

            //var estimator = mlContext.Transforms.FeatureSelection.SelectFeaturesBasedOnCount(outputColumnName: "Features", inputColumnName: nameof(BotData.is_bot))

            ////var estimator = mlContext.Transforms.Text.FeaturizeText(outputColumnName: "Features", inputColumnName: nameof(BotData.biography_Length))

            //    .Append(mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: "Label", featureColumnName: "Features"));

            ////"=============== Создаем и тренируем модель ===============");
            //var model = estimator.Fit(splitTrainSet);
            ////"=============== Конец тренировки ===============");
            return model;
        }

        /// <summary>
        /// Загружает набор тестовых данных. Создает оценщик BinaryClassification. Оценивает модель и создает метрики.
        /// Отображает метрики.
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="model"></param>
        /// <param name="splitTestSet"></param>
        public static void Evaluate(MLContext mlContext, ITransformer model, IDataView splitTestSet)
        {
            //=============== Оценка точности модели с помощью данных испытаний===============
            IDataView predictions = model.Transform(splitTestSet); //код использует метод Transform () для прогнозирования нескольких предоставленных входных строк тестового набора данных

            //оцените модель
            CalibratedBinaryClassificationMetrics metrics = mlContext.BinaryClassification.Evaluate(predictions, "Label");

            //Когда у вас есть набор прогнозов (предсказания), метод Evaluate () оценивает модель,
            //которая сравнивает прогнозные значения с фактическими метками в наборе тестовых данных и возвращает объект 
            //CalibratedBinaryClassificationMetrics о том, как модель работает.

            //Оценка метрик качества модели

            Console.WriteLine($"Accuracy: {metrics.Accuracy:P2}");      //Метрика Точность получает точность модели, которая является пропорцией правильных прогнозов в тестовом наборе.
            Console.WriteLine($"Auc: {metrics.AreaUnderRocCurve:P2}");  //Метрика AreaUnderRocCurve показывает, насколько уверенно модель правильно классифицирует положительные и отрицательные классы. Вы хотите, чтобы AreaUnderRocCurve был как можно ближе к единице
            Console.WriteLine($"F1Score: {metrics.F1Score:P2}");        //Метрика F1Score получает оценку модели F1, которая является мерой баланса между точностью и отзывом. Вы хотите, чтобы F1Score был как можно ближе к одному
            //=============== Конец оценки модели ===============
        }

        /// <summary>
        /// Предсказать результат теста данных
        /// Создает один комментарий к тестовым данным. Прогнозирует настроение на основе тестовых данных. 
        /// Объединяет тестовые данные и прогнозы для отчетности.
        /// Отображает прогнозируемые результаты.
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="model"></param>
        private static void UseModelWithSingleItem(MLContext mlContext, ITransformer model)
        {
            PredictionEngine<BotData, BotPrediction> predictionFunction = mlContext.Model.CreatePredictionEngine<BotData, BotPrediction>(model);

            //Создание экземпляра BotData  для проверки предсказания обученной модели
            BotData sampleStatement = new BotData
            {
                biography_Length = 10
            };

            //Передайте данные тестовых данных в PredictionEngine
            //Функция Predict () делает прогноз для одной строки данных
            var resultPrediction = predictionFunction.Predict(sampleStatement);

            //Тест на прогнозирование модели с одним образцом и набором тестовых данных
            Console.WriteLine($"Длина поля биография: {resultPrediction.biography_Length} | Прогноз: {(Convert.ToBoolean(resultPrediction.Prediction) ? "Позитивный" : "Негативный")} | Вероятность: {resultPrediction.Probability} ");

        }

        /// <summary>
        /// Использование модели для прогноза
        /// Развертывание и прогнозирование элементов партии
        /// Метод решает слудующие задачи:
        /// 1 Создает данные пакетного теста
        /// 2 Прогнозирует бот или нет на основе тестовых данных
        /// 3 Объединяет данные испытаний и прогнозы для отчетности
        /// 4 Отображает прогнозируемые результаты
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="model"></param>
        public static void UseModelWithBatchItems(MLContext mlContext, ITransformer model)
        {
            //Добавьте несколько записей о пользователях, чтобы проверить предсказания обученной модели
            IEnumerable<BotData> userDatas = new[]
            {
                new BotData
                {
                    biography_Length = 10
                },
                new BotData
                {
                   biography_Length = 6
                }
            };

            //Прогнозирование данных о польлзователях
            //Используем модель, чтобы предсказать признаки бота, используя метод Transform ():
            IDataView batchComments = mlContext.Data.LoadFromEnumerable(userDatas);

            IDataView predictions = model.Transform(batchComments);

            // Использование модели, для предсказания, являются ли данные положительными (1) или отрицательными (0)
            IEnumerable<BotPrediction> predictedResults = mlContext.Data.CreateEnumerable<BotPrediction>(predictions, reuseRowObject: false);

            //Объединение и отображение прогнозов
            Console.WriteLine("=============== Тест на предсказание загруженной модели с несколькими выборками ===============");

            foreach (BotPrediction prediction in predictedResults)
            {
                Console.WriteLine($"Длина поля биография: {prediction.biography_Length} | Прогноз: {(Convert.ToBoolean(prediction.Prediction) ? "Позитивный" : "Негативный")} | Вероятность: {prediction.Probability} ");

            }
            Console.WriteLine("=============== Конец прогнозов ===============");
        }

        //public bool Predict(string text)
        //{
        //    return false;
        //}


        //public static async Task<PredictionModel<SentimentData, SentimentPrediction>> TrainAsunc()
        //{
        //    var pioelene = new LearningPipeline();
        //    return _model;
        //}



    }
}
