﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Botometr.MLNet
{

    public class ModelInput
    {
        /// <summary>
        /// Длина поля содержащего биографию
        /// </summary>
        [ColumnName("V0"), LoadColumn(0)]
        public int biography_Length { get; set; }

        /// <summary>
        /// Признак -  заблокированности страной
        /// </summary>
        [ColumnName("V1"), LoadColumn(1)]
        public Boolean country_block_Sign { get; set; }

        /// <summary>
        /// Признак -  наличия внешней ссылки
        /// </summary>
        [ColumnName("V2"), LoadColumn(2)]
        public Boolean external_url_Sign { get; set; }

        /// <summary>
        /// Признак - наличия внешней ссылки
        /// </summary>
        [ColumnName("V3"), LoadColumn(3)]
        public Boolean external_url_linkshimmed_Sign { get; set; }

        /// <summary>
        /// Имеет канал
        /// </summary>
        [ColumnName("V4"), LoadColumn(4)]
        public Boolean has_channel_Sign { get; set; }

        /// <summary>
        /// Количество подписчиков
        /// </summary>
        [ColumnName("V5"), LoadColumn(5)]
        public int edge_followed_by_Count { get; set; }

        /// <summary>
        /// Количество подписок
        /// </summary>
        [ColumnName("V6"), LoadColumn(6)]
        public int edge_follow_Count { get; set; }

        /// <summary>
        /// Признак -  имя пользователя
        /// </summary>
        [ColumnName("V7"), LoadColumn(7)]
        public Boolean full_name_Sign { get; set; }

        /// <summary>
        /// Выделить количество (рулонов, барабанов, катушек)
        /// </summary>
        [ColumnName("V8"), LoadColumn(8)]
        public int highlight_reel_Count { get; set; }

        /// <summary>
        /// Признак -  Наименование категории бизнеса
        /// </summary>
        [ColumnName("V9"), LoadColumn(9)]
        public Boolean business_category_name_Sign { get; set; }

        /// <summary>
        /// Признак - Присоединился недавно
        /// </summary>
        [ColumnName("V10"), LoadColumn(10)]
        public Boolean is_joined_recently_Sign { get; set; }

        /// <summary>
        /// Признак - приватность
        /// </summary>
        [ColumnName("V11"), LoadColumn(11)]
        public Boolean is_private_Sign { get; set; }

        /// <summary>
        /// Признак - Верифицированный аккаунт
        /// </summary>
        [ColumnName("V12"), LoadColumn(12)]
        public Boolean is_verified_Sign { get; set; }

        /// <summary>
        /// Признак - наличие ссылки на изображение пользователя
        /// </summary>
        [ColumnName("V13"), LoadColumn(13)]
        public Boolean profile_pic_url_Sign { get; set; }

        /// <summary>
        /// Признак - наличие ссылки на изображение пользователя
        /// </summary>
        [ColumnName("V14"), LoadColumn(14)]
        public Boolean profile_pic_url_hd_Sign { get; set; }

        /// <summary>
        /// Признак - наличие страницы в fb
        /// </summary>
        [ColumnName("V15"), LoadColumn(15)]
        public Boolean connected_fb_page_Sign { get; set; }

        /// <summary>
        /// Количество IGTV публикации
        /// </summary>
        [ColumnName("V16"), LoadColumn(16)]
        public int edge_felix_video_timeline_Count { get; set; }

        /// <summary>
        /// Количество комментариев для публикации IGTV 
        /// </summary>
        [ColumnName("V17"), LoadColumn(17)]
        public int edge_felix_video_timeline_Comment_Count { get; set; }

        /// <summary>
        /// Количество лайков для публикации IGTV 
        /// </summary>
        [ColumnName("V18"), LoadColumn(18)]
        public int edge_felix_video_timeline_Like_Count { get; set; }

        /// <summary>
        /// Процент публикаций с запрещенными комментариями для IGTV comments_disabled = true
        /// </summary>
        [ColumnName("V19"), LoadColumn(19)]
        public int edge_felix_comments_disabled_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем location для IGTV
        /// </summary>
        [ColumnName("V20"), LoadColumn(20)]
        public int edge_felix_location_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем gating_info для IGTV
        /// </summary>
        [ColumnName("21"), LoadColumn(21)]
        public int edge_felix_gating_info_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем fact_check_overall_rating для IGTV
        /// </summary>
        [ColumnName("V22"), LoadColumn(22)]
        public int edge_felix_fact_check_overall_rating_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем fact_check_information для IGTV
        /// </summary>
        [ColumnName("V23"), LoadColumn(23)]
        public int edge_felix_fact_check_information_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с  полем is_video = true	 для IGTV
        /// </summary>
        [ColumnName("V24"), LoadColumn(24)]
        public int edge_felix_is_video_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с  полем is_published = true	 для IGTV
        /// </summary>
        [ColumnName("V25"), LoadColumn(25)]
        public int edge_felix_is_published_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с не пустым полем title для IGTV
        /// </summary>
        [ColumnName("V26"), LoadColumn(26)]
        public int edge_felix_title_notEmpty_Percent { get; set; }

        /// <summary>
        /// Количество просмотров для публикации IGTV 
        /// </summary>
        [ColumnName("V27"), LoadColumn(27)]
        public int edge_felix_video_view_Count { get; set; }

        /// <summary>
        /// Количество публикации
        /// </summary>
        [ColumnName("V28"), LoadColumn(28)]
        public int edge_owner_to_timeline_media_Count { get; set; }

        /// <summary>
        /// Количество всех загруженных комментариев к публикациям edge_media_to_comment.count
        /// </summary>
        [ColumnName("V29"), LoadColumn(29)]
        public int edge_owner_media_to_comment_Count { get; set; }

        /// <summary>
        /// Процент публикаций с  полем comments_disabled = true
        /// </summary>
        [ColumnName("V30"), LoadColumn(30)]
        public int edge_owner_comments_disabled_Percent { get; set; }

        /// <summary>
        /// Количество лайков на всех публикациях edge_liked_by.count
        /// </summary>
        [ColumnName("V31"), LoadColumn(31)]
        public int edge_owner_edge_liked_by_Count { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем location
        /// </summary>
        [ColumnName("V32"), LoadColumn(32)]
        public int edge_owner_location_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем gating_info
        /// </summary>
        [ColumnName("V33"), LoadColumn(33)]
        public int edge_owner_gating_info_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем fact_check_overall_rating
        /// </summary>
        [ColumnName("V34"), LoadColumn(34)]
        public int edge_owner_fact_check_overall_rating_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с нулевым полем fact_check_information
        /// </summary>
        [ColumnName("V35"), LoadColumn(35)]
        public int edge_owner_fact_check_information_null_Percent { get; set; }

        /// <summary>
        /// Процент публикаций с  полем is_video = true
        /// </summary>
        [ColumnName("V36"), LoadColumn(36)]
        public int edge_owner_is_video_Percent { get; set; }

        /// <summary>
        ///Количество сохраненные медиа
        /// </summary>
        [ColumnName("V37"), LoadColumn(37)]
        public int edge_saved_media_Count { get; set; }

        /// <summary>
        /// Количество медиа коллекций
        /// </summary>
        [ColumnName("V38"), LoadColumn(38)]
        public int edge_media_collections_Count { get; set; }


        [ColumnName("is_bot"), LoadColumn(39)]
        public bool is_bot { get; set; }
    }

    public class ModelOutput
    {
        [ColumnName("PredictedLabel")]
        public bool Prediction { get; set; }

        public float Score { get; set; }
    }
}
