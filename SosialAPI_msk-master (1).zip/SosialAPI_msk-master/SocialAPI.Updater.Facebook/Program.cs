﻿using SocialAPI.Mappers.Neo4j;
using System;
using SocialAPI.Models.SocialNetworks.Facebook;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.DataOperators;
using SocialAPI.Connections;
using SocialAPI.Models.MsSQL.History;
using SocialAPI.Mappers.Neo4j.Facebook;
using System.Threading;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using SocialAPI.Models.SocialNetworks;

namespace SocialAPI.Updater.Facebook
{
    class UserFacebookData
    {
        public UserFacebook data { get; set; }
    }

    /// <summary>
    /// При настройке запуска приложения по времени,  необходимо открыть вкладку действия
    /// в поле "Программа или сценарий" ввести dotnet
    /// В поле "Добавить аргументы" прописать путь к SocialAPI.Updater.Facebook.dll
    /// C:\Users\user1\Desktop\SosialAPI_msk.git\trunk\SocialAPI.Updater.Facebook\bin\Debug\netcoreapp2.1\SocialAPI.Updater.Facebook.dll 07DD29FF-1BF8-48DA-0272-08D729F8DF1B 1000 http://localhost:52147/
    /// При необходимости в поле "Рабочая папка" прописать путь к папке содержащей SocialAPI.Updater.Facebook.dll НАПРИМЕР - C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Служебное поле - массив полей Reflection
        /// </summary>
        public static PropertyInfo[] props;
        /// <summary>
        /// Служебное поле - массив наименований полей
        /// </summary>
        public static List<string> propNameList;

        /// <summary>
        /// Как в АПИ - количество подписчиков (друзья получаются все)
        /// </summary>
        public static int count;

        /// <summary>
        /// Токен для доступа к БД
        /// </summary>
        public static Guid user_token;

        /// <summary>
        /// Клиент для получения пользователей по средством Http запросов
        /// </summary>
        public static HttpClient client = new HttpClient();

        /// <summary>
        /// Признак запуска обновления данных
        /// </summary>
        public static bool isRuning;

        /// <summary>
        /// базовый адрес универсального идентификатора ресурса (URI) Интернета
        /// </summary>
        public static Uri baseAddress;

        /// <summary>
        /// Список полей, изменение значений которых не нужно сохранять в истории 
        /// </summary>
        public static List<string> notUpdatePropNameList;

        static void Main(string[] args)
        {
            MsSQLDataOperator.ParseArgs(args, ref user_token, ref count);

            if (3 <= args.Length)
                baseAddress = new Uri(args[2]);
            else
                baseAddress = new Uri("http://localhost:64195/");
            Init(user_token, count, baseAddress);

            Run();
        }

        /// <summary>
        /// Инициализация всех установок
        /// </summary>
        public static void Init(Guid usr_token, int cnt, Uri baseAddress)
        {
            Type t = (typeof(UserFacebook));
            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            notUpdatePropNameList = new List<string>() {
                "edge_followed_by"
                ,"edge_follow"
            };

            client.BaseAddress = baseAddress;
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        }

        /// <summary>
        /// Инициализация всех установок (для интеграционного тестирования)
        /// </summary>
        public static void Init(Guid usr_token, int cnt, HttpClient _client)
        {
            Type t = (typeof(UserFacebook));
            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            notUpdatePropNameList = new List<string>() {
                "edge_followed_by"
                ,"edge_follow"
            };


            client = _client;

        }


        /// <summary>
        /// Основная процедура
        /// </summary>
        public static void Run()
        {
            //Проверить токен пользователя в БД
            Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
            if (currentUser == null)
            {
                throw new Exception("Для пользователя user_token = \"" + user_token.ToString() + "\" не выполнен вход.");
            }

            using (UserFacebookMapper mapper = new UserFacebookMapper(Neo4jClientSource.CreateClient()))
            {
                using (FriendsFacebookMapper friedsMapper = new FriendsFacebookMapper(Neo4jClientSource.CreateClient()))
                {

                    while (isRuning)
                    {
                        Dictionary<string, string> instance_values_db = new Dictionary<string, string>();
                        Dictionary<string, string> instance_values_socialNet = new Dictionary<string, string>();
                        UserFacebook curentFacebook_db = getLastValue();
                        UserFacebook curentFacebook_socialNet = null;

                        if (curentFacebook_db == null) //Если в базе отсутствует запись т ждем 5 минут 
                        {
                            Thread.Sleep(5000 * 60);
                            continue;
                        }

                        #region Получение данных из БД
                        if (curentFacebook_db != null)
                        {
                            curentFacebook_db.Friends = friedsMapper.GetFriends(curentFacebook_db);
                            fillDictionaty(curentFacebook_db, ref instance_values_db);
                        }

                        #endregion

                        #region Получение данных из социальной сети

                        var url = String.Format(@"/api/users/findfacebook?user_token={0}&user_url={1}", user_token, curentFacebook_db.Page);

                        var getData = FindUserInFacebookAsync(url);
                        if (getData.Result == null)
                            throw new Exception("Запрос по странице Page = \"" + curentFacebook_db.Page + "\" не вернул результат.");
                        curentFacebook_socialNet = getData.Result;

                        DateTime updateDate = DateTime.Now;

                        if (curentFacebook_socialNet != null)
                        {
                            curentFacebook_socialNet.updateDate = updateDate;
                            if (curentFacebook_socialNet.Friends != null)
                                MsSQLDataOperator.SetUpdateDate(curentFacebook_socialNet.Friends.ToList<AbstractUser>(), updateDate);
                            fillDictionaty(curentFacebook_socialNet, ref instance_values_socialNet);
                        }

                        #endregion


                        #region Пользователь есть в БД - сравниваем

                        if (curentFacebook_db != null && curentFacebook_socialNet != null)
                        {
                            bool isNeedMerge_User = false;
                            bool isNeedMerge_Friends = false;
                            foreach (string propName in propNameList.Where(item => !notUpdatePropNameList.Any(item2 => item2 == item)))
                            {
                                string oldValue = instance_values_db[propName] == null ? String.Empty : instance_values_db[propName];
                                string newValue = instance_values_socialNet[propName] == null ? String.Empty : instance_values_socialNet[propName];
                                if (!oldValue.Equals(newValue))
                                {
                                    AddHistory(curentFacebook_db.Page, propName, oldValue, newValue, updateDate);

                                    if (propName.Equals("Friends"))
                                        isNeedMerge_Friends = true;
                                    else
                                        isNeedMerge_User = true;
                                }
                            }
                            #region Если есть необходимость - обновляем данные БД Neo
                            List<UserFacebook> friends = null;
                            if (curentFacebook_socialNet.Friends != null && curentFacebook_db.Friends != null)
                                friends = curentFacebook_socialNet.Friends.Where(item => !curentFacebook_db.Friends.Any(item2 => item2.Page == item.Page)).ToList();
                            else if (curentFacebook_socialNet.Friends != null) friends = curentFacebook_socialNet.Friends.ToList();

                            curentFacebook_socialNet.Friends = null;

                            //обновляем текущего пользователя всегда, так как нужно записать новую ubdateDate в neo4j
                            mapper.UpdateMerge(curentFacebook_socialNet);

                            if (isNeedMerge_Friends)
                            {
                                if (friends != null && friends.Count() > 0)
                                {
                                    mapper.Merge(friends);
                                    friedsMapper.SaveFacebookFriend(curentFacebook_socialNet.Page, friends);
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }

                }
            }
        }

        /// <summary>
        /// Делает запрос к Facebook и возвращает экземпляр класса UserFacebook
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        static async Task<UserFacebook> FindUserInFacebookAsync(string path)
        {
            UserFacebookData userFacebook = null;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
                userFacebook = await response.Content.ReadAsAsync<UserFacebookData>();
            }
            if (userFacebook != null)
                return userFacebook.data;
            else return null;
        }

        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public static UserFacebook getLastValue()
        {
            UserFacebookMapper mapper = new UserFacebookMapper(Neo4jClientSource.CreateClient());
            UserFacebook oldestUser = mapper.FindOldestRecord();
            return oldestUser;
        }
        /// <summary>
        /// Заполняет список пар "атрибут"-"значение" для указанного пользователя
        /// </summary>
        /// <param name="props"></param>
        /// <param name="curentFacebook"></param>
        /// <param name="dic"></param>
        static void fillDictionaty(UserFacebook curentFacebook, ref Dictionary<string, string> dic)
        {
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentFacebook);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentFacebook.Friends.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);//!!! TODO: Проверить значение 
            }
        }
        /// <summary>
        /// Добавляет в БД Neo пользователя
        /// </summary>
        /// <param name="userFacebook"></param>
        /// <param name="mapper"></param>
        /// <param name="friedsMapper"></param>
        /// <param name="followersMapper"></param>
        static void MergeUserFacebook(UserFacebook userFacebook, UserFacebookMapper mapper, FriendsFacebookMapper friendsMapper)
        {
            mapper.Merge(userFacebook);
            if (userFacebook.Friends != null && userFacebook.Friends.Count() > 0)
            {
                mapper.Merge(userFacebook.Friends);
                friendsMapper.SaveFacebookFriend(userFacebook.Page, userFacebook.Friends);
            }
        }
        /// <summary>
        /// Добавляет запись истории изменений атрибута
        /// </summary>
        /// <param name="fb_page">страница файлсбук</param>
        /// <param name="propName">имя поля</param>
        /// <param name="oldValue">старое значение</param>
        /// <param name="newValue">новое значение</param>
        /// <param name="updateDate">дата обновления</param>
        static void AddHistory(string fb_page, string propName, string oldValue, string newValue, DateTime updateDate)
        {
            HistoryFacebook history = new HistoryFacebook();
            history.rid = Guid.NewGuid();
            history.id_user_facebook = fb_page;
            history.attribute_name = propName;
            history.old_value = oldValue;
            history.new_value = newValue;
            history.date_change = updateDate;
            MsSQLDataOperator.HistoryFacebookAdd(history);
        }

    }
}
