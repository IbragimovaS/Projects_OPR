using Microsoft.AspNetCore.Mvc.Testing;
using SocialAPI.Botometr.Controllers;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;


namespace SocialAPI.Botometr.Instagram.IntegrationTests
{

    /// <summary>
    /// ����� ������������ ��� ���������� ��������� �������� ������� � �� SQL ����� ���������� ���������� SocialAPI.Botometr.Instagram
    /// </summary>
    public class IntegrationBotometrTest : IClassFixture<WebApplicationFactory<Startup>>
    {

        private readonly WebApplicationFactory<Startup> _factory;

        public IntegrationBotometrTest(WebApplicationFactory<Startup> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task Test1()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {

                    // Act
                    Guid user_token = new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b");
                    string usernames = "anastasiiasmirno;tais.pon_ko";
                    bool is_bot = false;
                    string password = "wwFdm2";

                    List<Task> tasks = new List<Task>();
                    var url = String.Format(@"/api/training/Insertinstagram?user_token={0}&usernames={1}&is_bot={2}&password={3}", user_token, usernames, is_bot, password);
                    tasks.Add(client.GetAsync(url));

                    await Task.WhenAll(tasks);

                    List<ExpandoObject> fbList = new List<ExpandoObject>();
                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        using (HttpContent content = t.Result.Content)
                        {

                            if (t.Result.IsSuccessStatusCode)
                            {
                                ExpandoObject cont = await t.Result.Content.ReadAsAsync<ExpandoObject>();
                                fbList.Add(cont);
                            }
                        }
                    }

                    Assert.True(fbList.Count > 0, "������ ������ ������� ������������");

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task insertTrainingSetRealUsersTest1()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {
                    string path = @"C:\test\realUserInsta.txt";
                    var file = File.ReadAllLines(path);
                    List<string> userList = new List<string>(file).Take(1300).ToList();
                    List<string> userListEnd = new List<string>();

                    Guid user_token = new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b");
                    bool is_bot = false;
                    string password = "wwFdm2";
                    string usernames = String.Empty;
                    int currentLine = 0;
                    List<Task> tasks = new List<Task>();
                    foreach (string user in userList)
                    {
                        userListEnd.Add(user.Replace(" ", String.Empty));
                    }

                    while (true)
                    {
                        string[] tempUser;

                        tempUser = userListEnd.Skip(currentLine).Take(1).ToArray();
                        if (tempUser.Length == 0)
                        {
                            break;
                        }
                        usernames = String.Join(";", tempUser);
                        var url = String.Format(@"/api/training/Insertinstagram?user_token={0}&usernames={1}&is_bot={2}&password={3}", user_token, usernames, is_bot, password);
                        tasks.Add(client.GetAsync(url));

                        currentLine = currentLine + 1;

                        Thread.Sleep(1000);
                    }


                    await Task.WhenAll(tasks);

                    List<ExpandoObject> fbList = new List<ExpandoObject>();
                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        using (HttpContent content = t.Result.Content)
                        {

                            if (t.Result.IsSuccessStatusCode)
                            {
                                ExpandoObject cont = await t.Result.Content.ReadAsAsync<ExpandoObject>();
                                fbList.Add(cont);
                            }
                        }
                    }

                    Assert.True(fbList.Count > 0, "������ ������ ������� ������������");

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task CheckBot()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {
                    string path = @"Data\usersForCheck.txt";
                    var file = File.ReadAllLines(path);
                    List<string> userList = new List<string>(file).Take(1300).ToList();
                    List<string> userListEnd = new List<string>();

                    Guid user_token = new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b");
                    string usernames = String.Empty;

                    List<Task> tasks = new List<Task>();
                    foreach (string user in userList)
                    {
                        userListEnd.Add(user.Replace(" ", String.Empty));
                    }

                    usernames = String.Join(";", userListEnd);
                    var url = String.Format(@"/api/check/checkbot?user_token={0}&usernames={1}&usernames={1}", user_token, usernames);
                    tasks.Add(client.GetAsync(url));


                    await Task.WhenAll(tasks);

                    List<ExpandoObject> fbList = new List<ExpandoObject>();
                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        using (HttpContent content = t.Result.Content)
                        {

                            if (t.Result.IsSuccessStatusCode)
                            {
                                ExpandoObject cont = await t.Result.Content.ReadAsAsync<ExpandoObject>();
                                fbList.Add(cont);
                            }
                        }
                    }

                    Assert.True(fbList.Count > 0, "������ ������ ������� ����� � �������������� ������������ � ����");

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }
    }
}
