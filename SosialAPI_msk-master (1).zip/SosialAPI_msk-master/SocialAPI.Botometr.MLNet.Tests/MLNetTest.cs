using System;
using Xunit;

namespace SocialAPI.Botometr.MLNet.Tests
{
    public class MLNetTest
    {
        [Fact]
        public void Test1()
        {
            //Predictor predictor = new Predictor();
        }
    }
}
