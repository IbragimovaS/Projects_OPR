﻿using SocialAPI.Mappers.Neo4j;
using SocialAPI.Mappers.Neo4j.VK;
using System;
using SocialAPI.Models.SocialNetworks.VK;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.DataOperators;
using SocialAPI.Connections;
using SocialAPI.Models.MsSQL.History;
using SocialAPI.Models.SocialNetworks;
using System.IO;
using System.Diagnostics;

namespace SocialAPI.Updater.VK
{
    /// <summary>
    /// При настройке запуска приложения по времени,  необходимо открыть вкладку действия
    /// в поле "Программа или сценарий" ввести dotnet
    /// В поле "Добавить аргументы" прописать путь к SocialAPI.Updater.VK.dll
    /// C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\SocialAPI.Updater.VK.dll 07DD29FF-1BF8-48DA-0272-08D729F8DF1B 203 false
    /// При необходимости в поле "Рабочая папка" прописать путь к папке содержащей SocialAPI.Updater.VK.dll НАПРИМЕР - C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Служебное поле - массив полей Reflection
        /// </summary>
        public static PropertyInfo[] props;
        /// <summary>
        /// Служебное поле - массив наименований полей
        /// </summary>
        public static List<string> propNameList;
        /// <summary>
        /// Как в АПИ - количество подписчиков (друзья получаются все)
        /// </summary>
        public static int count;
        /// <summary>
        /// Как в АПИ - быстрое получение подписчиков (получаются только идентификаторы подписчиков, если true - параметр count игнорируется)
        /// </summary>
        public static bool fast_followers;
        /// <summary>
        /// Токен для доступа к БД
        /// </summary>
        public static Guid user_token;

        /// <summary>
        /// Приблизительное количество пользователей в ВК
        /// </summary>
        public static int countUserInCatalog = 572000000;

        /// <summary>
        /// Наименование файла содержащего запись последнего загруженного id
        /// </summary>
        public static string lastCheckedIdFile = "lastCheckedId.txt";

        /// <summary>
        /// Список полей, изменение значений которых не нужно сохранять в истории 
        /// </summary>
        public static List<string> notUpdatePropNameList;

        /// <summary>
        /// Признак запуска обновления данных
        /// </summary>
        public static bool isRuning;

        static void Main(string[] args)
        {
            MsSQLDataOperator.ParseArgs(args, ref user_token, ref count);

            if (3 <= args.Length)
                bool.TryParse(args[2], out fast_followers);

            Init(user_token, count, fast_followers);

            Run();
        }

        /// <summary>
        /// Инициализация всех установок
        /// </summary>
        public static void Init(Guid usr_token, int cnt, bool fastF)
        {
            Type t = (typeof(UserVK));

            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            notUpdatePropNameList = new List<string>() {
                 "City"
                ,"Country"
                ,"Last_seen"
                ,"Career"
                ,"Universities"
                ,"Schools"
                ,"Military"};

            fast_followers = fastF;
        }

        /// <summary>
        /// Основная процедура
        /// </summary>
        public static void Run()
        {
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                if (currentUser == null)
                {
                    throw new Exception("Для пользователя user_token = \"" + user_token.ToString() + "\" не выполнен вход.");
                }
                var vkAccount = MsSQLDataOperator.GetGoodAccountVK();//получаем токен ВКонтакте

                using (UserVKMapper mapper = new UserVKMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsVKMapper friedsMapper = new FriendsVKMapper(Neo4jClientSource.CreateClient()))
                    {
                        using (FollowersVKMapper followersMapper = new FollowersVKMapper(Neo4jClientSource.CreateClient()))
                        {

                            while (isRuning)
                            {
                                long last_id = getLastValue();
                                Dictionary<string, string> instance_values_db = new Dictionary<string, string>();
                                Dictionary<string, string> instance_values_socialNet = new Dictionary<string, string>();
                                UserVK curentVK_db = null;
                                UserVK curentVK_socialNet = null;

                                #region Получение данных из БД

                                curentVK_db = mapper.Find(last_id);
                                if (curentVK_db != null)
                                {
                                    curentVK_db.Friends = friedsMapper.GetFriends(curentVK_db);
                                    curentVK_db.Followers = followersMapper.GetFollowers(curentVK_db);
                                    curentVK_db.Subscriptions = followersMapper.GetSubscriptions(curentVK_db);

                                    fillDictionaty(curentVK_db, ref instance_values_db);
                                }

                                #endregion

                                #region Получение данных из социальной сети

                                var getData = VKConnection.getVKUsers(last_id.ToString(), vkAccount.token);
                                if (getData == null || getData.Count() == 0)
                                    throw new Exception("Запрос по странице id = \"" + last_id.ToString() + "\" не вернул результат.");
                                curentVK_socialNet = getData.First();
                                getUserVK(vkAccount, last_id, ref instance_values_socialNet, ref curentVK_socialNet);
                                DateTime updateDate = DateTime.Now;
                                if (curentVK_socialNet != null)
                                {
                                    curentVK_socialNet.updateDate = updateDate;
                                    if (curentVK_socialNet.Friends != null)
                                        MsSQLDataOperator.SetUpdateDate(curentVK_socialNet.Friends.ToList<AbstractUser>(), updateDate);
                                    if (curentVK_socialNet.Followers != null)
                                        MsSQLDataOperator.SetUpdateDate(curentVK_socialNet.Followers.ToList<AbstractUser>(), updateDate);
                                    if (curentVK_socialNet.Subscriptions != null)
                                        MsSQLDataOperator.SetUpdateDate(curentVK_socialNet.Subscriptions.ToList<AbstractUser>(), updateDate);
                                }
                                #endregion

                                #region Такой пользователь отсутствует в БД - добавляем

                                if (curentVK_db == null && curentVK_socialNet != null)
                                {
                                    MergeUserVK(curentVK_socialNet, mapper, friedsMapper, followersMapper);
                                }
                                #endregion

                                #region Пользователь есть в БД - сравниваем

                                if (curentVK_db != null && curentVK_socialNet != null)
                                {
                                    bool isNeedMerge_User = false;
                                    bool isNeedMerge_Friends = false;
                                    bool isNeedMerge_Followers = false;
                                    bool isNeedMerge_Subscriptions = false;
                                    foreach (string propName in propNameList.Where(item => !notUpdatePropNameList.Any(item2 => item2 == item)))
                                    {
                                        string oldValue = instance_values_db[propName] == null ? String.Empty : instance_values_db[propName];
                                        string newValue = instance_values_socialNet[propName] == null ? String.Empty : instance_values_socialNet[propName];

                                        if (!oldValue.Equals(newValue))
                                        {
                                            AddHistory(last_id, propName, oldValue, newValue, updateDate);

                                            if (propName.Equals("Friends"))
                                                isNeedMerge_Friends = true;
                                            else if (propName.Equals("Followers"))
                                                isNeedMerge_Followers = true;
                                            else if (propName.Equals("Subscriptions"))
                                                isNeedMerge_Subscriptions = true;
                                            else
                                                isNeedMerge_User = true;
                                        }
                                    }
                                    #region Если есть необходимость - обновляем данные БД Neo
                                    List<UserVK> friends = null;
                                    List<UserVK> followers = null;
                                    List<UserVK> subscriptions = null;
                                    if (curentVK_socialNet.Friends != null && curentVK_db.Friends != null)
                                        friends = curentVK_socialNet.Friends.Where(item => !curentVK_db.Friends.Any(item2 => item2.id == item.id)).ToList();
                                    else if (curentVK_socialNet.Friends != null) friends = curentVK_socialNet.Friends.ToList();

                                    if (curentVK_socialNet.Followers != null && curentVK_db.Followers != null)
                                        followers = curentVK_socialNet.Followers.Where(item => !curentVK_db.Followers.Any(item2 => item2.id == item.id)).ToList();
                                    else if (curentVK_socialNet.Followers != null) followers = curentVK_socialNet.Followers.ToList();

                                    if (curentVK_socialNet.Subscriptions != null && curentVK_db.Subscriptions != null)
                                        subscriptions = curentVK_socialNet.Subscriptions.Where(item => !curentVK_db.Subscriptions.Any(item2 => item2.id == item.id)).ToList();
                                    else if (curentVK_socialNet.Subscriptions != null) subscriptions = curentVK_socialNet.Subscriptions.ToList();

                                    curentVK_socialNet.Friends = null;
                                    curentVK_socialNet.Followers = null;
                                    curentVK_socialNet.Subscriptions = null;

                                    if (isNeedMerge_User)
                                        mapper.UpdateMerge(curentVK_socialNet);
                                    if (isNeedMerge_Friends)
                                    {
                                        if (friends != null && friends.Count() > 0)
                                        {
                                            mapper.Merge(friends);
                                            friedsMapper.SaveVKFriend(curentVK_socialNet.id, friends);
                                        }
                                    }
                                    if (isNeedMerge_Followers)
                                    {

                                        if (followers != null && followers.Count() > 0)
                                        {
                                            mapper.Merge(followers);
                                            followersMapper.SaveVKFollowers(curentVK_socialNet.id, followers);
                                        }
                                    }
                                    if (isNeedMerge_Subscriptions)
                                    {

                                        if (subscriptions != null && subscriptions.Count() > 0)
                                        {
                                            mapper.Merge(subscriptions);
                                            followersMapper.SaveVKSubscriptions(curentVK_socialNet.id, subscriptions);
                                        }
                                    }
                                    #endregion
                                }
                                #endregion
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Updater.VK.Run. Текст ошибки {0}", ex.ToString()));
            }
        }

        /// <summary>
        /// Наполняет данными модель пользователя
        /// </summary>
        /// <param name="vkAccount"></param>
        /// <param name="vk_id"></param>
        /// <param name="instance_values_socialNet"></param>
        /// <param name="curentVK_socialNet"></param>
        private static void getUserVK(Models.MsSQL.AccountManager.AccountManagerVK vkAccount, long vk_id, ref Dictionary<string, string> instance_values_socialNet, ref UserVK curentVK_socialNet)
        {
            if (curentVK_socialNet != null)
            {
                var friends = VKConnection.getVKFriends(vk_id.ToString(), vkAccount.token);
                if (friends != null && friends.Count > 0)
                {
                    curentVK_socialNet.Friends = friends;

                }
                List<UserVK> followers = null;
                if (fast_followers)
                {
                    var ids = VKConnection.getFollowersIDs(vk_id.ToString(), vkAccount.token);
                    if (ids != null && ids.Count() > 0)
                    {
                        followers = ids.Select(x => new UserVK { id = x }).ToList();
                    }
                }
                else
                {
                    followers = VKConnection.getVKFollowers(vk_id.ToString(), vkAccount.token, 0, count);
                }
                if (followers != null && followers.Count > 0)
                {

                    curentVK_socialNet.Followers = followers;
                }
                var subscriptions = VKConnection.getVKSubscriptions(vk_id.ToString(), vkAccount.token);
                if (subscriptions != null && subscriptions.Count() > 0)
                {

                    curentVK_socialNet.Subscriptions = subscriptions;
                }

                fillDictionaty(curentVK_socialNet, ref instance_values_socialNet);
            }
        }

        /// <summary>
        /// Получает актуальное число пользователей ВКонтакте
        /// </summary>
        /// <returns></returns>
        public static long getLastValue()
        {
            long result = 1;
            try
            {
                string location = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string path = Path.Combine(location, lastCheckedIdFile);
                if (File.Exists(path))
                {
                    result = long.Parse(File.ReadAllText(path));

                    if (result < countUserInCatalog)
                        result += 1;
                    using (StreamWriter newTask = new StreamWriter(path, false))
                    {
                        newTask.WriteLine(result.ToString());
                    }
                }
                else
                {
                    File.AppendAllText(path, result.ToString());
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SSocialAPI.Updater.VK.Program.getLastValue. Текст ошибки {0}", ex.ToString()));
            }
            return result;
        }

        /// <summary>
        /// Заполняет список пар "атрибут"-"значение" для указанного пользователя
        /// </summary>
        /// <param name="props"></param>
        /// <param name="curentVK"></param>
        /// <param name="dic"></param>
        static void fillDictionaty(UserVK curentVK, ref Dictionary<string, string> dic)
        {
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentVK);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentVK.Friends.Count().ToString());
                    }
                    else if (attrName.Equals("Followers"))
                    {
                        dic.Add(attrName, curentVK.Followers.Count().ToString());
                    }
                    else if (attrName.Equals("Subscriptions"))
                    {
                        dic.Add(attrName, curentVK.Subscriptions.Count().ToString());
                    }
                    else if (attrName.Equals("Universities"))
                    {
                        dic.Add(attrName, curentVK.universities_list);
                    }
                    else if (attrName.Equals("Country"))
                    {
                        dic.Add(attrName, curentVK.CountryName);
                    }
                    else if (attrName.Equals("Career"))
                    {
                        dic.Add(attrName, curentVK.career_list);
                    }
                    else if (attrName.Equals("Schools"))
                    {
                        dic.Add(attrName, curentVK.schools_list);
                    }
                    else if (attrName.Equals("Last_seen"))
                    {
                        dic.Add(attrName, curentVK.last_seen_platform.ToString());
                    }
                    else if (attrName.Equals("City"))
                    {
                        dic.Add(attrName, curentVK.CityName);
                    }
                    else if (attrName.Equals("Military"))
                    {
                        dic.Add(attrName, curentVK.military_list);
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);//!!! TODO: Проверить значение 
            }
        }

        /// <summary>
        /// Добавляет в БД Neo пользователя
        /// </summary>
        /// <param name="userVK"></param>
        /// <param name="mapper"></param>
        /// <param name="friedsMapper"></param>
        /// <param name="followersMapper"></param>
        static void MergeUserVK(UserVK userVK, UserVKMapper mapper, FriendsVKMapper friedsMapper, FollowersVKMapper followersMapper)
        {
            var friends = userVK.Friends.ToArray();
            var followers = userVK.Followers.ToArray();
            var subscriptions = userVK.Subscriptions.ToArray();

            userVK.Friends = null;
            userVK.Followers = null;
            userVK.Subscriptions = null;

            mapper.Merge(userVK);
            if (friends != null && friends.Count() > 0)
            {
                mapper.Merge(friends);
                friedsMapper.SaveVKFriend(userVK.id, friends);
            }
            if (followers != null && followers.Count() > 0)
            {
                mapper.Merge(followers);
                followersMapper.SaveVKFollowers(userVK.id, followers);
            }
            if (subscriptions != null && subscriptions.Count() > 0)
            {
                mapper.Merge(subscriptions);
                followersMapper.SaveVKSubscriptions(userVK.id, subscriptions);
            }
        }

        /// <summary>
        /// Добавляет запись истории изменений атрибута
        /// </summary>
        /// <param name="vk_id">id пользователя вконтакте</param>
        /// <param name="propName">имя поля</param>
        /// <param name="oldValue">старое значение</param>
        /// <param name="newValue">новое значение</param>
        /// <param name="updateDate">дата обновления</param>
        static void AddHistory(long vk_id, string propName, string oldValue, string newValue, DateTime updateDate)
        {
            HistoryVK history = new HistoryVK();
            history.rid = Guid.NewGuid();
            history.id_user_vk = vk_id;
            history.attribute_name = propName;
            history.old_value = oldValue;
            history.new_value = newValue;
            history.date_change = updateDate;
            MsSQLDataOperator.HistoryVKAdd(history);
        }

    }
}
