using Newtonsoft.Json;
using NUnit.Framework;
using SocialAPI.Botometr;
using SocialAPI.Botometr.Controllers;
using SocialAPI.Connections;
using SocialAPI.DataOperators;
using SocialAPI.Models.MsSQL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Tests
{
    /// <summary>
    /// ����� ������������ ������������ ���������� ����� ������
    /// </summary>
    public class ProxyTest
    {
        [SetUp]
        public void Setup()
        {
        }

        /// <summary>
        /// ���������� �������� ������ � �����
        /// </summary>
        [Test]
        public void Test1()
        {

            try
            {
                var user_name = "pavelvolyaofficial";
                var proxy = new SocialAPI.Models.MsSQL.Proxy();
                var user = InstagramConnection.GetInstagramUser(user_name, ref proxy);
                var model = InstagramConnection.GetModelInputForTraining(user, false);
                int resultWriteToDB = MsSQLDataOperator.WriteToDBBotometrTrainingSet(model);

                Assert.AreEqual(0, resultWriteToDB);
            }
            catch (Exception)
            {

            }
        }

  

        [Test]
        public void testProxy()
        {
            Proxy proxy = MsSQLDataOperator.GetProxy();
            //var url = @"https://www.google.com/";
            var url = @"https://www.instagram.com/t.bobchik/?__a=1/";
            try
            {
                Assert.IsTrue(ProxyConnection.TestingConnection(proxy), "������ �� ��������");
            }
            catch (Exception ex)
            {
                string e = ex.ToString();
            }
        }

        [Test]
        public void testProxyIPv6()
        {
            var url = @"https://www.google.com/";
            //var url = @"https://www.instagram.com/t.bobchik/?__a=1";
            bool result = false;
            int count = 0;
            while (count < 250)
            {
                try
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                    WebProxy myproxy = new WebProxy("95.215.1.84", 43388);
                    myproxy.Credentials = new NetworkCredential("pCeGvEHVl7", "R1CdqHnnpE");

                    myproxy.BypassProxyOnLocal = false;
                    request.Proxy = myproxy;

                    request.Method = "GET";

                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        Stream dataStream = response.GetResponseStream();

                        StreamReader reader = new StreamReader(dataStream, Encoding.GetEncoding("UTF-8"));

                        string responseFromServer = reader.ReadToEnd();

                        reader.Close();
                        dataStream.Close();
                        response.Close();
                        count += 1;
                        Thread.Sleep(500);
                    }

                }
                catch (Exception ex)
                {
                    result = false;
                }
            }
        }


    }
}