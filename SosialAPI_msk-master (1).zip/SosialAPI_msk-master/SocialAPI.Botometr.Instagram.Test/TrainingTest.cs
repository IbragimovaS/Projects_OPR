using Newtonsoft.Json;
using NUnit.Framework;
using SocialAPI.Botometr;
using SocialAPI.Botometr.Controllers;
using SocialAPI.Connections;
using SocialAPI.DataOperators;
using SocialAPI.Models.MsSQL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Tests
{
    /// <summary>
    /// ����� ������������ ��� ���������� ��������� �������� ������� � �� SQL
    /// </summary>
    public class TrainingTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void insertTrainingSetRealUsersFromController()
        {
            try
            {
                string path = @"C:\test\BotsSet.txt";
                var file = File.ReadAllLines(path);
                List<string> userList = new List<string>(file).ToList();
                List<string> userListEnd = new List<string>();

                Guid user_token = new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b");
                bool is_bot = true;
                string password = "wwFdm2";
                string usernames = String.Empty;

                TrainingController controller = new TrainingController();

                foreach (string user in userList)
                {
                    var user_name = user.Replace(" ", String.Empty);
                    controller.Insertinstagram(user_token, user_name, is_bot, password);
                }
                //Assert.True(fbList.Count > 0, "������ ������ ������� ������������");

            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }
    }
}