﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialAPI.Connections;
using SocialAPI.DataOperators;
using SocialAPI.Mappers.Neo4j;
using SocialAPI.Mappers.Neo4j.Facebook;
using SocialAPI.Mappers.Neo4j.Instagram;
using SocialAPI.Mappers.Neo4j.OK;
using SocialAPI.Mappers.Neo4j.Twitter;
using SocialAPI.Mappers.Neo4j.VK;
using SocialAPI.Models;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.Facebook;
using SocialAPI.Models.SocialNetworks.Instagram;
using SocialAPI.Models.SocialNetworks.Twitter;
using SocialAPI.Models.SocialNetworks.VK;
using static SocialAPI.DataOperators.MsSQLDataOperator;
using static SocialAPI.Models.MsSQL.AccountManager.AccountManagerTwitter;

namespace SocialAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        /// <summary>
        /// Стаут при завершении метода действия без ошибок логики
        /// </summary>
        private const string OkStatus = "ok";

        /// <summary>
        /// Стаут при завершении метода действия c ошибкой в логике
        /// </summary>
        private const string FailStatus = "fail";

        /// <summary>
        /// Сообщение рользователю API - доступ запрещен
        /// </summary>
        private const string AccessIsDenied = "доступ запрещен";

        // GET: api/Users
        [HttpGet]
        public GenericResponse<AbstractUser> Get()
        {
            return new GenericResponse<AbstractUser>("не реализовано");
        }

        /// <summary>
        /// Получение ответа по пользователю ВКонтакте на запрос типа 
        /// http://localhost:52147/api/users/getvk?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&vk_id=1
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="vk_id"></param>
        /// <returns></returns>
        [HttpGet("GetVK")]
        public GenericResponse<AbstractUser> GetVK(Guid user_token, string vk_id)
        {
            using (UserVKMapper mapper = new UserVKMapper(Neo4jClientSource.CreateClient()))
            {
                using (FriendsVKMapper friedsMapper = new FriendsVKMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FollowersVKMapper followersMapper = new FollowersVKMapper(Neo4jClientSource.CreateClient()))
                    {
                        //Проверить токен пользователя в БД
                        Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                        if (currentUser == null)
                        {
                            return new GenericResponse<AbstractUser>(AccessIsDenied);
                        }

                        long numberVK;
                        UserVK res;
                        bool result = long.TryParse(vk_id, out numberVK);
                        if (result)
                        {
                            res = mapper.Find(numberVK);
                        }
                        else
                        {
                            res = mapper.FindByName(vk_id);
                        }

                        if (res != null)
                        {
                            res.Friends = friedsMapper.GetFriends(res);
                            res.Followers = followersMapper.GetFollowers(res);
                            res.Subscriptions = followersMapper.GetSubscriptions(res);
                            res.ShouldSerialize = false;
                        }
                        currentUser.current_count = currentUser.current_count + 1;
                        MsSQLDataOperator.UsersUpdate(currentUser);
                        return new GenericResponse<AbstractUser>(res);
                    }
                }
            }
        }

        /// <summary>
        /// Загрузка данных о пользователе ВКонтакте в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/putvk?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&vk_id=63607432
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="vk_id"></param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <param name="fast_followers">быстрое получение подписчиков (получаются только идентификаторы подписчиков, если true - параметр count игнорируется)</param>
        /// <returns></returns>
        [HttpGet("PutVK")]
        public GenericResponse<PutUserResponse> PutVK(Guid user_token, string vk_id, int count = 10000, bool fast_followers = true)
        {
            PutUserResponse res = new PutUserResponse { id = vk_id.ToString() };
            try
            {
                using (UserVKMapper mapper = new UserVKMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsVKMapper friedsMapper = new FriendsVKMapper(Neo4jClientSource.CreateClient()))
                    {
                        using (FollowersVKMapper followersMapper = new FollowersVKMapper(Neo4jClientSource.CreateClient()))
                        {
                            //Проверить токен пользователя в БД
                            Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                            if (currentUser == null)
                            {
                                res.State = FailStatus;
                                res.Message = AccessIsDenied;
                                return new GenericResponse<PutUserResponse>(res);
                            }
                            else
                            {
                                var vkAccount = MsSQLDataOperator.GetGoodAccountVK();//получаем токен ВКонтакте
                                if (vkAccount == null)
                                {
                                    res.State = FailStatus;
                                    return new GenericResponse<PutUserResponse>(res);
                                }

                                var usersVK = VKConnection.getVKUsers(vk_id.ToString(), vkAccount.token);//получаем пользователя
                                if (usersVK != null && usersVK.Count() > 0)
                                {
                                    DateTime updateDate = DateTime.Now;
                                    usersVK.First().updateDate = updateDate;

                                    mapper.Merge(usersVK.First());
                                    var friends = VKConnection.getVKFriends(usersVK.First().id.ToString(), vkAccount.token);
                                    if (friends != null && friends.Count > 0)
                                    {
                                        SetUpdateDate(friends.ToList<AbstractUser>(), updateDate);

                                        res.FriendsCount = friends.Count;
                                        mapper.Merge(friends);
                                        friedsMapper.SaveVKFriend(usersVK.First().id, friends);
                                    }
                                    List<UserVK> followers = null;
                                    if (fast_followers)
                                    {
                                        var ids = VKConnection.getFollowersIDs(usersVK.First().id.ToString(), vkAccount.token);
                                        if (ids != null && ids.Count() > 0)
                                        {
                                            followers = ids.Select(x => new UserVK { id = x }).ToList();
                                        }
                                    }
                                    else
                                    {
                                        followers = VKConnection.getVKFollowers(usersVK.First().id.ToString(), vkAccount.token, 0, count);
                                    }
                                    if (followers != null && followers.Count > 0)
                                    {
                                        SetUpdateDate(followers.ToList<AbstractUser>(), updateDate);

                                        res.FollowersCount = followers.Count;
                                        mapper.Merge(followers);
                                        followersMapper.SaveVKFollowers(usersVK.First().id, followers);
                                    }
                                    var subscriptions = VKConnection.getVKSubscriptions(usersVK.First().id.ToString(), vkAccount.token);
                                    if (subscriptions != null && subscriptions.Count() > 0)
                                    {
                                        SetUpdateDate(subscriptions.ToList<AbstractUser>(), updateDate);

                                        res.SubscriptionsCount = subscriptions.Count();
                                        mapper.Merge(subscriptions);
                                        followersMapper.SaveVKSubscriptions(usersVK.First().id, subscriptions);
                                    }
                                }
                            }

                            currentUser.current_count = currentUser.current_count + 1;
                            MsSQLDataOperator.UsersUpdate(currentUser);

                            res.State = OkStatus;
                            return new GenericResponse<PutUserResponse>(res);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                res.State = FailStatus;
                res.Message = ex.ToString();
                return new GenericResponse<PutUserResponse>(res);
            }
        }

        /// <summary>
        /// Получение ответа по пользователю OK на запрос типа 
        /// http://localhost:52147/api/users/getok?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&ok_id=1
        /// </summary>
        /// <param name="user_token">GUID  в базе данных SQL для текущего аккаунта [SocialAPI].[dbo].[Users]</param>
        /// <param name="OK_id">id проверяемого пользователя</param>
        /// <param name="real_time">необходимость запроса к БД SocialAPI, либо к социальной сети и БД SocialAPI</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("GetOK")]
        public GenericResponse<AbstractUser> GetOK(Guid user_token, long ok_id)
        {
            using (UserOKMapper mapper = new UserOKMapper(Neo4jClientSource.CreateClient()))
            {
                using (FriendsOKMapper friedsMapper = new FriendsOKMapper(Neo4jClientSource.CreateClient()))
                {
                    //Проверить токен пользователя в БД
                    Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                    if (currentUser == null)
                    {
                        return new GenericResponse<AbstractUser>(AccessIsDenied);
                    }

                    var res = mapper.Find(ok_id);
                    if (res != null)
                    {
                        res.Friends = friedsMapper.GetFriends(res);
                        res.ShouldSerialize = false;
                    }
                    currentUser.current_count = currentUser.current_count + 1;
                    MsSQLDataOperator.UsersUpdate(currentUser);
                    return new GenericResponse<AbstractUser>(res);
                }
            }
        }
        /// <summary>
        /// Загрузка данных о пользователе OK в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/putok?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&ok_id=1
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="ok_id"></param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("PutOK")]
        public GenericResponse<PutUserResponse> PutOK(Guid user_token, long ok_id, int count = 10000)
        {
            PutUserResponse res = new PutUserResponse { id = ok_id.ToString() };
            try
            {
                using (UserOKMapper mapper = new UserOKMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsOKMapper friedsMapper = new FriendsOKMapper(Neo4jClientSource.CreateClient()))
                    {

                        //Проверить токен пользователя в БД
                        Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                        if (currentUser == null)
                        {
                            res.State = FailStatus;
                            res.Message = AccessIsDenied;
                            return new GenericResponse<PutUserResponse>(res);
                        }
                        else
                        {
                            var okAccount = MsSQLDataOperator.GetGoodAccountOK();//получаем токен OK
                            if (okAccount == null)
                            {
                                res.State = FailStatus;
                                return new GenericResponse<PutUserResponse>(res);
                            }

                            var usersOK = OKConnection.getOKUsers(ok_id.ToString(), okAccount);//получаем пользователя
                            if (usersOK != null && usersOK.Count() > 0)
                            {
                                DateTime updateDate = DateTime.Now;
                                usersOK.First().updateDate = updateDate;

                                mapper.Merge(usersOK.First());
                                var friends = OKConnection.getOKFriends(ok_id, okAccount);
                                if (friends != null)
                                    SetUpdateDate(friends.ToList<AbstractUser>(), updateDate);
                                if (friends != null && friends.Count > 0)
                                {
                                    res.FriendsCount = friends.Count;
                                    mapper.Merge(friends);
                                    friedsMapper.SaveOKFriend(ok_id, friends);
                                }
                            }
                        }

                        currentUser.current_count = currentUser.current_count + 1;
                        MsSQLDataOperator.UsersUpdate(currentUser);

                        res.State = OkStatus;
                        return new GenericResponse<PutUserResponse>(res);
                    }
                }
            }
            catch (Exception ex)
            {
                res.State = FailStatus;
                res.Message = ex.ToString();
                return new GenericResponse<PutUserResponse>(res);
            }
        }

        /// <summary>
        /// Загрузка данных о пользователе Twitter в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/puttwitter?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&sc_nm=nezsssss
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="sc_nm">screen name - идентификатор пользователя Twitter в адресной строке twitter.com/screen_name</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("PutTwitter")]
        public GenericResponse<PutUserResponse> PutTwitter(Guid user_token, string sc_nm, int count = 10000, bool fast_followers = true)
        {
            PutUserResponse res = new PutUserResponse();
            AccountManagerTwitter twAccount = null;
            try
            {
                using (UserTwitterMapper mapper = new UserTwitterMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsTwitterMapper friendsMapper = new FriendsTwitterMapper(Neo4jClientSource.CreateClient()))
                    {
                        using (FollowersTwitterMapper followersMapper = new FollowersTwitterMapper(Neo4jClientSource.CreateClient()))
                        {

                            //Проверить токен пользователя в БД
                            Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);

                            if (currentUser == null)
                            {
                                res.State = FailStatus;
                                res.Message = AccessIsDenied;
                                return new GenericResponse<PutUserResponse>(res);
                            }
                            else
                            {
                                twAccount = MsSQLDataOperator.GetGoodAccountTwitter();//получаем токен Twitter

                                var usersTwitter = TwitterConnection.getTwitterUsers(sc_nm, ref twAccount);//получаем пользователя
                                if (usersTwitter != null && usersTwitter.Count() > 0)
                                {
                                    DateTime updateDate = DateTime.Now;

                                    UserTwitter curent_twitter_user = usersTwitter.First();
                                    curent_twitter_user.updateDate = updateDate;

                                    res.id = curent_twitter_user.id.ToString();

                                    mapper.Merge(usersTwitter.First());
                                    var friends = TwitterConnection.getTwitterFriends(curent_twitter_user, ref twAccount);
                                    if (friends != null && friends.Count > 0)
                                    {
                                        SetUpdateDate(friends.ToList<AbstractUser>(), updateDate);

                                        res.FriendsCount = friends.Count;
                                        mapper.Merge(friends);
                                        friendsMapper.SaveTwitterFriend(curent_twitter_user.id, friends);
                                    }
                                    List<UserTwitter> followers = null;
                                    if (fast_followers)
                                    {
                                        var ids = TwitterConnection.getTwitterFollowersIDs(curent_twitter_user, ref twAccount);
                                        if (ids != null && ids.Count() > 0)
                                        {
                                            followers = ids.Select(x => new UserTwitter { id = x }).ToList();
                                        }
                                    }
                                    else
                                    {
                                        followers = TwitterConnection.getTwitterFollowers(curent_twitter_user, ref twAccount, count);
                                    }
                                    if (followers != null && followers.Count > 0)
                                    {
                                        SetUpdateDate(followers.ToList<AbstractUser>(), updateDate);

                                        res.FollowersCount = followers.Count;
                                        mapper.Merge(followers);
                                        followersMapper.SaveTwitterFollowers(curent_twitter_user.id, followers);
                                    }
                                }
                            }

                            currentUser.current_count = currentUser.current_count + 1;
                            MsSQLDataOperator.UsersUpdate(currentUser);

                            res.State = OkStatus;
                            return new GenericResponse<PutUserResponse>(res);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                res.State = FailStatus;
                res.Message = ex.ToString();
                return new GenericResponse<PutUserResponse>(res);
            }
            finally
            {
                if (twAccount != null)
                {
                    MsSQLDataOperator.AccountTwitterSetIsUsed(twAccount, false); //устанавливаем для теущего аккаунта признак - неиспользуется
                }
            }
        }

        /// <summary>
        /// Получение ответа по пользователю Twitter на запрос типа 
        /// http://localhost:52147/api/users/gettwitter?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&sc_nm=tomkruz
        /// </summary>
        /// <param name="user_token">GUID  в базе данных SQL для текущего аккаунта [SocialAPI].[dbo].[Users]</param>
        /// <param name="sc_nm">screen name проверяемого пользователя</param>
        /// <returns></returns>
        [HttpGet("GetTwitter")]
        public GenericResponse<AbstractUser> GetTwitter(Guid user_token, string sc_nm)
        {
            using (UserTwitterMapper mapper = new UserTwitterMapper(Neo4jClientSource.CreateClient()))
            {
                using (FriendsTwitterMapper friedsMapper = new FriendsTwitterMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FollowersTwitterMapper followersMapper = new FollowersTwitterMapper(Neo4jClientSource.CreateClient()))
                    {
                        //Проверить токен пользователя в БД
                        Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                        if (currentUser == null)
                        {
                            return new GenericResponse<AbstractUser>(AccessIsDenied);
                        }

                        var res = mapper.FindScreen_name(sc_nm);
                        if (res != null)
                        {
                            res.Friends = friedsMapper.GetFriends(res).ToList();
                            res.Followers = followersMapper.GetFollowers(res).ToList();
                            res.ShouldSerialize = false;
                        }
                        currentUser.current_count = currentUser.current_count + 1;
                        MsSQLDataOperator.UsersUpdate(currentUser);
                        return new GenericResponse<AbstractUser>(res);
                    }
                }
            }
        }

        /// <summary>
        /// Получение ответа по пользователю Facebook на запрос типа 
        /// http://localhost:52147/api/users/getfacebook?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&user_url=https://www.facebook.com/erchik
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="user_url"></param>
        /// <returns></returns>
        [HttpGet("GetFacebook")]
        public GenericResponse<AbstractUser> GetFacebook(Guid user_token, string user_url)
        {
            using (UserFacebookMapper mapper = new UserFacebookMapper(Neo4jClientSource.CreateClient()))
            {
                using (FriendsFacebookMapper friendsMapper = new FriendsFacebookMapper(Neo4jClientSource.CreateClient()))
                {
                    //Проверить токен пользователя в БД
                    Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                    if (currentUser == null)
                    {
                        return new GenericResponse<AbstractUser>(AccessIsDenied);
                    }

                    UserFacebook res = mapper.Find(user_url);
                    if (res != null)
                    {
                        res.Friends = friendsMapper.GetFriends(res).ToList();
                        res.ShouldSerialize = false;
                    }
                    currentUser.current_count = currentUser.current_count + 1;
                    MsSQLDataOperator.UsersUpdate(currentUser);
                    return new GenericResponse<AbstractUser>(res);
                }
            }
        }

        /// <summary>
        /// Загрузка данных о пользователе OK в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/putfacebook?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&user_url=https://www.facebook.com/erchik
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="user_url">ссылка на страницу пользователя</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("PutFacebook")]
        public GenericResponse<PutUserResponse> PutFacebook(Guid user_token, string user_url, int count = 10000)
        {
            PutUserResponse res = new PutUserResponse { id = user_url };
            try
            {
                using (UserFacebookMapper mapper = new UserFacebookMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsFacebookMapper friendsMapper = new FriendsFacebookMapper(Neo4jClientSource.CreateClient()))
                    {

                        //Проверить токен пользователя в БД
                        Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                        if (currentUser == null)
                        {
                            res.State = FailStatus;
                            res.Message = AccessIsDenied;
                            return new GenericResponse<PutUserResponse>(res);
                        }
                        else
                        {
                            var userFacebook = MsSQLDataOperator.RunParseUserFacebookPage(user_url);//получаем пользователя

                            if (userFacebook != null)
                            {
                                DateTime updateDate = DateTime.Now;
                                userFacebook.updateDate = updateDate;

                                var friends = userFacebook.Friends;
                                if (friends != null)
                                    SetUpdateDate(friends.ToList<AbstractUser>(), updateDate);
                                userFacebook.Friends = null;

                                mapper.Merge(userFacebook);

                                if (friends != null && friends.ToList().Count() > 0)
                                {
                                    res.FriendsCount = friends.ToList().Count();
                                    mapper.Merge(friends);
                                    friendsMapper.SaveFacebookFriend(user_url, friends);
                                }
                            }
                        }

                        currentUser.current_count = currentUser.current_count + 1;
                        MsSQLDataOperator.UsersUpdate(currentUser);

                        res.State = OkStatus;

                        return new GenericResponse<PutUserResponse>(res);

                    }
                }
            }
            catch (Exception ex)
            {
                res.State = FailStatus;
                res.Message = ex.ToString();
                return new GenericResponse<PutUserResponse>(res);
            }
        }


        /// <summary>
        /// Загрузка данных о пользователе OK в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/findfacebook?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&user_url=https://www.facebook.com/erchik
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="user_url">ссылка на страницу пользователя</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("Findfacebook")]
        public GenericResponse<AbstractUser> Findfacebook(Guid user_token, string user_url, int count = 10000)
        {
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                UserFacebook userFacebook = null;
                if (currentUser == null)
                {
                    return new GenericResponse<AbstractUser>(AccessIsDenied);
                }
                else
                {
                    userFacebook = MsSQLDataOperator.RunParseUserFacebookPage(user_url);//получаем пользователя
                }

                currentUser.current_count = currentUser.current_count + 1;
                MsSQLDataOperator.UsersUpdate(currentUser);

                return new GenericResponse<AbstractUser>(userFacebook);

            }
            catch (Exception ex)
            {
                return new GenericResponse<AbstractUser>(ex.ToString());
            }
        }

        /// <summary>
        /// Загрузка данных о пользователе Instagram в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/putinstagram?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&username=t.tratata
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="username">имя пользователя</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("PutInstagram")]
        public GenericResponse<PutUserResponse> PutInstagram(Guid user_token, string username, int count = 10000)
        {
            PutUserResponse res = new PutUserResponse { id = username };
            try
            {
                using (UserInstagramMapper mapper = new UserInstagramMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FollowersInstagramMapper followersMapper = new FollowersInstagramMapper(Neo4jClientSource.CreateClient()))
                    {

                        //Проверить токен пользователя в БД
                        Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                        if (currentUser == null)
                        {
                            res.State = FailStatus;
                            res.Message = AccessIsDenied;
                            return new GenericResponse<PutUserResponse>(res);
                        }
                        else
                        {
                            var userInstagram = MsSQLDataOperator.RunParseUserInstagramPage(username, count);//получаем пользователя
                            if (userInstagram != null)
                            {
                                DateTime updateDate = DateTime.Now;
                                userInstagram.updateDate = updateDate;
                                if (userInstagram.Followers != null)
                                    SetUpdateDate(userInstagram.Followers.ToList<AbstractUser>(), updateDate);
                                if (userInstagram.Followings != null)
                                    SetUpdateDate(userInstagram.Followings.ToList<AbstractUser>(), updateDate);

                                var followers = userInstagram.Followers;
                                var followings = userInstagram.Followings;

                                userInstagram.Followers = null;
                                userInstagram.Followings = null;

                                mapper.Merge(userInstagram);

                                if (followers != null && followers.ToList().Count() > 0)
                                {
                                    res.FollowersCount = followers.ToList().Count();
                                    mapper.Merge(followers);
                                    followersMapper.SaveInstagramFollowers(userInstagram.id, followers);
                                }

                                if (followings != null && followings.ToList().Count() > 0)
                                {
                                    res.SubscriptionsCount = followings.ToList().Count();
                                    mapper.Merge(followings);
                                    followersMapper.SaveInstagramSubscriptions(userInstagram.id, followings);
                                }
                            }
                        }

                        currentUser.current_count = currentUser.current_count + 1;
                        MsSQLDataOperator.UsersUpdate(currentUser);

                        res.State = OkStatus;

                        return new GenericResponse<PutUserResponse>(res);

                    }
                }
            }
            catch (Exception ex)
            {
                res.State = FailStatus;
                res.Message = ex.ToString();
                return new GenericResponse<PutUserResponse>(res);
            }
        }

        /// <summary>
        /// Загрузка данных о пользователе OK в БД neo4j 
        /// запрос типа http://localhost:52147/api/users/findinstagram?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&username=erchik
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="username">ссылка на страницу пользователя</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("FindInstagram")]
        public GenericResponse<AbstractUser> FindInstagram(Guid user_token, string username, int count = 10000)
        {
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                UserInstagram userInstagram = null;
                if (currentUser == null)
                {
                    return new GenericResponse<AbstractUser>(AccessIsDenied);
                }
                else
                {
                    userInstagram = MsSQLDataOperator.RunParseUserInstagramPage(username, count);//получаем пользователя
                }

                currentUser.current_count = currentUser.current_count + 1;
                MsSQLDataOperator.UsersUpdate(currentUser);

                return new GenericResponse<AbstractUser>(userInstagram);

            }
            catch (Exception ex)
            {
                return new GenericResponse<AbstractUser>(ex.ToString());
            }
        }

        /// <summary>
        /// Получение ответа по пользователю Instagram на запрос типа 
        /// http://localhost:52147/api/users/getinstagram?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&username=erchik
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="username">имя пользователя</param>
        /// <param name="count">количество подписчиков (друзья получаются все)</param>
        /// <returns></returns>
        [HttpGet("GetInstagram")]
        public GenericResponse<AbstractUser> GetInstagram(Guid user_token, string username, int count = 10000)
        {
            using (UserInstagramMapper mapper = new UserInstagramMapper(Neo4jClientSource.CreateClient()))
            {
                using (FollowersInstagramMapper followersMapper = new FollowersInstagramMapper(Neo4jClientSource.CreateClient()))
                {
                    //Проверить токен пользователя в БД
                    Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                    if (currentUser == null)
                    {
                        return new GenericResponse<AbstractUser>(AccessIsDenied);
                    }

                    UserInstagram res = mapper.Find(username);
                    if (res != null)
                    {
                        res.Followers = followersMapper.GetFollowers(res).ToList();
                        res.Followings = followersMapper.GetSubscriptions(res).ToList();
                        res.ShouldSerialize = false;
                    }
                    currentUser.current_count = currentUser.current_count + 1;
                    MsSQLDataOperator.UsersUpdate(currentUser);
                    return new GenericResponse<AbstractUser>(res);
                }
            }
        }
    }
}
