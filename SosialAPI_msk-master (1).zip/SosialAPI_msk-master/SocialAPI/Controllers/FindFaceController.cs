﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using SocialAPI.DataOperators;

using SocialAPI.Models;
using SocialAPI.Models.FindFace;

namespace SocialAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FindFaceController : ControllerBase
    {

        /// <summary>
        /// Получение ответа по пользователю ВКонтакте на запрос типа 
        /// http://localhost:52147/api/users/putfindface?user_token=07dd29ff-1bf8-48da-0272-08d729f8df1b&vk_id=1
        /// </summary>
        /// <param name="user_token"></param>
        /// <param name="vk_id"></param>
        /// <returns></returns>
        [HttpPost("PostFindFace")]
        public async Task<GenericResponse<FindFaceResult>> PostFindFace(Guid user_token, int deph)
        {
            FindFaceResult res = null;
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                if (currentUser == null)
                {
                    return new GenericResponse<FindFaceResult>("доступ запрещен");
                }

                var file = HttpContext.Request.Form.Files.First();

                byte[] fileByteArray = null;
                using (var ms = new MemoryStream())
                {
                    file.CopyTo(ms);
                    fileByteArray = ms.ToArray();
                }

                res = FindFaceDataOperator.RunSearch(fileByteArray, file.Name, deph);
            }
            catch (Exception ex)
            {

            }
            return new GenericResponse<FindFaceResult>(res);
        }

        
    }
}
