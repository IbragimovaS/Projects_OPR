﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;
using SocialAPI.Models.SocialNetworks.Facebook;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.Models.MsSQL.AccountManager;
using OpenQA.Selenium.Interactions;
using System.Collections.ObjectModel;
using HtmlAgilityPack;

namespace SocialAPI.Selenium
{
    public static class FacebookSeleniumManager
    {

        /// <summary>
        /// Получить текущего (авторизовавшегося) пользователя
        /// </summary>
        /// <returns></returns>
        public static UserFacebook getCurrentFacebookUser(AccountManagerFacebook currentAccount, ChromeDriver driver)
        {
            UserFacebook user = null;
            try
            {
                if (!String.IsNullOrEmpty(currentAccount.cookie_string))
                {
                    LoginByCookie(currentAccount, driver);
                    user = getCurrentUser(driver);
                }
                else
                {
                    Login(currentAccount, driver);
                    user = getCurrentUser(driver);
                }
            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка Selenium.getCurrentFacebookUser. Текст ошибки {0}", ex.ToString()));
            }
            return user;
        }

        /// <summary>
        /// Получает данные о текущем пользователе с его страницы
        /// </summary>
        /// <param name="driver"></param>
        /// <returns></returns>
        private static UserFacebook getCurrentUser(ChromeDriver driver)
        {
            UserFacebook user = null;
            try
            {
                IWebElement element = null;
                IWebElement elementToolBar = null;
                elementToolBar = driver.FindElement(By.Id("pagelet_navigation"));
                ReadOnlyCollection<IWebElement> aElem = elementToolBar.FindElements(By.TagName("a"));
                Actions actions = new Actions(driver);
                actions.MoveToElement(aElem[1]).Click().Build().Perform();

                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(4);

                element = driver.FindElement(By.Id("fb-timeline-cover-name")); //_1vp5

                var imgsAltXPath = driver.FindElement(By.XPath("//img[contains(@class,'_11kf img')]"));

                user = new UserFacebook() { Name = element.Text, ImageURL = imgsAltXPath.GetAttribute("src") };
            }
            catch(Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Selenium.getCurrentUser. Текст ошибки {1}", ex.ToString()));
            }

            return user;
        }

        static string ParseId(string page)
        {
            string pattern = "?id=";
            string id = page.Substring(page.IndexOf(pattern) + pattern.Length, page.Length - (page.IndexOf(pattern) + pattern.Length));
            return id;
        }

        /// <summary>
        /// Получить пользователя с друзьями
        /// </summary>
        /// <param name="id"></param>
        /// <param name="cnn"></param>
        /// <returns></returns>
        public static UserFacebook getUserFacebookWithFriends(string page, ChromeDriver driver)
        {
            UserFacebook result = null;
            try
            {
                result = getUserWithFriends(page, driver);

                //Пользователь с таким идентификатором не найден
                if (result == null || String.IsNullOrEmpty(result.Name))
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Selenium.getUserFacebookWithFriends. Параметры page {0}. Текст ошибки {1}",
                    page, ex.ToString()));
            }
            return result;
        }

        /// <summary>
        /// Получить модель пользователя Facebook по странице
        /// </summary>
        /// <param name="page"></param>
        /// <returns></returns>
        private static UserFacebook getUserWithFriends(string page, ChromeDriver driver)
        {
            UserFacebook result = new UserFacebook();
            try
            {
                if (page.IndexOf("?id=") > 0)
                {
                    result.Page = page.IndexOf("&") > 0 ? page.Substring(0, page.IndexOf("&")) : page;
                }
                else
                {
                    result.Page = page.IndexOf("?") > 0 ? page.Substring(0, page.IndexOf("?")) : page;
                }

                //загрузка профиля
                driver.Navigate().GoToUrl(result.Page);

                var element = driver.FindElement(By.Id("fb-timeline-cover-name"));

                result.Name = element.Text;

                var imgsAltXPath = driver.FindElement(By.XPath("//img[contains(@class,'_11kf img')]"));
                result.ImageURL = imgsAltXPath.GetAttribute("src");

                getFacebookFriends(result, driver);
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка GetUserWithFriends. Текст ошибки {0} uid {1}", ex.Message, page));
            }

            return result;
        }

        /// <summary>
        /// Получить список друзей пользователя Facebook
        /// </summary>
        /// <param name="result"></param>
        private static void getFacebookFriends(UserFacebook result, ChromeDriver driver)
        {
            try
            {
                //загрузка друзей

                string friendsUrl = driver.Url.IndexOf("?id=") > 0 ? driver.Url + "&sk=friends" : driver.Url + "/friends";
                driver.Navigate().GoToUrl(friendsUrl);

                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
                //прокрутка до конца страницы
                driver.ExecuteScript("window.scrollTo(0, document.body.scrollHeight)");

                while (needToLoadMore(driver))
                {
                    driver.ExecuteScript("window.scrollTo(0, document.body.scrollHeight)");
                };

                //получаем друзей
                var friends = new List<UserFacebook>();
                var document = new HtmlDocument();
                document.LoadHtml(driver.PageSource);
                var friendBlocks = document.DocumentNode.Descendants("li").ToArray();

                for (int i = 0; i < friendBlocks.Count(); i++)
                {
                    string name = String.Empty, page = String.Empty, image = String.Empty;
                    var chNodes = friendBlocks.ElementAt(i).Descendants().ToArray();

                    for (int ii = 0; ii < chNodes.Count(); ii++)
                    {
                        HtmlNode htmlNode = chNodes.ElementAt(ii);
                        if (htmlNode.Attributes["class"] != null)

                            if (htmlNode.Attributes["class"].Value == "fsl fwb fcb")
                            {
                                name = htmlNode.InnerText;
                                page = htmlNode.Descendants("a").ElementAt(0).Attributes["href"].Value;


                                if (page.IndexOf("?") > 0)
                                {
                                    if (page.IndexOf("?id=") > 0)
                                    {
                                        page = page.Substring(0, page.IndexOf("&"));
                                    }
                                    else
                                    {
                                        page = page.Substring(0, page.IndexOf("?"));
                                    }
                                }
                            }

                        if (htmlNode.Attributes["class"] != null)
                            if (htmlNode.Attributes["class"].Value.EndsWith("_rv img") || htmlNode.Attributes["class"].Value.EndsWith("_rw img"))
                            {
                                image = htmlNode.Attributes["src"].DeEntitizeValue;
                            }
                    }

                    if (!String.IsNullOrEmpty(page))
                    {
                        friends.Add(new UserFacebook { Page = page, Name = name, ImageURL = image });
                    }

                }
                result.Friends = friends;
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка FacebookConnection.GetFriends. Текст ошибки {0} uid {1}", ex.Message, result.Page));
            }
        }


        /// <summary>
        /// Вход в аккаунт Facebook
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="login"></param>
        /// <param name="password"></param>
        public static void Login(AccountManagerFacebook accaunt, ChromeDriver driver)
        {
            driver.Navigate().GoToUrl("https://www.facebook.com/");
            Thread.Sleep(1000);
            var email = driver.FindElementByName("email");
            var pass = driver.FindElementByName("pass");
            driver.FindElement(By.Name("email")).SendKeys(accaunt.user_name);
            driver.FindElement(By.Name("pass")).SendKeys(accaunt.user_password);
            Thread.Sleep(1000);

            pass.Submit();
            Thread.Sleep(1000);
        }

        /// <summary>
        /// Вход в аккаунт Facebook с использованем куки
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="login"></param>
        /// <param name="password"></param>
        public static void LoginByCookie(AccountManagerFacebook accaunt, ChromeDriver driver)
        {
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Navigate().GoToUrl("https://www.facebook.com/");
            ReadCookiefromString(driver, accaunt.cookie_string);
            Thread.Sleep(1000);
            driver.Navigate().Refresh();
            Thread.Sleep(1000);
        }

        /// <summary>
        /// Метод проверяет необходимость дальнейшей прокрутки браузера
        /// </summary>
        /// <param name="driver"></param>
        /// <returns></returns>
        private static bool needToLoadMore(ChromeDriver driver)
        {
            IWebElement elem;
            try
            {
                elem = driver.FindElementById("pagelet_timeline_medley_photos");
            }
            catch (Exception ex)
            {
                elem = null;
            }
            return elem == null ? true : false;
        }

        /// <summary>
        /// Формирует куки из строки и добавляет их в ChromeDriver
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="cookStr"></param>
        private static void ReadCookiefromString(ChromeDriver driver, string cookStr)
        {
            try
            {
                string[] array = cookStr.Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

                foreach (String line in array)
                {
                    string[] words = line.Split(';');
                    {
                        String name = words[0];
                        String value = words[1];

                        Cookie ck = new Cookie(name, value);
                        driver.Manage().Cookies.AddCookie(ck); // This will add the stored cookie to your current session					
                    }

                }
            }
            catch (Exception exx)
            {
                string exception = exx.ToString();
            }
        }

    }
}
