﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;
using SocialAPI.Models.SocialNetworks.Facebook;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.Models.MsSQL.AccountManager;
using OpenQA.Selenium.Interactions;
using System.Collections.ObjectModel;
using HtmlAgilityPack;
using SocialAPI.Models.SocialNetworks.Instagram;
using Newtonsoft.Json;
using System.IO;
using SocialAPI.Models.MsSQL.BotometrModel;

namespace SocialAPI.Selenium
{
    public static class InstagramSeleniumManager
    {

        /// <summary>
        /// Получить текущего (авторизовавшегося) пользователя
        /// </summary>
        /// <returns></returns>
        public static UserInstagram getCurrentInstagramUser(AccountManagerInstagram currentAccount, ChromeDriver driver)
        {
            UserInstagram res = null;
            try
            {
                Login(currentAccount, driver);
                Thread.Sleep(3000);

                string resp = string.Empty;

                driver.Navigate().GoToUrl(string.Format("https://www.instagram.com/{0}/?__a=1", currentAccount.user_name));

                resp = driver.PageSource;

                int startIndex = 84;
                int length = resp.Length - startIndex - @"</pre></body></html>".Length;
                resp = resp.Substring(startIndex, length);
                res = JsonConvert.DeserializeObject<UserRoot>(resp).graphql.user;

            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка InstagramSeleniumManager.getCurrentInstagramUser. Текст ошибки {0}. Ответ {1}", ex.Message, ex.ToString()));
                if (ex.Message == "Превышен лимит запросов instagram - ошибка 429")
                {
                    throw new Exception("Превышен лимит запросов instagram - ошибка 429");
                }
            }



            return res;
        }

        /// <summary>
        /// Получить пользователя без друзей
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public static UserInstagram GetUser(string username, ChromeDriver driver, int count)
        {
            UserInstagram result = null;
            string resp = string.Empty;
            try
            {
                driver.Navigate().GoToUrl(string.Format("https://www.instagram.com/{0}/?__a=1", username));

                resp = GetinnerText(driver);

                result = JsonConvert.DeserializeObject<UserRoot>(resp).graphql.user;

            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка InstagramSeleniumManager.GetUser. Текст ошибки {0}. Ответ {1}", ex.Message, resp));
                if (ex.Message == "Превышен лимит запросов instagram - ошибка 429")
                {
                    throw new Exception("Превышен лимит запросов instagram - ошибка 429");
                }
            }
            return result;
        }


        /// <summary>
        /// Получить текст содержащий json без html тегов
        /// </summary>
        /// <param name="driver"></param>
        /// <returns></returns>
        private static string GetinnerText(ChromeDriver driver)
        {
            string resp = driver.PageSource;
            int startIndex = 84;
            int length = resp.Length - startIndex - @"</pre></body></html>".Length;
            resp = resp.Substring(startIndex, length);
            return resp;
        }

        /// <summary>
        /// Получить подписчиков
        /// </summary>
        /// <param name="id">идентификатор пользователя</param>
        /// <param name="maxCount">максимальное количество получаемых пользователей</param>
        /// <param name="currentCount">текущее количество получаемых пользователей</param>
        /// <param name="nextPage">идентификатор следующей страницы</param>
        /// <returns></returns>
        public static string GetFollowers(long id, ChromeDriver driver, ref  int currentCount, ref string nextPage,ref List<UserInstagram> result, ref string stat, int maxCount = 1000)
        {
            string response = String.Empty;
           
            string resp = string.Empty;
            FollowRoot fr = null;
            MessageStatus status = null;


            try
            {
                string query = string.Format("https://www.instagram.com/graphql/query/?query_hash=37479f2b8209594dde7facb0d904896a&id={0}&first=50", id);

                if (!String.IsNullOrEmpty(nextPage))
                {
                    query = string.Format("{0}&after={1}", query, nextPage);
                }

                GetResponse(driver, out resp, out status, query);

                if (String.Equals(status.message, "rate limited"))
                {
                    stat = status.message;
                    return status.message;
                }
                    fr = JsonConvert.DeserializeObject<FollowRoot>(resp);
                var r1 = fr.data.user.edge_followed_by.edges.Select(x => x.node);

                if (r1 != null && r1.Count() > 0)
                {
                    currentCount = r1.Count() + currentCount;
                    result.AddRange(r1);

                    if (currentCount < fr.data.user.edge_followed_by.count && currentCount < maxCount)
                    {
                        nextPage = fr.data.user.edge_followed_by.page_info.end_cursor;
                        GetFollowers(id, driver, ref currentCount, ref nextPage, ref result,ref stat, maxCount);
                        //result.AddRange();
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка InstagramSeleniumManager.GetFollowed. Текст ошибки {0}. Ответ {1}", ex.Message, resp));

            }


            return stat;
        }

        /// <summary>
        /// Получение ответа от сервера (если вернулась обшибка то ожидание)
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="resp"></param>
        /// <param name="status"></param>
        /// <param name="query"></param>
        private static void GetResponse(ChromeDriver driver, out string resp, out MessageStatus status, string query)
        {
                driver.Navigate().GoToUrl(query);
                resp = GetinnerText(driver);

                status = JsonConvert.DeserializeObject<MessageStatus>(resp);
        }

        public class MessageStatus
        {
            public string message { get; set; }
            public string status { get; set; }
        }


        /// <summary>
        /// Получить подписки
        /// </summary>
        /// <param name="id">идентификатор пользователя</param>
        /// <param name="maxCount">максимальное количество получаемых пользователей</param>
        /// <param name="currentCount">текущее количество получаемых пользователей</param>
        /// <param name="nextPage">идентификатор следующей страницы</param>
        /// <returns></returns>
        public static string GetFollowings(long id, ChromeDriver driver, ref int currentCount, ref string nextPage, ref List<UserInstagram> result, ref string stat, int maxCount = 1000)
        {
            string resp = string.Empty;
            FollowRoot fr = null;
            MessageStatus status = null;
            try
            {
                string query = string.Format("https://www.instagram.com/graphql/query/?query_hash=58712303d941c6855d4e888c5f0cd22f&id={0}&first=50", id);

                if (!String.IsNullOrEmpty(nextPage))
                {
                    query = string.Format("{0}&after={1}", query, nextPage);
                }

                GetResponse(driver, out resp, out status, query);

                if (String.Equals(status.message, "rate limited"))
                {
                    stat = status.message;
                    return status.message;
                }

                fr = JsonConvert.DeserializeObject<FollowRoot>(resp);
                var r1 = fr.data.user.edge_follow.edges.Select(x => x.node);

                if (r1 != null && r1.Count() > 0)
                {
                    currentCount = r1.Count() + currentCount;
                    result.AddRange(r1);

                    if (currentCount < fr.data.user.edge_follow.count && currentCount < maxCount)
                    {
                        nextPage = fr.data.user.edge_follow.page_info.end_cursor;
                        GetFollowings(id, driver, ref currentCount, ref nextPage, ref result, ref stat, maxCount);
                        //result.AddRange(GetFollowings(id, driver, maxCount, currentCount, fr.data.user.edge_follow.page_info.end_cursor));
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка InstagramSeleniumManager.GetFollow. Текст ошибки {0}. Ответ {1}", ex.Message, resp));
                if (ex.Message == "Превышен лимит запросов instagram - ошибка 429")
                {
                    throw new Exception("Превышен лимит запросов instagram - ошибка 429");
                }
            }
            return stat;
        }


        /// <summary>
        /// Вход в аккаунт Facebook
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="login"></param>
        /// <param name="password"></param>
        public static void Login(AccountManagerInstagram accaunt, ChromeDriver driver)
        {
            driver.Navigate().GoToUrl("https://www.instagram.com/accounts/login/");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(4);
            var email = driver.FindElementByName("username");
            var pass = driver.FindElementByName("password");
            driver.FindElement(By.Name("username")).SendKeys(accaunt.user_name);
            driver.FindElement(By.Name("password")).SendKeys(accaunt.user_password);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(0);
            pass.Submit();
        }

    }
}
