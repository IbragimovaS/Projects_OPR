﻿using Microsoft.AspNetCore.Mvc.Testing;
using SocialAPI.Models.SocialNetworks.Instagram;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace SocialAPI.Selenium.IntegrationTests
{
    public class UserInstagramData
    {
        public UserInstagram data { get; set; }
    }


    public class InstagramIntegrationTest : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly WebApplicationFactory<Startup> _factory;

        public InstagramIntegrationTest(WebApplicationFactory<Startup> factory)
        {
            _factory = factory;
        }


        [Fact]
        public async Task Get_Test1()
        {
            try
            {
                // Arrange
                var client = _factory.CreateClient();

                // Act
                var user_token = "07dd29ff-1bf8-48da-0272-08d729f8df1b";
                List<string> pages = new List<string>();
                //pages.Add("khazarovavalentina");
                //pages.Add("tais_psy");
                pages.Add("anastasiiasmirno");

                List<Task> tasks = new List<Task>();

                foreach (string page in pages)
                {
                    var url = String.Format(@"/api/users/getinstagram?user_token={0}&username={1}", user_token, page);
                    tasks.Add(client.GetAsync(url));
                }

                await Task.WhenAll(tasks);

                List<UserInstagram> instList = new List<UserInstagram>();
                foreach (Task<HttpResponseMessage> t in tasks)
                {
                    using (HttpContent content = t.Result.Content)
                    {
                        UserInstagramData userInstagram = null;
                        if (t.Result.IsSuccessStatusCode)
                        {
                            userInstagram = await t.Result.Content.ReadAsAsync<UserInstagramData>();
                        }
                        if (userInstagram.data != null)
                            instList.Add(userInstagram.data);
                    }
                }
                Assert.True(instList.Count > 0, "Количество возвращенных сервером пользователей должно быть больше 0");

            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task Put_Test2()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {

                    // Act
                    var user_token = "07dd29ff-1bf8-48da-0272-08d729f8df1b";

                    List<string> pages = new List<string>();
                    //pages.Add("khazarovavalentina");
                    //pages.Add("tais_psy");
                    //pages.Add("anastasiiasmirno");
                    pages.Add("annabuzova");


                    List<Task> tasks = new List<Task>();

                    foreach (string page in pages)
                    {
                        var url = String.Format(@"/api/users/putinstagram?user_token={0}&username={1}&count=30000", user_token, page);
                        tasks.Add(client.GetAsync(url));
                    }

                    await Task.WhenAll(tasks);

                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        var data = await t.Result.Content.ReadAsAsync<ExpandoObject>();
                    }

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task Find_Test3()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {

                    // Act
                    var user_token = "07dd29ff-1bf8-48da-0272-08d729f8df1b";


                    string username = "anastasiiasmirno";

                    List<Task> tasks = new List<Task>();
                    var url = String.Format(@"/api/users/findinstagram?user_token={0}&username={1}", user_token, username);
                    tasks.Add(client.GetAsync(url));

                    await Task.WhenAll(tasks);

                    List<UserInstagram> fbList = new List<UserInstagram>();

                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        using (HttpContent content = t.Result.Content)
                        {
                            UserInstagramData userInstagram = null;
                            if (t.Result.IsSuccessStatusCode)
                            {
                                userInstagram = await t.Result.Content.ReadAsAsync<UserInstagramData>();
                            }
                            if (userInstagram.data != null)
                                fbList.Add(userInstagram.data);
                        }
                    }

                    Assert.True(fbList.Count > 0, "Сервер должен вернуть пользователя");

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }


        [Fact]
        public async Task Update_Test4()
        {
            var client = _factory.CreateClient();
            SocialAPI.Updater.Instagram.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 1000, client);
            Updater.Instagram.Program.Run();

        }
    }
}
