﻿using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;
using SocialAPI.Models.SocialNetworks.Facebook;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace SocialAPI.Selenium.IntegrationTests
{
    public class UserFacebookData
    {
        public UserFacebook data { get; set; }
    }

    public class FacebookIntegrationTest : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly WebApplicationFactory<Startup> _factory;

        public FacebookIntegrationTest(WebApplicationFactory<Startup> factory)
        {
            _factory = factory;
        }


        [Fact]
        public async Task Get_Test1()
        {
            try
            {
                // Arrange
                var client = _factory.CreateClient();
                // Act
                var user_token = "07dd29ff-1bf8-48da-0272-08d729f8df1b";
                var user_url = "https://www.facebook.com/erchic";

                var url = String.Format(@"/api/users/getfacebook?user_token={0}&user_url={1}", user_token, user_url);

                List<Task> tasks = new List<Task>();

                for (int i = 0; i < 3; i++)
                {
                    tasks.Add(client.GetAsync(url));
                }
                await Task.WhenAll(tasks);

                List<UserFacebook> fbList = new List<UserFacebook>();

                foreach (Task<HttpResponseMessage> t in tasks)
                {
                    using (HttpContent content = t.Result.Content)
                    {
                        UserFacebookData userFacebook = null;
                        if (t.Result.IsSuccessStatusCode)
                        {
                            userFacebook = await t.Result.Content.ReadAsAsync<UserFacebookData>();
                        }
                        if (userFacebook.data != null)
                            fbList.Add(userFacebook.data);
                    }
                }

                Assert.True(fbList.Count > 0, "Количество возвращенных сервером пользователей должно быть больше 0");

            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task Put_Test2()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {

                    // Act
                    var user_token = "07dd29ff-1bf8-48da-0272-08d729f8df1b";

                    List<string> pages = new List<string>();
                    //pages.Add("https://www.facebook.com/erchic");
                    //pages.Add("https://www.facebook.com/lula.roz");
                    //pages.Add("https://www.facebook.com/profile.php?id=100005059326153");
                    // pages.Add("https://www.facebook.com/sergey.yakovlev.9");

                    List<Task> tasks = new List<Task>();

                    foreach (string page in pages)
                    {
                        var url = String.Format(@"/api/users/putfacebook?user_token={0}&user_url={1}", user_token, page);
                        tasks.Add(client.GetAsync(url));
                    }

                    await Task.WhenAll(tasks);

                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        var data = await t.Result.Content.ReadAsAsync<ExpandoObject>();
                    }

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task Find_Test3()
        {
            try
            {
                // Arrange
                using (HttpClient client = _factory.CreateClient())
                {

                    // Act
                    var user_token = "07dd29ff-1bf8-48da-0272-08d729f8df1b";


                    string page = "https://www.facebook.com/erchic";


                    List<Task> tasks = new List<Task>();
                    var url = String.Format(@"/api/users/findfacebook?user_token={0}&user_url={1}", user_token, page);
                    tasks.Add(client.GetAsync(url));

                    await Task.WhenAll(tasks);

                    List<UserFacebook> fbList = new List<UserFacebook>();

                    foreach (Task<HttpResponseMessage> t in tasks)
                    {
                        using (HttpContent content = t.Result.Content)
                        {
                            UserFacebookData userFacebook = null;
                            if (t.Result.IsSuccessStatusCode)
                            {
                                userFacebook = await t.Result.Content.ReadAsAsync<UserFacebookData>();
                            }
                            if (userFacebook.data != null)
                                fbList.Add(userFacebook.data);
                        }
                    }

                    Assert.True(fbList.Count > 0, "Сервер должен вернуть пользователя");

                }
            }
            catch (Exception ex)
            {
                string ec = ex.ToString();
            }
        }

        [Fact]
        public async Task Update_Test4()
        {
            var client = _factory.CreateClient();
            SocialAPI.Updater.Facebook.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 1000, client);
            Updater.Facebook.Program.Run();
        }

    }
}
