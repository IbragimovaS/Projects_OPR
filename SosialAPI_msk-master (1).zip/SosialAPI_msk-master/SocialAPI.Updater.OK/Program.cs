﻿using SocialAPI.Mappers.Neo4j;
using System;
using SocialAPI.Models.SocialNetworks.OK;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using SocialAPI.DataOperators;
using SocialAPI.Connections;
using SocialAPI.Models.MsSQL.History;
using SocialAPI.Mappers.Neo4j.OK;
using System.Threading;
using SocialAPI.Models.SocialNetworks;
using System.Diagnostics;

namespace SocialAPI.Updater.OK
{

    /// <summary>
    /// При настройке запуска приложения по времени,  необходимо открыть вкладку действия
    /// в поле "Программа или сценарий" ввести dotnet
    /// В поле "Добавить аргументы" прописать путь к SocialAPI.Updater.OK.dll
    /// C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\SocialAPI.Updater.OK.dll 07DD29FF-1BF8-48DA-0272-08D729F8DF1B 203 false
    /// При необходимости в поле "Рабочая папка" прописать путь к папке содержащей SocialAPI.Updater.OK.dll НАПРИМЕР - C:\Users\4Centr\source\repos\ConsoleApp3\ConsoleApp3\bin\Debug\netcoreapp2.1\
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Служебное поле - массив полей Reflection
        /// </summary>
        public static PropertyInfo[] props;
        /// <summary>
        /// Служебное поле - массив наименований полей
        /// </summary>
        public static List<string> propNameList;
        /// <summary>
        /// Как в АПИ - количество подписчиков (друзья получаются все)
        /// </summary>
        public static int count;
        /// <summary>
        /// Как в АПИ - быстрое получение подписчиков (получаются только идентификаторы подписчиков, если true - параметр count игнорируется)
        /// </summary>
        public static bool fast_followers;

        /// <summary>
        /// Токен для доступа к БД
        /// </summary>
        public static Guid user_token;

        /// <summary>
        /// Признак запуска обновления данных
        /// </summary>
        public static bool isRuning;

        /// <summary>
        /// Список полей, изменение значений которых не нужно сохранять в истории 
        /// </summary>
        public static List<string> notUpdatePropNameList;


        static void Main(string[] args)
        {
            try
            {
                MsSQLDataOperator.ParseArgs(args, ref user_token, ref count);

                if (3 <= args.Length)
                    bool.TryParse(args[2], out fast_followers);

                Init(user_token, count, fast_followers);

                Run();
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Updater.OK.Program.Main(string[] args). Текст ошибки {0}", ex.ToString()));
            }
        }

       

        /// <summary>
        /// Инициализация всех установок
        /// </summary>
        public static void Init(Guid usr_token, int cnt, bool fastF)
        {
            Type t = (typeof(UserOK));

            MsSQLDataOperator.InitCommon(usr_token, cnt, t, ref propNameList, ref props, ref count, ref user_token, ref isRuning);

            notUpdatePropNameList = new List<string>() {
                "location"
                ,"last_online"
            };
            
            fast_followers = fastF;
        }

        /// <summary>
        /// Основная процедура
        /// </summary>
        public static void Run()
        {
            try
            {
                //Проверить токен пользователя в БД
                Models.MsSQL.User currentUser = MsSQLDataOperator.UsersFind(user_token);
                if (currentUser == null)
                {
                    throw new Exception("Для пользователя user_token = \"" + user_token.ToString() + "\" не выполнен вход.");
                }
                var okAccount = MsSQLDataOperator.GetGoodAccountOK();//получаем токен одноклассиноков
                if (okAccount == null)
                {
                    Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Updater.OK.Program.Run. Текст ошибки {0}", "Закончились хорошие аккунты для OK.RU"));
                    throw new Exception("Закончились хорошие аккунты для OK.RU");
                }
                using (UserOKMapper mapper = new UserOKMapper(Neo4jClientSource.CreateClient()))
                {
                    using (FriendsOKMapper friedsMapper = new FriendsOKMapper(Neo4jClientSource.CreateClient()))
                    {

                        while (isRuning)
                        {
                            Dictionary<string, string> instance_values_db = new Dictionary<string, string>();
                            Dictionary<string, string> instance_values_socialNet = new Dictionary<string, string>();
                            UserOK curentOK_db = getLastValue();
                            UserOK curentOK_socialNet = null;

                            if (curentOK_db == null) //Если в базе отсутствует запись т ждем 5 минут 
                            {
                                Thread.Sleep(5000 * 60);
                                continue;
                            }

                            #region Получение данных из БД
                            if (curentOK_db != null)
                            {

                                curentOK_db.Friends = friedsMapper.GetFriends(curentOK_db);
                                fillDictionaty(curentOK_db, ref instance_values_db);
                            }

                            #endregion

                            #region Получение данных из социальной сети

                            var getData = OKConnection.getOKUsers(curentOK_db.uid.ToString(), okAccount);
                            if (getData == null || getData.Count() == 0)
                            {
                                okAccount = MsSQLDataOperator.GetGoodAccountOK();
                                if (okAccount != null)
                                    continue;
                                else 
                                    throw new Exception("Закончились хорошие аккунты для OK.RU");

                            }
                            curentOK_socialNet = getData.First();

                            DateTime updateDate = DateTime.Now;
                            if (curentOK_socialNet != null)
                            {
                                curentOK_socialNet.updateDate = updateDate;

                                var friends = OKConnection.getOKFriends(curentOK_db.uid, okAccount);
                                if (friends != null && friends.Count > 0)
                                {
                                    curentOK_socialNet.Friends = friends;
                                    MsSQLDataOperator.SetUpdateDate(curentOK_socialNet.Friends.ToList<AbstractUser>(), updateDate);

                                }
                                fillDictionaty(curentOK_socialNet, ref instance_values_socialNet);
                            }

                            #endregion


                            #region Пользователь есть в БД - сравниваем

                            if (curentOK_db != null && curentOK_socialNet != null)
                            {
                                bool isNeedMerge_Friends = false;
                                foreach (string propName in propNameList.Where(item => !notUpdatePropNameList.Any(item2 => item2 == item)))
                                {
                                    string oldValue = instance_values_db[propName] == null ? String.Empty : instance_values_db[propName];
                                    string newValue = instance_values_socialNet[propName] == null ? String.Empty : instance_values_socialNet[propName];

                                    if (!oldValue.Equals(newValue))
                                    {
                                        AddHistory(curentOK_db.uid, propName, oldValue, newValue, updateDate);

                                        if (propName.Equals("Friends"))
                                            isNeedMerge_Friends = true;

                                    }
                                }
                                #region Если есть необходимость - обновляем данные БД Neo
                                List<UserOK> friends = null;
                                if (curentOK_socialNet.Friends != null && curentOK_db.Friends != null)
                                    friends = curentOK_socialNet.Friends.Where(item => !curentOK_db.Friends.Any(item2 => item2.uid == item.uid)).ToList();
                                else if (curentOK_socialNet.Friends != null) friends = curentOK_socialNet.Friends.ToList();

                                curentOK_socialNet.Friends = null;

                                //обновляем текущего пользователя всегда, так как нужно записать новую ubdateDate в neo4j
                                mapper.UpdateMerge(curentOK_socialNet);
                                if (isNeedMerge_Friends)
                                {
                                    if (friends != null && friends.Count() > 0)
                                    {
                                        mapper.Merge(friends);
                                        friedsMapper.SaveOKFriend(curentOK_socialNet.uid, friends);
                                    }
                                }
                                #endregion
                            }
                            #endregion
                        }

                    }
                }
            }
            catch(Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка SocialAPI.Updater.OK.Program.Run. Текст ошибки {0}", ex.ToString()));
            }
        }
        /// <summary>
        /// Возвращает пользователя запись о котором была сделана раньше всего
        /// </summary>
        /// <returns></returns>
        public static UserOK getLastValue()
        {
            UserOKMapper mapper = new UserOKMapper(Neo4jClientSource.CreateClient());
            UserOK oldestUser = mapper.FindOldestRecord();
            return oldestUser;
        }
        /// <summary>
        /// Заполняет список пар "атрибут"-"значение" для указанного пользователя
        /// </summary>
        /// <param name="props"></param>
        /// <param name="curentOK"></param>
        /// <param name="dic"></param>
        static void fillDictionaty(UserOK curentOK, ref Dictionary<string, string> dic)
        {
            foreach (var prop in props)
            {
                string attrName = prop.Name;
                object attrValue = prop.GetValue(curentOK);
                if (attrValue != null)
                {
                    if (attrName.Equals("Friends"))
                    {
                        dic.Add(attrName, curentOK.Friends.Count().ToString());
                    }
                    else
                    {
                        dic.Add(attrName, attrValue.ToString());
                    }
                }
                else
                    dic.Add(attrName, null);//!!! TODO: Проверить значение 
            }
        }

        /// <summary>
        /// Добавляет запись истории изменений атрибута
        /// </summary>
        /// <param name="ok_uid">id пользователя в одноклассниках</param>
        /// <param name="propName">имя поля</param>
        /// <param name="oldValue">старое значение</param>
        /// <param name="newValue">новое значение</param>
        /// <param name="updateDate">дата обновления</param>
        static void AddHistory(long ok_uid, string propName, string oldValue, string newValue, DateTime updateDate)
        {
            HistoryOK history = new HistoryOK();
            history.rid = Guid.NewGuid();
            history.id_user_ok = ok_uid;
            history.attribute_name = propName;
            history.old_value = oldValue;
            history.new_value = newValue;
            history.date_change = updateDate;
            MsSQLDataOperator.HistoryOKAdd(history);
        }

    }
}
