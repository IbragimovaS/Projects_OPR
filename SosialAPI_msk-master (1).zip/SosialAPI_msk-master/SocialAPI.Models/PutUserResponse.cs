﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models
{
    /// <summary>
    /// Класс ответа при добавлении пользователя в БД нео
    /// </summary>
    public class PutUserResponse
    {
        /// <summary>
        /// Статус
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Ид добавленного пользователя
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// Количество добавленных друзей
        /// </summary>
        public int FriendsCount { get; set; }

        /// <summary>
        /// Количество добавленных подписчиков
        /// </summary>
        public int FollowersCount { get; set; }

        /// <summary>
        /// Количество добавленных подписок
        /// </summary>
        public int SubscriptionsCount { get; set; }

        /// <summary>
        /// Содержит сообщение для пользователя API
        /// </summary>
        public string Message { get; set; }
    }
}
