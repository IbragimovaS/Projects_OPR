﻿using System;
using System.Collections.Generic;
using System.Text;
using static SocialAPI.Models.FindFace.Search;

namespace SocialAPI.Models.FindFace
{
    public class FindFaceResult
    {
        /// <summary>
        /// Результаты поиска в VK
        /// </summary>
        public List<SearchResult> VKResult { get; set; }

        /// <summary>
        /// Результаты поиска в OK
        /// </summary>
        public List<SearchResult> OKResult { get; set; }
    }
}
