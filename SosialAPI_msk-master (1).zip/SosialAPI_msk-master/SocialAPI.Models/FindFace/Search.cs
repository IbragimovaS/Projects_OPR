﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.FindFace
{
    public class Search
    {
        public List<SearchResult> results { get; set; }

        public class SearchResult
        {
            public double similarity { get; set; }
            public double confidence { get; set; }
            public List<double> bbox { get; set; }
            public int width { get; set; }
            public int height { get; set; }
            public string photo_url_hash { get; set; }
            public long photo_id { get; set; }
            public long user_id { get; set; }
            public string photo_url { get; set; }
            public string profile_url { get; set; }

        }
    }
}
