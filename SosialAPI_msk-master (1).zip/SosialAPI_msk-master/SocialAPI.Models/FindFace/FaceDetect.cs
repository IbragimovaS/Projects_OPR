﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.FindFace
{
    public class FaceDetect
    {
        public string image_hash { get; set; }

        public List<int[]> bboxes { get; set; }
    }
}
