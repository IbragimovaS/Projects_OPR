﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
namespace SocialAPI.Models.MsSQL.History
{
    /// <summary>
    /// Абстрактный класс истории изменений
    /// </summary>
    public class HistoryAbstract
    {
        /// <summary>
        /// Первичный ключ
        /// </summary>
        [Key]
        [HiddenInput(DisplayValue = false)]
        public Guid rid { get; set; }

        /// <summary>
        /// Дата изменений
        /// </summary>
        [Display(Name = "Дата изменений")]
        public DateTime date_change { get; set; }

        /// <summary>
        /// Тип значения
        /// </summary>
        [Display(Name = "Тип значения")]
        public string attribute_name { get; set; }

        /// <summary>
        /// Старое значение
        /// </summary>
        [Display(Name = "Старое значение")]
        public string old_value { get; set; }

        /// <summary>
        /// Новое значение
        /// </summary>
        [Display(Name = "Новое значение")]
        public string new_value { get; set; }
    }
}
