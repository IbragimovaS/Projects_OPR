﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.History
{
    /// <summary>
    /// Модель сущности истории изменений для "Фейсбук"
    /// </summary>
    public class HistoryFacebook : HistoryAbstract
    {
        /// <summary>
        /// Facebook Id
        /// </summary>
        [Display(Name = "Фейсбук Id")]
        public string id_user_facebook { get; set; }
    }
}
