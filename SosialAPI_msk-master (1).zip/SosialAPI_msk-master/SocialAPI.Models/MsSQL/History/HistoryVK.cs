﻿using SocialAPI.Models.MsSQL.History;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace SocialAPI.Models.MsSQL.History
{
    
    /// <summary>
    /// Модель сущности истории изменений для "ВКонтакте"
    /// </summary>
    public class HistoryVK : HistoryAbstract
    {
        /// <summary>
        /// ВКонтакте Id
        /// </summary>
        [Display(Name = "ВКонтакте Id")]
        public long id_user_vk { get; set; }
    }
}
