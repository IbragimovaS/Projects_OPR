﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace SocialAPI.Models.MsSQL.History
{
    /// <summary>
    /// Модель сущности истории изменений для "Инстаграм"
    /// </summary>
    public class HistoryInstagram : HistoryAbstract
    {
        /// <summary>
        /// Инстаграм Id
        /// </summary>
        [Display(Name = "Инстаграм Id")]
        public long id_user_instagram { get; set; }
    }
}
