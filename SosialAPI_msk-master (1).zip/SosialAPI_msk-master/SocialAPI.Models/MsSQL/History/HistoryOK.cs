﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.History
{
    /// <summary>
    /// Модель сущности истории изменений для "Одноклассники"
    /// </summary>
    public class HistoryOK : HistoryAbstract
    {
        /// <summary>
        /// Одноклассники Id
        /// </summary>
        [Display(Name = "Одноклассники Id")]
        public long id_user_ok { get; set; }
    }
}
