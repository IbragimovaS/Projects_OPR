﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.History
{
    /// <summary>
    /// Модель сущности истории изменений для "Twitter"
    /// </summary>
    public class HistoryTwitter : HistoryAbstract
    {
        /// <summary>
        /// Одноклассники Id
        /// </summary>
        [Display(Name = "Twitter Id")]
        public long id_user_twitter { get; set; }
    }
}
