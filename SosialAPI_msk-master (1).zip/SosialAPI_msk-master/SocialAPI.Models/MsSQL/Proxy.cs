﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace SocialAPI.Models.MsSQL
{
    public class Proxy
    {
        /// <summary>
        /// Первичный ключ
        /// </summary>
        [Key]
        [HiddenInput(DisplayValue = false)]
        public Guid rid { get; set; }

        /// <summary>
        /// Хост
        /// </summary>
        [Display(Name = "Хост")]
        public string host { get; set; } = string.Empty;

        /// <summary>
        /// Порт
        /// </summary>
        [Display(Name = "Порт")]
        public int port { get; set; } = 0;
        
        /// <summary>
        /// Время последнего использования
        /// </summary>
        [Display(Name = "Время последнего использования")]
        public DateTime last_usage { get; set; }

        /// <summary>
        /// Признак рабочего токена
        /// </summary>
        [Display(Name = "Токен рабочий")]
        public Boolean is_good { get; set; }

        /// <summary>
        /// Логин
        /// </summary>
        [Display(Name = "Логин")]
        public string login { get; set; }

        /// <summary>
        /// Пароль
        /// </summary>
        [Display(Name = "Пароль")]
        public string password { get; set; }
    }
}

