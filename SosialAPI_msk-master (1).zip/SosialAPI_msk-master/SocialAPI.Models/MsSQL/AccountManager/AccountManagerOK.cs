﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.AccountManager
{
    /// <summary>
    /// Модель сущности "Аккаунт Одноклассники"
    /// </summary>
    public class AccountManagerOK : AccountManagerAbstract
    {
        /// <summary>
        /// Токен
        /// </summary>
        [Display(Name = "Токен")]
        public string token { get; set; } = string.Empty;

        /// <summary>
        /// закрытый ключ сессии
        /// 
        /// </summary>
        [Display(Name = "Закрытый ключ сессии")]
        public string session_secret_key { get; set; } = string.Empty;
    }
}
