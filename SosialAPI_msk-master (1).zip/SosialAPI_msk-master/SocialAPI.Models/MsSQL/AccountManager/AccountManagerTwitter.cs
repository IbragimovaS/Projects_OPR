﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.AccountManager
{
    /// <summary>
    /// Модель сущности "Акаунт Твиттер"
    /// </summary>
    public class AccountManagerTwitter : AccountManagerAbstract
    {
        /// <summary>
        /// Делегат для события сохранения последнего времени использоватия при достижении 15 запросов
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="newOb"></param>
        /// <param name="limitOver">Признак ошибки 429 (превышение лимита вызова API методов)</param>
        public delegate void TimeIsComeEventHandler(AccountManagerTwitter sender, out AccountManagerTwitter newOb);

        public event TimeIsComeEventHandler TimeIsComeEvent;

        /// <summary>
        /// Токен
        /// </summary>
        [Display(Name = "Токен")]
        public string access_token { get; set; } = string.Empty;

        /// <summary>
        /// Секретный токен
        /// </summary>
        [Display(Name = "Секретный токен")]
        public string access_tokenSecret { get; set; } = string.Empty;

        /// <summary>
        /// Потребительский ключ
        /// </summary>
        [Display(Name = "Потребительский ключ")]
        public string consumerKey { get; set; } = string.Empty;

        /// <summary>
        /// Потребительский секрет
        /// </summary>
        [Display(Name = "Потребительский секрет")]
        public string consumerSecret { get; set; } = string.Empty;

        /// <summary>
        /// Признак того, что аккаунт используется
        /// </summary>
        [Display(Name = "Используется")]
        public Boolean is_used { get; set; }

        
        public void RaiseTimeIsComeEvent(out AccountManagerTwitter newOb)
        {
            newOb = null;
            if (TimeIsComeEvent != null)
                TimeIsComeEvent(this, out newOb);
        }
    }
}
