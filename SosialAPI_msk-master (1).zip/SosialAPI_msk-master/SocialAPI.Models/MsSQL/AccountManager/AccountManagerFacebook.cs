﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.AccountManager
{
    /// <summary>
    /// Модель сущности "Акаунт Фейсбук"
    /// </summary>
    public class AccountManagerFacebook : AccountManagerAbstract
    {
        /// <summary>
        /// Логин
        /// </summary>
        [Display(Name = "Логин")]
        public string user_name { get; set; } = string.Empty;

        /// <summary>
        /// Пароль
        /// </summary>
        [Display(Name = "Пароль")]
        public string user_password { get; set; } = string.Empty;

        /// <summary>
        /// Куки содержащие параметры сессии
        /// </summary>
        public string cookie_string { get; set; } = string.Empty;
    }
}
