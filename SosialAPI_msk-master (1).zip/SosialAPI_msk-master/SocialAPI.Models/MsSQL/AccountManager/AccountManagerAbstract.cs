﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.AccountManager
{
    /// <summary>
    /// Абстрактный класс аккаунта
    /// </summary>
    public abstract class AccountManagerAbstract
    {
        /// <summary>
        /// Первичный ключ
        /// </summary>
        [Key]
        [HiddenInput(DisplayValue = false)]
        public Guid rid { get; set; }

        /// <summary>
        /// Признак рабочего токена
        /// </summary>
        [Display(Name = "Токен рабочий")]
        public Boolean is_good { get; set; }

        /// <summary>
        /// Время последнего использования
        /// </summary>
        [Display(Name = "Время последнего использования")]
        public DateTime last_usage { get; set; }

    }
}
