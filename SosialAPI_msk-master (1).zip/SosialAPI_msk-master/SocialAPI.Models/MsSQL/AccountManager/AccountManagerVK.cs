﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL.AccountManager
{
    /// <summary>
    /// Модель сущности "Аккаунт ВКонтакте"
    /// </summary>
    public class AccountManagerVK : AccountManagerAbstract
    {
        /// <summary>
        /// Токен
        /// </summary>
        [Display(Name = "Токен")]
        public string token { get; set; } = string.Empty;
    }
}
