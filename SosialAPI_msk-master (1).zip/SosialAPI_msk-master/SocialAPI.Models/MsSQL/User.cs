﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SocialAPI.Models.MsSQL
{
    /// <summary>
    /// Модель сущности "Пользователь SocialAPI"
    /// </summary>
    public class User
    {
        /// <summary>
        /// Уникальный идентификатор - он же токен для авторизации
        /// </summary>
        [Key]
        [Display(Name = "Токен")]
        public Guid rid { get; set; }

        /// <summary>
        /// Имя пользователя
        /// </summary>
        [Display(Name = "Имя пользователя")]
        public string user_name { get; set; } = string.Empty;

        /// <summary>
        /// Название организации
        /// </summary>
        [Display(Name = "Название организации")]
        public string user_org { get; set; } = string.Empty;

        /// <summary>
        /// Дата с которой активен пользователь
        /// </summary>
        [Display(Name = "Активен с")]
        public DateTime allowed_from { get; set; }

        /// <summary>
        /// Дата до которой активен пользователь
        /// </summary>
        [Display(Name = "Активен до")]
        public DateTime allowed_to { get; set; }

        /// <summary>
        /// Разрешенное количество запросов
        /// </summary>
        [Display(Name = "Разрешенное количество запросов")]
        public int? allowed_count { get; set; }

        /// <summary>
        /// Текущее количество запросов
        /// </summary>
        [Display(Name = "Текущее количество запросов")]
        public int current_count { get; set; }
    }
}
