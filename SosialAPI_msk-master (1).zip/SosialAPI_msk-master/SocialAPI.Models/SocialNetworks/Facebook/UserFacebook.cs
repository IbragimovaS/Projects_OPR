﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace SocialAPI.Models.SocialNetworks.Facebook
{
    /// <summary>
    /// Модель пользователя Facebook
    /// </summary>
    public class UserFacebook : AbstractUser
    {
        /// <summary>
        /// Идентификатор пользователя
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// ссылка на главную страницу
        /// </summary>
        public string Page { get; set; }

        /// <summary>
        /// Имя пользователя
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Ссылка на аватарку
        /// </summary>
        public string ImageURL { get; set; }

        /// <summary>
        /// Путь к аватарке
        /// </summary>
        public string ImagePath { get; set; }

        /// <summary>
        /// Друзья
        /// </summary>
        public IEnumerable<UserFacebook> Friends { get; set; }


        [JsonIgnore]
        public bool ShouldSerialize { get; set; } = true;
    }
}
