﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.OK
{
    /// <summary>
    /// Местонахождение
    /// </summary>
  public  class Location
    {
        /// <summary>
        /// Город
        /// </summary>
        public string city { get; set; }

        /// <summary>
        /// Страна
        /// </summary>
        public string country { get; set; }

        /// <summary>
        /// Код страны
        /// </summary>
        public string countryCode { get; set; }

        /// <summary>
        /// Код страны на русском
        /// </summary>
        public string countryName { get; set; }
    }
}
