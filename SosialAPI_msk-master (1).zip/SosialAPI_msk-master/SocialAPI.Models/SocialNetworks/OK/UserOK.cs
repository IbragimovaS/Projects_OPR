﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.OK
{
    public class UserOK : AbstractUser
    {
        #region Конструктор  
        /// <summary>
        /// Список людей
        /// </summary>
        private static Dictionary<string, UserOK> _UserOKList = new Dictionary<string, UserOK>();


#endregion

        #region Свойства
        /// <summary>
        /// Идентификатор пользователя
        /// </summary>
        public long uid { get; set; }

        
        /// <summary>
        /// Возраст
        /// </summary>
        public int age { get; set; }


        /// <summary>
        /// имя пользователя
        /// </summary>
        public string first_name { get; set; }

        /// <summary>
        /// фамилия пользователя
        /// </summary>
        public string last_name { get; set; }


        /// <summary>
        ///  ссылка на аватар
        /// </summary>
        public string pic_full { get; set; }


        /// <summary>
        /// Дата рождения
        /// </summary>
        public string birthday { get; set; }


        /// <summary>
        /// язык пользователя
        /// </summary>
        public string locale { get; set; }

        /// <summary>
        /// пол
        /// </summary>
        public string gender { get; set; }


        /// <summary>
        /// местонахождение
        /// </summary>
        [JsonProperty("location")]
        public Location location { get; set; }

        string _location;
        /// <summary>
        /// местонахождение
        /// </summary>
        public string locationValue
        {
            get
            {
                if (String.IsNullOrEmpty(_location))
                    if (location != null)
                        _location = String.Format("Город: {0}; Страна: {1}; Код страны: {2}; Код страны на русском: {3}",
                            location.city, location.country, location.countryCode, location.countryName);
                return _location;
            }
            set
            {
                _location = value;
            }
        }

        /// <summary>
        /// официальная страница
        /// </summary>
        public string url_profile { get; set; }

        /// <summary>
        /// текущий статус
        /// </summary>
        public string current_status { get; set; }


        /// <summary>
        /// дата установки текущего статуса
        /// </summary>
        public string current_status_date { get; set; }

        /// <summary>
        /// дата последнего выхода в онлайн
        /// </summary>
        public string last_online { get; set; }

        /// <summary>
        /// Дата регистрации
        /// </summary>
        public string registered_date { get; set; }
                                
        /// <summary>
        /// Друзья
        /// </summary>
        public IEnumerable<UserOK> Friends { get; set; }


        #endregion

        [JsonIgnore]
        public bool ShouldSerialize { get; set; } = true;

        public bool ShouldSerializelocation()
        {
            return ShouldSerialize;
        }
        
    }
}
