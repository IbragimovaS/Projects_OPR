﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.OK
{
    /// <summary>
    /// Класс местоположения для Одноклассников
    /// </summary>
    public class OKLocation
    {
        /// <summary>
        /// город
        /// </summary>
        public string city { get; set; }

        /// <summary>
        /// наименование страны (англ.)
        /// </summary>
        public string country { get; set; }

        /// <summary>
        /// код страны
        /// </summary>
        public string countryCode { get; set; }

        /// <summary>
        /// наименование страны
        /// </summary>
        public string countryName { get; set; }
    }
}
