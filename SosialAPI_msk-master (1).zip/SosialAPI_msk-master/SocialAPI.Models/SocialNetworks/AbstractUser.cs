﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks
{
    /// <summary>
    /// Абстрактный класс пользователя социальной сети
    /// </summary>
    public abstract class AbstractUser
    {
        /// <summary>
        /// Дата обновления
        /// </summary>
        public DateTime updateDate { get; set; }
    }
}
