﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// Сведения о последнем посещении сайта
    /// </summary>
    public class LastSeen
    {
        /// <summary>
        /// время
        /// </summary>
        public int time { get; set; }

        /// <summary>
        /// тип платформы
        /// </summary>
        public int platform { get; set; }
    }
}
