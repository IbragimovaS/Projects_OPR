﻿namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// информация о карьере пользователя
    /// </summary>
    public class Career
    {
        /// <summary>
        /// идентификатор сообщества (если доступно, иначе company);
        /// </summary>
        public int group_id { get; set; }

        /// <summary>
        /// название компании (если доступно, иначе group_id);
        /// </summary>
        public string company { get; set; }

        /// <summary>
        ///  идентификатор страны;
        /// </summary>
        public int country_id { get; set; }

        /// <summary>
        /// идентификатор города (если доступно, иначе city_name);
        /// </summary>
        public int city_id { get; set; }

        /// <summary>
        /// название города (если доступно, иначе city_id);
        /// </summary>
        public string city_name { get; set; }

        /// <summary>
        /// год начала работы;
        /// </summary>
        public int from { get; set; }

        /// <summary>
        /// год окончания работы;
        /// </summary>
        public int until { get; set; }

        /// <summary>
        /// должность
        /// </summary>
        public string position { get; set; }

        public override string ToString()
        {
            return $"компания {company} в городе {city_name} c {from} по {until}. Должность {position}";
        }

    }
}