﻿namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// ВУЗ
    /// </summary>
    public class University
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// идентификатор страны, в которой расположен университет
        /// </summary>
        public int country { get; set; }

        /// <summary>
        /// идентификатор города, в котором расположен университет
        /// </summary>
        public int city { get; set; }

        /// <summary>
        /// наименование университета
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// идентификатор факультета
        /// </summary>
        public int faculty { get; set; }

        /// <summary>
        /// наименование факультета
        /// </summary>
        public string faculty_name { get; set; }

        /// <summary>
        /// идентификатор кафедры
        /// </summary>
        public int chair { get; set; }

        /// <summary>
        /// наименование кафедры
        /// </summary>
        public string chair_name { get; set; }

        /// <summary>
        /// год окончания обучения
        /// </summary>
        public int graduation { get; set; }

        /// <summary>
        /// форма обучения
        /// </summary>
        public string education_form { get; set; }

        /// <summary>
        /// статус (например, «Выпускник (специалист)»).
        /// </summary>
        public string education_status { get; set; }

        public override string ToString()
        {
            return $"{name} факультет {faculty_name} кафедра {chair_name}. Год окончания {graduation}. Форма обучения {education_form}. {education_status}";
        }
    }
}