﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// Географические понятия
    /// </summary>
    public class Geography
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Название
        /// </summary>
        public string title { get; set; }
    }
}
