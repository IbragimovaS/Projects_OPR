﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// Класс профиля пользователя ВКонтакте
    /// </summary>
    public class UserVK : AbstractUser
    {
        /// <summary>
        /// Идентификатор пользователя
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// короткий адрес страницы
        /// </summary>
        public string domain { get ; set; }

        /// <summary>
        /// ссылка на страницу пользователя
        /// </summary>
        public string page
        {
            get
            {
                return !String.IsNullOrEmpty(domain) ? $"https://vk.com/{domain}" : $"https://vk.com/id{id}";
            }
        }

        /// <summary>
        /// имя пользователя
        /// </summary>
        public string first_name { get; set; }

        /// <summary>
        /// фамилия польозвателя
        /// </summary>
        public string last_name { get; set; }

        /// <summary>
        /// url фотографии максимального размера
        /// </summary>
        public string photo_max_orig { get; set; }

        /// <summary>
        /// Список друзей
        /// </summary>
        public IEnumerable<UserVK> Friends { get; set; }

        /// <summary>
        /// Список подписчиков
        /// </summary>
        public IEnumerable<UserVK> Followers { get; set; }

        /// <summary>
        /// Список подписок
        /// </summary>
        public IEnumerable<UserVK> Subscriptions { get; set; }

        /// <summary>
        /// Количество подписчиков
        /// </summary>
        public int followers_count { get; set; }

        /// <summary>
        /// пол
        /// </summary>
        public int sex { get; set; }

        /// <summary>
        /// дата рождения
        /// </summary>
        public string bdate { get; set; }

        /// <summary>
        /// семейное положение
        /// </summary>
        public int relation { get; set; }

        /// <summary>
        /// город
        /// </summary>
        [JsonProperty("city")]
        public Geography City { get; set; }

        string _CityName;
        /// <summary>
        /// Наименование города
        /// </summary>
        public string CityName
        {
            get
            {
                if (String.IsNullOrEmpty(_CityName))
                    if (City != null)
                        _CityName = City.title;
                return _CityName;
            }
            set
            {
                _CityName = value;
            }
        }

        /// <summary>
        /// страна
        /// </summary>
        [JsonProperty("country")]
        public Geography Country { get; set; }

        string _CountryName;
        /// <summary>
        /// Наименование города
        /// </summary>
        public string CountryName
        {
            get
            {
                if (String.IsNullOrEmpty(_CountryName))
                    if (Country != null)
                        _CountryName = Country.title;
                return _CountryName;
            }
            set
            {
                _CountryName = value;
            }
        }

        /// <summary>
        /// мобильный телефон
        /// </summary>
        public string mobile_phone { get; set; }

        /// <summary>
        /// домашний телефон
        /// </summary>
        public string home_phone { get; set; }

        /// <summary>
        /// сведения о деактивации профиля
        /// </summary>
        public string deactivated { get; set; }

        /// <summary>
        /// сведения о закрытости профиля
        /// </summary>
        public bool is_closed { get; set; }

        /// <summary>
        /// девичья фамилия
        /// </summary>
        public string maiden_name { get; set; }

        /// <summary>
        /// никнейм (отчество) пользователя
        /// </summary>
        public string nickname { get; set; }

        /// <summary>
        /// информация о карьере пользователя
        /// </summary>
        [JsonProperty("career")]
        public IEnumerable<Career> Career { get; set; }

        string _career_list;
        /// <summary>
        /// Список мест работы
        /// </summary>
        public string career_list
        {
            get
            {
                if (String.IsNullOrEmpty(_career_list))
                    if (Career != null && Career.Count() > 0)
                    {
                        _career_list = String.Join("\n", Career);
                    }
                return _career_list;
            }
            set
            {
                _career_list = value;
            }
        }

        /// <summary>
        /// Сведения о военной службе
        /// </summary>
        [JsonProperty("military")]
        public IEnumerable<Military> Military { get; set; }

        string _military_list;
        /// <summary>
        /// Список мест службы
        /// </summary>
        public string military_list
        {
            get
            {
                if (String.IsNullOrEmpty(_military_list))
                    if (Military != null && Military.Count() > 0)
                    {
                        _military_list = String.Join("\n", Military);
                    }
                return _military_list;
            }
            set
            {
                _military_list = value;
            }
        }

        /// <summary>
        /// Сведения о высшем образовании
        /// </summary>
        [JsonProperty("universities")]
        public IEnumerable<University> Universities { get; set; }

        string _universities_list;
        /// <summary>
        /// Список ВУЗов
        /// </summary>
        public string universities_list
        {
            get
            {
                if (String.IsNullOrEmpty(_universities_list))
                    if (Universities != null && Universities.Count() > 0)
                    {
                        _universities_list = String.Join("\n", Universities);
                    }
                return _universities_list;
            }
            set
            {
                _universities_list = value;
            }
        }

        /// <summary>
        /// Сведения о школах
        /// </summary>
        [JsonProperty("schools")]
        public IEnumerable<School> Schools { get; set; }

        string _schools_list;
        /// <summary>
        /// Список школ
        /// </summary>
        public string schools_list
        {
            get
            {
                if (String.IsNullOrEmpty(_schools_list))
                    if (Schools != null && Schools.Count() > 0)
                    {
                        _schools_list = String.Join("\n", Schools);
                    }
                return _schools_list;
            }
            set
            {
                _schools_list = value;
            }
        }

        /// <summary>
        /// Последенее посещение сайта
        /// </summary>
        [JsonProperty("last_seen")]
        public LastSeen Last_seen { get; set; }

        int? _last_seen_platform;
        /// <summary>
        /// Платформа последнего посещения сайта
        /// </summary>
        public int? last_seen_platform
        {
            get
            {
                if (_last_seen_platform == null)
                    if (Last_seen != null)
                        _last_seen_platform = Last_seen.platform;
                return _last_seen_platform;
            }
            set
            {
                _last_seen_platform = value;
            }
        }

        DateTime _last_seen_time;
        /// <summary>
        /// Платформа последнего посещения сайта
        /// </summary>
        public DateTime last_seen_time
        {
            get
            {
                if (_last_seen_time == null || _last_seen_time == DateTime.MinValue)
                    if (Last_seen != null)
                    {
                        _last_seen_time = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                        _last_seen_time = _last_seen_time.AddSeconds(Last_seen.time).ToLocalTime();
                    }
                return _last_seen_time;
            }
            set
            {
                _last_seen_time = value;
            }
        }


        /// <summary>
        /// признак верифицированной страницы
        /// </summary>
        public bool verified { get; set; }

        #region Необходимость сериализации сложных полей
        /// <summary>
        /// Признак необходимости сериализации сложных полей
        /// </summary>
        [JsonIgnore]
        public bool ShouldSerialize { get; set; } = true;

        public bool ShouldSerializeCity()
        {
            return ShouldSerialize;
        }

        public bool ShouldSerializeCountry()
        {
            return ShouldSerialize;
        }

        public bool ShouldSerializeLast_seen()
        {
            return ShouldSerialize;
        }

        public bool ShouldSerializeCareer()
        {
            return ShouldSerialize;
        }

        public bool ShouldSerializeMilitary()
        {
            return ShouldSerialize;
        }

        public bool ShouldSerializeUniversities()
        {
            return ShouldSerialize;
        }

        public bool ShouldSerializeSchools()
        {
            return ShouldSerialize;
        }
        #endregion

    }
}
