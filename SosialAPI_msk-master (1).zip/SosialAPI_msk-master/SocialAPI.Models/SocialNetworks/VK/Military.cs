﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// Сведения о военной службе
    /// </summary>
    public class Military
    {
        /// <summary>
        /// номер части
        /// </summary>
        public string unit { get; set; }

        /// <summary>
        /// идентификатор части в базе данных VK
        /// </summary>
        public int unit_id { get; set; }

        /// <summary>
        /// идентификатор страны, в которой находится часть
        /// </summary>
        public int country_id { get; set; }

        /// <summary>
        /// год начала службы
        /// </summary>
        public int from { get; set; }

        /// <summary>
        /// год окончания службы
        /// </summary>
        public int until { get; set; }

        public override string ToString()
        {
            return $"в/ч {unit} c {from} по {until}";
        }

    }
}
