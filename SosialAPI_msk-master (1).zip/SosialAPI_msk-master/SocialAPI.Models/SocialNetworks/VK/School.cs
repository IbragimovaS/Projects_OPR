﻿namespace SocialAPI.Models.SocialNetworks.VK
{
    /// <summary>
    /// Школа
    /// </summary>
    public class School
    {
        /// <summary>
        /// Идентификатор
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// идентификатор страны, в которой расположена школа
        /// </summary>
        public int country { get; set; }

        /// <summary>
        /// идентификатор города, в котором расположена школа
        /// </summary>
        public int city { get; set; }

        /// <summary>
        /// наименование школы
        /// </summary>
        public string name { get; set; }

        /// <summary>
        ///  год начала обучения
        /// </summary>
        public int year_from { get; set; }

        /// <summary>
        /// год окончания обучения
        /// </summary>
        public int year_to { get; set; }

        /// <summary>
        /// год выпуска
        /// </summary>
        public int year_graduated { get; set; }

        /// <summary>
        /// буква класса
        /// </summary>
        public string @class { get; set; }

        /// <summary>
        /// специализация
        /// </summary>
        public string speciality { get; set; }

        /// <summary>
        /// идентификатор типа
        /// </summary>
        public int type { get; set; }

        /// <summary>
        /// название типа
        /// </summary>
        public string type_str { get; set; }

        public override string ToString()
        {
            return $"{name} c {year_from} по {year_to} класс {@class} {speciality} {type_str}";
        }

    }
}