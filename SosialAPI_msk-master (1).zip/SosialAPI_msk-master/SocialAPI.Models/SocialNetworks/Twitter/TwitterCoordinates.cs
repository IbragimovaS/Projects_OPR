﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.Twitter
{
    public class TwitterCoordinates
    {
        public string type { get; set; }
        public List<double> coordinates { get; set; }
    }
}
