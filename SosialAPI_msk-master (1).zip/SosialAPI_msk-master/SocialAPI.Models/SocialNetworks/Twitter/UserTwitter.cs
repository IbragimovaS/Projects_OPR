﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.Twitter
{
    public class UserTwitter : AbstractUser
    {
        #region Конструктор  
        /// <summary>
        /// Список людей
        /// </summary>
        private static Dictionary<string, UserTwitter> _UserTwitterList = new Dictionary<string, UserTwitter>();


        #endregion

        #region Свойства
        /// <summary>
        /// Страница пользователя
        /// </summary>
        public string Page
        {
            get
            {
                return "https://twitter.com/" + screen_name;
            }
        }
        /// <summary>
        /// Путь к сохраненной фотографии на локальном диске
        /// </summary>
        public string photo_local_path { get; set; }

        /// <summary>
        /// идентификатор
        /// </summary>
        public long id { get; set; }

        /// <summary>
        /// имя
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// имя в адресной строке
        /// </summary>
        public string screen_name { get; set; }

        /// <summary>
        /// ссылка на сайт
        /// </summary>
        public string location { get; set; }

        /// <summary>
        /// статус
        /// </summary>
        public string description { get; set; }

        /// <summary>
        /// количество подписчиков
        /// </summary>
        public int followers_count { get; set; }

        /// <summary>
        /// количество друзей
        /// </summary>
        public int friends_count { get; set; }

        /// <summary>
        /// дата создания
        /// </summary>
        public string created_at { get; set; }

        /// <summary>
        /// статус
        /// </summary>
        //public TwitterStatus status { get; set; }

        /// <summary>
        /// ссылка на аватарку
        /// </summary>
        public string profile_image_url { get; set; }

        /// <summary>
        /// Список друзей
        /// </summary>
        public List<UserTwitter> Friends { get; set; }

        /// <summary>
        /// Список подписчиков
        /// </summary>
        public List<UserTwitter> Followers { get; set; }
        #endregion


        [JsonIgnore]
        public bool ShouldSerialize { get; set; } = true;

        /* // поле location не является "сложным"
        public bool ShouldSerializelocation()
        {
            return ShouldSerialize;
        }
        */
    }

    public class twResponse
    {
        public List<UserTwitter> users { get; set; }
        public string next_cursor_str { get; set; }
        public string previous_cursor_str { get; set; }
    }

    public class twResponseIds
    {
        public List<long> ids { get; set; }
        public string next_cursor_str { get; set; }
        public string previous_cursor_str { get; set; }
    }

}
