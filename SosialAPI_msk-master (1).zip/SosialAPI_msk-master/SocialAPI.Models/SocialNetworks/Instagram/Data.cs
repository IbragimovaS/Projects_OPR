﻿namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Данные для десериализации
    /// </summary>
    public class Data
    {
        public User user { get; set; }
    }
}
