﻿using System;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Класс для десериализации подписчиков и подписок
    /// </summary>
    public class FollowRoot
    {
        /// <summary>
        /// Данные
        /// </summary>
        public Data data { get; set; }

        /// <summary>
        /// Статус запроса
        /// </summary>
        public string status { get; set; }
    }
}
