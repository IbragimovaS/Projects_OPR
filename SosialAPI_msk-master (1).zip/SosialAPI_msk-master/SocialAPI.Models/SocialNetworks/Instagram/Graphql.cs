﻿namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// вспомогательный класс для десериализации данных по пользователю
    /// </summary>
    public class Graphql
    {
        public UserInstagram user { get; set; }
    }
}
