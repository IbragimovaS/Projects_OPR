﻿namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Информация о следующей странице
    /// </summary>
    public class PageInfo
    {
        /// <summary>
        /// Есть ли следующая страница - всегда выдается true - видимо не работает
        /// </summary>
        public bool has_next_page { get; set; }

        /// <summary>
        /// идентификатор следующей страницы - его необходимо подставлять для запроса в параметр &after=
        /// </summary>
        public string end_cursor { get; set; }
    }
}
