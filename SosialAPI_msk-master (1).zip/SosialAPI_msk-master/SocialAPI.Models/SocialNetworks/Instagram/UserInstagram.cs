﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Класс пользователя Инстаграмм
    /// </summary>
    public class UserInstagram : AbstractUser
    {
        /// <summary>
        /// идентификатор пользователя
        /// </summary>
        public long id { get; set; }

        /// <summary>
        /// имя страницы
        /// </summary>
        public string username { get; set; }

        /// <summary>
        /// имя пользователя
        /// </summary>
        public string full_name { get; set; }

        /// <summary>
        /// ссылка на изображение пользователя
        /// </summary>
        public string profile_pic_url { get; set; }

        /// <summary>
        /// Верифицированный аккаунт
        /// </summary>
        public bool is_verified { get; set; }

        /// <summary>
        /// Ссылка на страницу пользователя
        /// </summary>
        public string Page
        {
            get
            {
                return "https://www.instagram.com/" + username;
            }
        }

        /// <summary>
        /// Описание страницы
        /// </summary>
        public string biography { get; set; }

        /// <summary>
        /// Сайт
        /// </summary>
        public string external_url { get; set; }

        /// <summary>
        /// Количество подписчиков
        /// </summary>
        [JsonProperty("edge_followed_by")]
        public FCount edge_followed_by { get; set; }

        string _edge_followed_by;
        /// <summary>
        /// местонахождение
        /// </summary>
        public string edge_followed_byValue
        {
            get
            {
                if (String.IsNullOrEmpty(_edge_followed_by))
                    if (edge_followed_by != null)
                        _edge_followed_by = edge_followed_by.count.ToString();
                return _edge_followed_by;
            }
            set
            {
                _edge_followed_by = value;
            }
        }


        /// <summary>
        /// Количество подписок
        /// </summary>
        [JsonProperty("edge_follow")]
        public FCount edge_follow { get; set; }

        string _edge_follow;
        /// <summary>
        /// Количество подписок
        /// </summary>
        public string edge_followValue
        {
            get
            {
                if (String.IsNullOrEmpty(_edge_follow))
                    if (edge_follow != null)
                        _edge_follow = edge_follow.count.ToString();
                return _edge_follow;
            }
            set
            {
                _edge_follow = value;
            }
        }



        /// <summary>
        /// Подписчики
        /// </summary>
        public IEnumerable<UserInstagram> Followers { get; set; }


        /// <summary>
        /// Подписки
        /// </summary>
        public IEnumerable<UserInstagram> Followings { get; set; }

        /// <summary>
        /// Деловой аккаунт
        /// </summary>
        public bool is_business_account { get; set; }

        /// <summary>
        /// Электронная почта
        /// </summary>
        public string business_email { get; set; }

        /// <summary>
        /// Номер телефона
        /// </summary>
        public string business_phone_number { get; set; }

        /// <summary>
        /// Закрытый акаунт
        /// </summary>
        public bool is_private { get; set; }


        [JsonIgnore]
        public bool ShouldSerialize { get; set; } = true;

        public bool ShouldSerializeedge_followed_by()
        {
            return ShouldSerialize;
        }
        public bool ShouldSerializeedge_follow()
        {
            return ShouldSerialize;
        }
            
    }
}
