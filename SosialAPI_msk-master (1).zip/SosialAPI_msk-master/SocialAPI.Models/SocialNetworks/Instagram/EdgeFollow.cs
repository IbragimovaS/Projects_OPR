﻿using System.Collections.Generic;

namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Подписки и подписанные
    /// </summary>
    public class EdgeFollow
    {
        /// <summary>
        /// Количество пользователей
        /// </summary>
        public int count { get; set; }

        /// <summary>
        /// Информация о странице
        /// </summary>
        public PageInfo page_info { get; set; }
        public List<Edge> edges { get; set; }
    }
}
