﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Класс для десериализации пользователя инстаграм
    /// </summary>
    public class UserRoot
    {
        public string logging_page_id { get; set; }
        public bool show_suggested_profiles { get; set; }
        public Graphql graphql { get; set; }
    }
}
