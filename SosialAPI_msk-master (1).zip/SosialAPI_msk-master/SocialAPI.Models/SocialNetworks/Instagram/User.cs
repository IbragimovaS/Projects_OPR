﻿namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// класс для десериализации данных по пользователю
    /// </summary>
    public class User
    {
        /// <summary>
        /// Подписки
        /// </summary>
        public EdgeFollow edge_follow { get; set; }

        /// <summary>
        /// Подписанные
        /// </summary>
        public EdgeFollow edge_followed_by { get; set; }
    }
}
