﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Класс для десериализации количества подписчиков и подписок
    /// </summary>
    public class FCount
    {
        public int count { get; set; }

    }

   
}
