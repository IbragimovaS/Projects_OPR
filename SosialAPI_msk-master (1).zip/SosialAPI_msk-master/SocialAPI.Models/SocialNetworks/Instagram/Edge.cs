﻿namespace SocialAPI.Models.SocialNetworks.Instagram
{
    /// <summary>
    /// Класс для десериализации подписок/подписчиков
    /// </summary>
    public class Edge
    {
        public UserInstagram node { get; set; }
    }
}
