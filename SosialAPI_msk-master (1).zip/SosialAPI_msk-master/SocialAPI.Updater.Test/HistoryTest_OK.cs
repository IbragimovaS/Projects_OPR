using SocialAPI.Mappers.Neo4j;
using SocialAPI.Mappers.Neo4j.OK;
using SocialAPI.Models.SocialNetworks.OK;
using System;
using System.Collections.Generic;
using System.Reflection;
using Xunit;

namespace SocialAPI.Updater.Test
{
    public class HistoryTest_OK
    {
        /// <summary>
        /// ��������� ����� ������ ������
        /// </summary>
        [Fact]
        public void findOldestRecordTest1()
        {
            UserOKMapper mapper = new UserOKMapper(Neo4jClientSource.CreateClient());
            UserOK oldestUser= mapper.FindOldestRecord();
            Assert.True(oldestUser !=null, "������ ��� OK ����������� � neo4j");
        }


        [Fact]
        public void RunTest2()
        {
            SocialAPI.Updater.OK.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 1000, true);
            SocialAPI.Updater.OK.Program.Run();
            Assert.True(true);
        }
    }
}
