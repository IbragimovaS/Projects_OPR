using SocialAPI.Mappers.Neo4j;
using SocialAPI.Mappers.Neo4j.Twitter;
using SocialAPI.Models.SocialNetworks.Twitter;
using System;
using System.Collections.Generic;
using System.Reflection;
using Xunit;

namespace SocialAPI.Updater.Test
{
    public class HistoryTest_Twitter
    {
        /// <summary>
        /// ��������� ����� ������ ������
        /// </summary>
        [Fact]
        public void findOldestRecordTest1()
        {
            UserTwitterMapper mapper = new UserTwitterMapper(Neo4jClientSource.CreateClient());
            UserTwitter oldestUser = mapper.FindOldestRecord();
            Assert.True(oldestUser !=null, "������ ��� Twitter ����������� � neo4j");
        }


        [Fact]
        public void RunTest2()
        {
            Twitter.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 1000, true);
            Twitter.Program.Run();
            Assert.True(true);
        }
    }
}
