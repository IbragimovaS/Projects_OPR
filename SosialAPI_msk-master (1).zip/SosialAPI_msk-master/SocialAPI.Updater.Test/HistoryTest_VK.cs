using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Reflection;
using Xunit;

namespace SocialAPI.Updater.Test
{
    public class HistoryTest_VK
    {
        [Fact]
        public void Test1()
        {
            string lastvalue = SocialAPI.Updater.VK.Program.getLastValue().ToString();
            long result;
            bool valid = long.TryParse(lastvalue, out result);
            Assert.True(valid);
        }

        [Fact]
        public void Test2()
        {
            SocialAPI.Updater.VK.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 1000, true);
            Assert.True(true);
        }

        [Fact]
        public void Test3()
        {
            SocialAPI.Updater.VK.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 20, true);
            SocialAPI.Updater.VK.Program.Run();
            Assert.True(true);
        }

        [Fact]
        public void Test4()
        {
            DateTime a;
            DateTime sss = DateTime.MinValue;
           
            Assert.True(true);
        }

        [Fact]
        public void GetLastValueTest5()
        {
            long lastValue = SocialAPI.Updater.VK.Program.getLastValue();
            Assert.NotNull(lastValue);
        }

    }
}
