using HtmlAgilityPack;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using SocialAPI.Controllers;
using SocialAPI.DataOperators;
using SocialAPI.Mappers.Neo4j;
using SocialAPI.Mappers.Neo4j.Facebook;
using SocialAPI.Models;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.Facebook;
using SocialAPI.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Tests
{
    public class FacebookSeleniumTest
    {
        [SetUp]
        public void Setup()
        {
        }

        private static void parsePage(HtmlDocument document, UserFacebook result)
        {
            var friends = new List<UserFacebook>();
            var friendBlocks = document.DocumentNode.Descendants("li").ToArray();

            for (int i = 0; i < friendBlocks.Count(); i++)
            {
                string name = String.Empty, page = String.Empty, image = String.Empty;
                var chNodes = friendBlocks.ElementAt(i).Descendants().ToArray();

                for (int ii = 0; ii < chNodes.Count(); ii++)
                {
                    HtmlNode htmlNode = chNodes.ElementAt(ii);
                    if (htmlNode.Attributes["class"] != null)

                        if (htmlNode.Attributes["class"].Value == "fsl fwb fcb")
                        {
                            name = htmlNode.InnerText;
                            page = htmlNode.Descendants("a").ElementAt(0).Attributes["href"].Value;


                            if (page.IndexOf("?") > 0)
                            {
                                if (page.IndexOf("?id=") > 0)
                                {
                                    page = page.Substring(0, page.IndexOf("&"));
                                }
                                else
                                {
                                    page = page.Substring(0, page.IndexOf("?"));
                                }
                            }
                            result.Page = page;
                        }

                    if (htmlNode.Attributes["class"] != null)
                        if (htmlNode.Attributes["class"].Value.EndsWith("_rv img") || htmlNode.Attributes["class"].Value.EndsWith("_rw img"))
                        {
                            image = htmlNode.Attributes["src"].DeEntitizeValue;
                        }
                }

                if (!String.IsNullOrEmpty(page))
                {
                    friends.Add(new UserFacebook { Page = page, Name = name, ImageURL = image });
                }


            }

            result.Friends = friends.ToArray<UserFacebook>();
        }

        [Test]
        public void TestParsePage_Test1()
        {
            try
            {
                DateTime begin = DateTime.Now;
                var document = new HtmlDocument();
                document.Load(@"TestData\\HTMLPage1.html");
                UserFacebook result = new UserFacebook();
                parsePage(document, result);
                TimeSpan delta = DateTime.Now - begin;
                string time = delta.TotalMilliseconds.ToString(); //225.0129   233.01330000000002
            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }


        [Test]
        public void GetFacebook_Test2()
        {
            UsersController contr = new UsersController();
            var user_url = "https://www.facebook.com/erchic";
            GenericResponse<AbstractUser> users = contr.GetFacebook(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), user_url);

            Assert.IsTrue(users != null, "������ ������� �� ������� ���������");
        }

        [Test]
        public void PutFacebook_Test3()
        {
            MsSQLDataOperator.GetSeleniumFacebook();
            UsersController contr = new UsersController();
            var user_url = "https://www.facebook.com/erchic";
            GenericResponse<PutUserResponse> users = contr.PutFacebook(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), user_url);

            Assert.IsTrue(users != null, "������ ������� �� ������� ���������");
        }



    }
}