﻿using Newtonsoft.Json;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SocialAPI.Controllers;
using SocialAPI.DataOperators;
using SocialAPI.Models;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks;
using SocialAPI.Models.SocialNetworks.Instagram;
using SocialAPI.Models.MsSQL.BotometrModel;
using SocialAPI.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using SocialAPIML.Model;

namespace Tests
{
    public class InstagramSeleniumTest
    {
        [SetUp]
        public void Setup()
        {
        }


        [Test]
        public void Login_Test1()
        {
            try
            {
                List<AccountManagerInstagram> fbAcs;
                ChromeDriver driver;
                getDriverSelenium(out fbAcs, out driver);
                InstagramSeleniumManager.Login(fbAcs.First(), driver);
            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }

        private static void getDriverSelenium(out List<AccountManagerInstagram> fbAcs, out ChromeDriver driver)
        {
            fbAcs = MsSQLDataOperator.AccountsInstagramGet();
            ChromeOptions options = new ChromeOptions();
            options.AddArguments("--disable-notifications");
            options.AddArguments("--no-sandbox");
            options.AddUserProfilePreference("profile.default_content_setting_values.images", 2);
            driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), options);
        }

        [Test]
        public void getCurrentInstagramUser_Test2()
        {
            try
            {
                List<AccountManagerInstagram> fbAcs;
                ChromeDriver driver;
                getDriverSelenium(out fbAcs, out driver);
                UserInstagram userins = InstagramSeleniumManager.getCurrentInstagramUser(fbAcs.First(), driver);
                Assert.NotNull(userins);
            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }

        [Test]
        public void getUser_Test3()
        {
            try
            {
                List<AccountManagerInstagram> fbAcs;
                ChromeDriver driver;
                List<UserInstagram> followers;
                List<UserInstagram> followings;
                UserInstagram user;

                getDriverSelenium(out fbAcs, out driver);

                ChromeOptions options = new ChromeOptions();
                options.AddArguments("--disable-notifications");
                options.AddUserProfilePreference("profile.default_content_setting_values.images", 2);
                driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), options);

                UserInstagram userins = InstagramSeleniumManager.getCurrentInstagramUser(fbAcs.First(), driver);


                // driver.Navigate().GoToUrl("https://www.instagram.com/");


                if (userins != null)
                {
                    var userName = "razvivashki_s_malyshom";
                    user = InstagramSeleniumManager.GetUser(userName, driver, 1000);
                    //followers = InstagramSeleniumManager.GetFollowers(user.id, driver, user.edge_followed_by.count);
                    //followings = InstagramSeleniumManager.GetFollowings(user.id, driver, user.edge_follow.count);
                }

            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }

        [Test]
        public void PutInstagram_Test4()
        {
            MsSQLDataOperator.GetSeleniumInstagram();
            UsersController contr = new UsersController();
            var username = "anastasiiasmirno";
            GenericResponse<PutUserResponse> users = contr.PutInstagram(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), username);

            Assert.IsTrue(users != null, "Должен вернуть не нулевой результат");
        }

        [Test]
        public void GetInstagram_Test5()
        {
            UsersController contr = new UsersController();
            var username = "anastasiiasmirno";
            GenericResponse<AbstractUser> users = contr.GetInstagram(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), username);

            Assert.IsTrue(users != null, "Должен вернуть не нулевой результат");
        }

        [Test]
        public void UpdateInstagram_Test6()
        {
            SocialAPI.Updater.Instagram.Program.Init(Guid.Parse("07DD29FF-1BF8-48DA-0272-08D729F8DF1B"), 1000, new Uri(@"http://localhost:52147/"));

            SocialAPI.Updater.Instagram.Program.Run();

        }

        [Test]
        public void SaveCook_Test7()
        {
            try
            {
                List<AccountManagerInstagram> fbAcs;
                ChromeDriver driver;
                getDriverSelenium(out fbAcs, out driver);
                InstagramSeleniumManager.Login(fbAcs.First(), driver);

                var cookie = driver.Manage().Cookies;
                string file = @"C:\test\Cookies.data";
                CookieManager.WriteToFile(driver, file);
            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }

        [Test]
        public void ReadCookFromFile_Test8()
        {
            try
            {
                List<AccountManagerInstagram> fbAcs;
                ChromeDriver driver;
                getDriverSelenium(out fbAcs, out driver);
                driver.Navigate().GoToUrl("https://www.instagram.com/");
                //var cookie = driver.Manage().Cookies;
                string file = @"C:\test\Cookies.data";
                CookieManager.ReadFromFile(driver, file);

                driver.Navigate().Refresh();
            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }

        [Test]
        public void SaveAndReadToStringCook_Test9()
        {
            try
            {
                List<AccountManagerInstagram> fbAcs;
                ChromeDriver driver;
                getDriverSelenium(out fbAcs, out driver);
                InstagramSeleniumManager.Login(fbAcs.First(), driver);

                var cookie = driver.Manage().Cookies;
                string file = @"C:\test\Cookies.data";
                var cookStr = CookieManager.WriteCookieAsString(driver);
                driver.Manage().Cookies.DeleteAllCookies();

                driver.Navigate().Refresh();
                driver.Navigate().GoToUrl("https://www.instagram.com/");

                CookieManager.ReadCookiefromString(driver, cookStr);
                driver.Navigate().Refresh();
            }
            catch (Exception ex)
            {
                string exce = ex.ToString();
            }
        }

        [Test]
        public void ReadUserFromFile()
        {
            //var userText = File.ReadAllText(@"TestData\\userInstGaga.txt");
            //var userText = File.ReadAllText(@"TestData\\userInstBorntest.txt");
            var userText = File.ReadAllText(@"TestData\\userInst.txt");
            Assert.IsTrue(userText.Length > 0, "Количество символов в тексте должно быть больше 0");


            var user = JsonConvert.DeserializeObject<BotRootObject>(userText).graphql.user;

            ModelInput mappedData = null;
            //InstagramSeleniumManager.Mapping(user, ref mappedData);

            Assert.IsNotNull(mappedData);
        }



        /// <summary>
        /// Класс содержащий методы для чтения и записи Cookie
        /// </summary>
        public class CookieManager
        {

            public static void WriteToFile(ChromeDriver driver, string path)
            {

                // create file named Cookies to store Login Information		
                using (StreamWriter file = new StreamWriter(path))
                {
                    try
                    {
                        foreach (Cookie ck in driver.Manage().Cookies.AllCookies)
                        {
                            file.WriteLine((ck.Name + ";" + ck.Value));
                        }
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
            }

            public static void ReadFromFile(ChromeDriver driver, string patth)
            {
                try
                {
                    string line;
                    System.IO.StreamReader file = new System.IO.StreamReader(patth);
                    while ((line = file.ReadLine()) != null)
                    {
                        string[] words = line.Split(';');
                        {
                            String name = words[0];
                            String value = words[1];
                            String domain = words[2];

                            String path = words[3];
                            DateTime? expiry = String.IsNullOrEmpty(words[4]) ? null : (DateTime?)DateTime.Parse(words[4]);

                            Cookie ck = new Cookie(name, value);

                            driver.Manage().Cookies.AddCookie(ck); // This will add the stored cookie to your current session					
                        }
                    }

                    file.Close();

                }
                catch (Exception exx)
                {

                }
            }

            /// <summary>
            /// Записывает наименование куки и значение в строку (каждый куки соответствует своя строка)
            /// </summary>
            /// <param name="driver"></param>
            /// <param name="path"></param>
            /// <returns></returns>
            public static string WriteCookieAsString(ChromeDriver driver)
            {
                StringBuilder builder = new StringBuilder();
                try
                {
                    foreach (Cookie ck in driver.Manage().Cookies.AllCookies)
                    {
                        builder.AppendLine(ck.Name + ";" + ck.Value);
                    }
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
                return builder.ToString();
            }

            /// <summary>
            /// Формирует куки из строки и добавляет их в ChromeDriver
            /// </summary>
            /// <param name="driver"></param>
            /// <param name="cookStr"></param>
            public static void ReadCookiefromString(ChromeDriver driver, string cookStr)
            {
                try
                {
                    string[] array = cookStr.Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

                    foreach (String line in array)
                    {
                        string[] words = line.Split(';');
                        {
                            String name = words[0];
                            String value = words[1];

                            Cookie ck = new Cookie(name, value);
                            driver.Manage().Cookies.AddCookie(ck); // This will add the stored cookie to your current session					
                        }

                    }
                }
                catch (Exception exx)
                {
                    string exception = exx.ToString();
                }
            }


        }

    }
}