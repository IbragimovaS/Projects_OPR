﻿using Newtonsoft.Json;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.MsSQL.BotometrModel;
using SocialAPI.Models.SocialNetworks.OK;
using SocialAPIML.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Класс подключения к веб-сервису Instagram
    /// </summary>
    public class InstagramConnection : AbstractConnection
    {


        /// <summary>
        /// Октрыть подключение
        /// </summary>          
        public override bool Open()
        {
            return true;
        }

        /// <summary>
        /// Получить текущего (авторизовавшегося) пользователя
        /// </summary>
        /// <returns></returns>
        public static SocialAPI.Models.MsSQL.BotometrModel.User GetInstagramUser(string user_name, ref Proxy proxy)
        {
            SocialAPI.Models.MsSQL.BotometrModel.User res = null;
            try
            {
                string StringGET = string.Format("https://www.instagram.com/{0}/?__a=1", user_name);
                string response = GetDataByProxy(StringGET, ref proxy);
                res = JsonConvert.DeserializeObject<BotRootObject>(response).graphql.user;
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка InstagramConnection.GetInstagramUser. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }

        /// <summary>
        /// Получить модель для обучающей выборки
        /// </summary>
        /// <param name="profileID"></param>
        /// <param name="is_bot"></param>
        /// <returns></returns>
        public static ModelInput GetModelInputForTraining(SocialAPI.Models.MsSQL.BotometrModel.User profile, bool is_bot)
        {
            ModelInput result = GetModelInput(profile);
            result.Is_bot = is_bot;
            return result;
        }

        /// <summary>
        /// Преобразовать экземпляр класса  SocialAPI.Models.MsSQL.BotometrModel.User в ModelInput
        /// </summary>
        /// <param name="profile"></param>
        /// <returns></returns>
        public static ModelInput GetModelInput(SocialAPI.Models.MsSQL.BotometrModel.User profile)
        {
            ModelInput result = new ModelInput();
            result.Rid = Guid.NewGuid().ToString();
            result.Date_load = DateTime.Now.ToString();
            result.Username = profile.username;
            result.User_id = profile.id;
            result.Biography_Length = profile.biography == null ? 0 : profile.biography.Length;
            result.Country_block_Sign = profile.country_block;
            result.External_url_Sign = String.IsNullOrEmpty(profile.external_url) == true ? false : true;
            result.External_url_linkshimmed_Sign = String.IsNullOrEmpty(profile.external_url_linkshimmed) == true ? false : true;
            result.Has_channel_Sign = profile.has_channel;
            result.Edge_followed_by_Count = profile.edge_followed_by == null ? 0 : profile.edge_followed_by.count;
            result.Edge_follow_Count = profile.edge_follow == null ? 0 : profile.edge_follow.count;
            result.Full_name_Sign = String.IsNullOrEmpty(profile.full_name) == true ? false : true;
            result.Highlight_reel_Count = profile.highlight_reel_count;

            if (profile.business_category_name != null)
                result.Business_category_name_Sign = String.IsNullOrEmpty(profile.business_category_name.ToString()) == true ? false : true;
            else
                result.Business_category_name_Sign = false;

            result.Is_joined_recently_Sign = profile.is_joined_recently;
            result.Is_private_Sign = profile.is_private;
            result.Is_verified_Sign = profile.is_verified;
            result.Profile_pic_url_Sign = String.IsNullOrEmpty(profile.profile_pic_url) == true ? false : true;
            result.Profile_pic_url_hd_Sign = String.IsNullOrEmpty(profile.profile_pic_url_hd) == true ? false : true;

            if (profile.connected_fb_page != null)
                result.Connected_fb_page_Sign = String.IsNullOrEmpty(profile.connected_fb_page.ToString()) == true ? false : true;
            else result.Connected_fb_page_Sign = false;

            //публикации IGTV
            result.Edge_felix_video_timeline_Count = profile.edge_felix_video_timeline == null ? 0 : profile.edge_felix_video_timeline.count;

            result.Edge_felix_video_timeline_Comment_Count = profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.edge_media_to_comment != null).Sum(item => item.node.edge_media_to_comment.count);
            result.Edge_felix_video_timeline_Like_Count = profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.edge_liked_by != null).Sum(item => item.node.edge_liked_by.count);

            int fvCount = profile.edge_felix_video_timeline.edges.Count();
            result.Edge_felix_comments_disabled_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.comments_disabled == true).Count() / fvCount;
            result.Edge_felix_location_null_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.location == null).Count() / fvCount;
            result.Edge_felix_gating_info_null_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.gating_info == null).Count() / fvCount;
            result.Edge_felix_fact_check_overall_rating_null_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.fact_check_overall_rating == null).Count() / fvCount;
            result.Edge_felix_fact_check_information_null_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.fact_check_information == null).Count() / fvCount;
            result.Edge_felix_is_video_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.is_video == true).Count() / fvCount;
            result.Edge_felix_is_published_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => item.node.is_published == true).Count() / fvCount;
            result.Edge_felix_title_notEmpty_Percent = fvCount == 0 ? 0 : 100 * profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Where(item => String.IsNullOrEmpty(item.node.title) == false).Count() / fvCount;
            result.Edge_felix_video_view_Count = profile.edge_felix_video_timeline.edges.Where(item => item.node != null).Sum(item => item.node.video_view_count);


            //публикации простые
            int ownCount = profile.edge_owner_to_timeline_media.edges.Count();
            result.Edge_owner_to_timeline_media_Count = profile.edge_owner_to_timeline_media == null ? 0 : profile.edge_owner_to_timeline_media.count;
            result.Edge_owner_media_to_comment_Count = profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.edge_media_to_comment != null).Sum(item => item.node.edge_media_to_comment.count);
            result.Edge_owner_comments_disabled_Percent = ownCount == 0 ? 0 : 100 * profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.comments_disabled == true).Count() / ownCount;
            result.Edge_owner_edge_liked_by_Count = profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.edge_liked_by != null).Sum(item => item.node.edge_liked_by.count);

            result.Edge_owner_location_null_Percent = ownCount == 0 ? 0 : 100 * profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.location == null).Count() / ownCount;
            result.Edge_owner_gating_info_null_Percent = ownCount == 0 ? 0 : 100 * profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.gating_info == null).Count() / ownCount;
            result.Edge_owner_fact_check_overall_rating_null_Percent = ownCount == 0 ? 0 : 100 * profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.fact_check_overall_rating == null).Count() / ownCount;
            result.Edge_owner_fact_check_information_null_Percent = ownCount == 0 ? 0 : 100 * profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.fact_check_information == null).Count() / ownCount;
            result.Edge_owner_is_video_Percent = ownCount == 0 ? 0 : 100 * profile.edge_owner_to_timeline_media.edges.Where(item => item.node != null).Where(item => item.node.is_video == true).Count() / ownCount;

            result.Edge_saved_media_Count = profile.edge_saved_media == null ? 0 : profile.edge_saved_media.count;
            result.Edge_media_collections_Count = profile.edge_media_collections == null ? 0 : profile.edge_media_collections.count;
            return result;
        }
    }
}
