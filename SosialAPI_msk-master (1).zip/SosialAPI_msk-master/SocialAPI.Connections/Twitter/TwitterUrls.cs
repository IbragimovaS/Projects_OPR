﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Данный класс содержит методы для получения ссылок для работы с твиттером
    /// </summary>
    public class TwitterUrls
    {
        /// <summary>
        /// Ссылка для авторизации
        /// </summary>
        const string oauthUrl = @"https://api.twitter.com/oauth2/token";

        /// <summary>
        /// Ссылка для подписчиков
        /// </summary>
        const string followersUrl = @"https://api.twitter.com/1.1/followers/list.json";

        /// <summary>
        /// Ссылка для подписчиков ID
        /// </summary>
        const string followersIDsUrl = @"https://api.twitter.com/1.1/followers/ids.json";

        /// <summary>
        /// Ссылка для друзей
        /// </summary>
        const string friendsUrl = @"https://api.twitter.com/1.1/friends/list.json";

        /// <summary>
        /// Ссылка для профиля
        /// </summary>
        const string lookupUrl = @"https://api.twitter.com/1.1/users/lookup.json";

        /// <summary>
        /// Возвращает настройки (включая информацию о текущем тренде, гео и времени сна) для аутентифицирующего пользователя.
        /// </summary>
        const string accountUrl = @"https://api.twitter.com/1.1/account/settings.json";

        /// <summary>
        /// Ссылка для авторизации
        /// </summary>
        public static string OauthUrl
        {
            get
            {
                return oauthUrl;
            }
        }

        /// <summary>
        /// Получить ссылку для получения профиля пользователя
        /// </summary>
        /// <param name="screen_name"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public static string GetUserUrl(string screen_name)
        {
            return String.Format("{0}?screen_name={1}", lookupUrl, screen_name);
        }

       
        public static string GetAcountUrl()
        {
            return accountUrl;
        }

        /// <summary>
        /// Получит ссылку для получения друзей пользователя (выводит по 200 шт.)
        /// </summary>
        /// <param name="screen_name">адресное имя</param>
        /// <param name="user_id">идентификатор пользователя</param>
        /// <param name="cursor">-1 если надо получать друзей сначала, FriendsList.next_cursor - если продолжить получение друзей</param>
        /// <param name="count">количество пользователей</param>
        /// <returns></returns>
        public static string GetFriendsListUrl(string screen_name, long? user_id, string cursor, int count)
        {
            string result = String.Empty;
            //cursor = cursor ?? -1;
            if (!string.IsNullOrEmpty(screen_name))
                result = String.Format("{0}?cursor={1}&screen_name={2}&skip_status=false&include_user_entities=false&count={3}",
                                        friendsUrl, cursor, screen_name, count);
            else if (user_id != null)
                result = String.Format("{0}?cursor={1}&user_id={2}&skip_status=false&include_user_entities=false&count={3}",
                                        friendsUrl, cursor, user_id, count);
            return result;
        }

        /// <summary>
        /// Получить ссылку для получения подписчиков пользователя (выводит по 200 шт.)
        /// </summary>
        /// <param name="screen_name">адресное имя</param>
        /// <param name="user_id">идентификатор пользователя</param>
        /// <param name="cursor">-1 если надо получать друзей сначала, FriendsList.next_cursor - если продолжить получение друзей</param>
        /// <param name="count">количество пользователей</param>
        /// <returns></returns>
        public static string GetFollowersListUrl(string screen_name, long? user_id, string cursor, int count)
        {
            string result = String.Empty;
            if (!string.IsNullOrEmpty(screen_name))
                result = String.Format("{0}?cursor={1}&screen_name={2}&skip_status=false&include_user_entities=false&count={3}",
                                        followersUrl, cursor, screen_name, count);
            else if (user_id != null)
                result = String.Format("{0}?cursor={1}&user_id={2}&skip_status=false&include_user_entities=false&count={3}",
                                        followersUrl, cursor, user_id, count);
            return result;
        }

        /// <summary>
        /// Получить ссылку для получения списка идентификаторов подписчиков пользователя (выводит по 5000 шт.)
        /// </summary>
        /// <param name="screen_name">адресное имя</param>
        /// <param name="user_id">идентификатор пользователя</param>
        /// <param name="cursor">-1 если надо получать друзей сначала, FriendsList.next_cursor - если продолжить получение друзей</param>
        /// <param name="count">количество пользователей</param>
        /// <returns></returns>
        public static string GetFollowersIDsUrl(string screen_name, long? user_id, string cursor, int count)
        {
            string result = String.Empty;
            if (!string.IsNullOrEmpty(screen_name))
                result = String.Format("{0}?cursor={1}&screen_name={2}&stringify_ids=true&count={3}",
                                        followersIDsUrl, cursor, screen_name, count);
            else if (user_id != null)
                result = String.Format("{0}?cursor={1}&user_id={2}&stringify_ids=true&count={3}",
                                        followersIDsUrl, cursor, user_id, count);
            return result;
        }
    }
}
