﻿using Newtonsoft.Json;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks.Twitter;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Класс подключения к веб-сервису Twitter
    /// </summary>
    public class TwitterConnection : AbstractConnection
    {


        /// <summary>
        /// Октрыть подключение
        /// </summary>          
        public override bool Open()
        {
            return true;
        }

        /// <summary>
        /// Получить текущего (авторизовавшегося) пользователя
        /// </summary>
        /// <returns></returns>
        public static UserTwitter getCurrentTwitterUser(ref AccountManagerTwitter currentAccount)
        {
            UserTwitter res = null;
            try
            {

                OAuthUtility oAuthUtility = new OAuthUtility();
                string response = oAuthUtility.GetResponse(TwitterUrls.GetAcountUrl(), ref currentAccount);

                res = JsonConvert.DeserializeObject<UserTwitter>(response);
            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка TwitterConnection.getCurrentTwitterUser. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }

        /// <summary>
        /// Получить пользователей
        /// </summary>
        /// <param name="sc_nm">screen name один или набор, перечисленный через запятую без пробелов 100 максимум</param>
        /// <param name="currentAccount"></param>
        /// <returns></returns>
        public static List<UserTwitter> getTwitterUsers(string sc_nms, ref AccountManagerTwitter currentAccount)
        {
            List<UserTwitter> res = null;
            try
            {
                OAuthUtility oAuthUtility = new OAuthUtility();
                string response = oAuthUtility.GetResponse(TwitterUrls.GetUserUrl(sc_nms), ref currentAccount);
                res = JsonConvert.DeserializeObject<List<UserTwitter>>(response);
            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка TwitterConnection.getTwitterUsers. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }


        /// <summary>
        /// Возвращает список  друзей заданного объекта UserTwitter
        /// </summary>
        /// <param name="user"></param>
        /// <param name="currentAccount"></param>
        /// <returns></returns>
        public static List<UserTwitter> getTwitterFriends(UserTwitter user, ref AccountManagerTwitter currentAccount)
        {
            List<UserTwitter> res = new List<UserTwitter>();
            try
            {
                OAuthUtility oAuthUtility = new OAuthUtility();
                string response = String.Empty;
                string cursor = "-1";
                int step = 200;
                int countIteration = user.friends_count / step;
                if (countIteration == 0)
                    countIteration = 1;
                for (int i = 0; i <= countIteration; i++)
                {
                    response = oAuthUtility.GetResponse(TwitterUrls.GetFriendsListUrl(user.screen_name, null, cursor, step), ref currentAccount);
                    twResponse resObj = JsonConvert.DeserializeObject<twResponse>(response);
                    res.AddRange(resObj.users);
                    cursor = resObj.next_cursor_str;
                }

            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка TwitterConnection.getFriends. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }

        /// <summary>
        /// Возвращает список подписчиков заданного объекта UserTwitter
        /// </summary>
        /// <param name="user"></param>
        /// <param name="currentAccount"></param>
        /// <param name="count">Ограничение на количество загружаемых подписчиков</param>
        /// <returns></returns>
        public static List<UserTwitter> getTwitterFollowers(UserTwitter user, ref AccountManagerTwitter currentAccount, int count = 10000)
        {
            List<UserTwitter> res = new List<UserTwitter>();
            try
            {
                OAuthUtility oAuthUtility = new OAuthUtility();
                string response = String.Empty;
                string cursor = "-1";
                int step = 200;
                int countIteration = user.followers_count / step;
                int maxIteration = count/ step;
                if (countIteration == 0)
                    countIteration = 1;
                if (countIteration > maxIteration)
                    countIteration = maxIteration;
                for (int i = 0; i <= countIteration; i++)
                {
                    response = oAuthUtility.GetResponse(TwitterUrls.GetFollowersListUrl(user.screen_name, null, cursor, step), ref currentAccount);
                    twResponse resObj = JsonConvert.DeserializeObject<twResponse>(response);
                    res.AddRange(resObj.users);
                    cursor = resObj.next_cursor_str;
                }

            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка TwitterConnection.getTwitterFollowers. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }

        /// <summary>
        /// Возвращает список идентификаторов подписчиков заданного объекта UserTwitter
        /// </summary>
        /// <param name="user"></param>
        /// <param name="currentAccount"></param>
        /// <returns></returns>
        public static List<long> getTwitterFollowersIDs(UserTwitter user, ref AccountManagerTwitter currentAccount)
        {
            List<long> res = new List<long>();
            try
            {
                OAuthUtility oAuthUtility = new OAuthUtility();
                string response = String.Empty;
                string cursor = "-1";
                int step = 5000;
                int countIteration = user.followers_count / step;
                if (countIteration == 0)
                    countIteration = 1;
                for (int i = 0; i <= countIteration; i++)
                {
                    response = oAuthUtility.GetResponse(TwitterUrls.GetFollowersIDsUrl(user.screen_name, null, cursor, step), ref currentAccount);
                    twResponseIds resObj = JsonConvert.DeserializeObject<twResponseIds>(response);
                    res.AddRange(resObj.ids);
                    cursor = resObj.next_cursor_str;
                }

            }
            catch (Exception ex)
            {

                Trace.TraceError(DateTime.Now + String.Format("Ошибка TwitterConnection.getTwitterFollowersIDs. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }


        /// <summary>
        /// Проверяет ответ сервера на наличие ошибки
        /// </summary>
        /// <param name="response"></param>
        private static bool checkError(string response)
        {
            ErrorRootObject error = null;
            try
            {
                error = JsonConvert.DeserializeObject<ErrorRootObject>(response);
                if (error != null && error.error_code > 0)
                {
                    Trace.TraceError(DateTime.Now + String.Format("Ошибка OKConnection.GetCurrentUser. Текст ошибки {0}",
                        String.Format("Код ошибки API: {0}", HelperErrorCodeOK.GetError(error.error_code))));
                    return true;
                }
            }
            catch { }

            return false;
        }

        /// <summary>
        /// Рассчет MD5
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private static string getMD5Hash(string input)
        {
            var x = new System.Security.Cryptography.MD5CryptoServiceProvider();
            var bs = Encoding.UTF8.GetBytes(input);
            bs = x.ComputeHash(bs);
            var s = new StringBuilder();
            foreach (var b in bs)
            {
                s.Append(b.ToString("x2").ToLower());
            }
            return s.ToString();
        }

        /// <summary>
        /// Класс для десериализации ответа по пользователю В Twitter
        /// </summary>
        public class RootObjectUserTwitter
        {
            public UserTwitter response { get; set; }
        }

        /// <summary>
        /// Класс для сериализации ответа - Ошибка
        /// </summary>
        public class ErrorRootObject
        {
            public int error_code { get; set; }
            public string error_msg { get; set; }
            public object error_data { get; set; }
        }
    }
}
