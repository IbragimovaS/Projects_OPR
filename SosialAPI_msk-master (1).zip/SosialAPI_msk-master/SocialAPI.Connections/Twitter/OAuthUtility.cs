﻿using SocialAPI.Models.MsSQL.AccountManager;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace SocialAPI.Connections
{
    public class OAuthUtility
    {




        public OAuthUtility()
        {
        }

        AccountManagerTwitter twAccount;

        /// <summary>
        /// Получает ответ от сервера twitter
        /// </summary>
        /// <param name="uriString">запрос</param>
        public string GetResponse(string uriString, ref AccountManagerTwitter currentAccount)
        {

            WebRequestBuilder builder = new WebRequestBuilder(
                 new Uri(uriString),
                 HTTPVerb.GET,
                 new OAuthTokens { ConsumerKey = currentAccount.consumerKey, ConsumerSecret = currentAccount.consumerSecret, AccessToken = currentAccount.access_token, AccessTokenSecret = currentAccount.access_tokenSecret }, "");


            string responseBody = String.Empty;

            try
            {

                HttpWebResponse webResponse = builder.ExecuteRequest();
                responseBody = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();

            }
            catch (WebException wex)
            {
                if (wex.Message.Contains("429"))
                {
                    currentAccount.RaiseTimeIsComeEvent(out twAccount);
                    currentAccount = twAccount;
                }

                string errmes = wex.ToString();
                //throw new TwitterizerException(wex.Message, wex);
                //todo: error generate json
            }

            return responseBody;
        }


        /// <summary>
        /// Adds the OAuth Echo header to the supplied web request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="tokens">The tokens.</param>
        public static void AddOAuthEchoHeader(WebRequest request, OAuthTokens tokens)
        {
            WebRequestBuilder builder = new WebRequestBuilder(
                new Uri("https://api.twitter.com/1.1/account/verify_credentials.json"),
                HTTPVerb.POST,
                tokens, "");

            builder.PrepareRequest();

            request.Headers.Add("X-Verify-Credentials-Authorization", builder.GenerateAuthorizationHeader());
            request.Headers.Add("X-Auth-Service-Provider", "https://api.twitter.com/1.1/account/verify_credentials.json");
        }
    }
}
