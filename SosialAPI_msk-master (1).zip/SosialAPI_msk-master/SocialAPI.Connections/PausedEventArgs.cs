﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Класс аргументов события "Подключение в режиме ожидания"
    /// </summary>
    public class PausedEventArgs : EventArgs
    {

        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="time">Примерное время ожидания</param>
        public PausedEventArgs(TimeSpan time)
        {
            _ElapsedTime = time;
        }

        private TimeSpan _ElapsedTime;
        /// <summary>
        /// Примерное время ожидания
        /// </summary>
        public TimeSpan ElapsedTime
        {
            get
            {
                return _ElapsedTime;
            }
        }
    }
}
