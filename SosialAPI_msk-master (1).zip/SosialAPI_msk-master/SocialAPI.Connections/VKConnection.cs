﻿using Newtonsoft.Json;
using SocialAPI.Models.SocialNetworks.VK;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Класс подключения к веб-сервису ВКонтакте
    /// </summary>
    public class VKConnection : AbstractConnection
    {
        /// <summary>
        /// Используемая версия API
        /// </summary>
        const string VK_API_VERSION = "5.101";

        /// <summary>
        /// Октрыть подключение
        /// </summary>          
        public override bool Open()
        {
            return true;
        }

        /// <summary>
        /// Получить ответ сервера по текущему пользователю
        /// </summary>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static UserVK getCurrentVKUser(string access_token)
        {
            UserVK res = null;
            try
            {
                string request = String.Format("https://api.vk.com/method/users.get.json?v={0}&access_token={1}", VK_API_VERSION, access_token);
                string resp = GetData(request);
                res = JsonConvert.DeserializeObject<RootObjectUserVK>(resp).response.First();
            }
            catch (Exception)
            {
                
            }
            
            return res;
        }

        /// <summary>
        /// Получить набор пользователей ВКонтакте по идентификаторам
        /// </summary>
        /// <param name="ids">перечень идентификаторов через запятую (не более 1000)</param>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static IEnumerable<UserVK> getVKUsers(string ids, string access_token)
        {
            IEnumerable<UserVK> res = null;
            try
            {
                string request = String.Format("https://api.vk.com/method/users.get.json?v={0}&access_token={1}&user_ids={2}&fields=domain,photo_max_orig,followers_count,sex,bdate,relation,city,country,contacts,deactivated,is_closed,maiden_name,nickname,career,military,universities,schools,last_seen,verified",
                    VK_API_VERSION, access_token, ids);
                string resp = SendPostRequest(request);
                res = JsonConvert.DeserializeObject<RootObjectUserVK>(resp).response;
            }
            catch (Exception)
            {

            }

            return res;
        }

        /// <summary>
        /// Получить набор пользователей ВКонтакте по идентификаторам
        /// </summary>
        /// <param name="id">идентификаторы (не более 1000)</param>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static IEnumerable<UserVK> getVKUsers(int[] id, string access_token)
        {
            if (id.Length > 1000)
                throw new Exception("array is too long");
            string ids = id[0].ToString();
            for (int i = 1; i < id.Length - 1; i++)
            {
                ids = $"{ids},{i}";
            }
            return getVKUsers(ids, access_token);
        }

        /// <summary>
        /// Получить друзей ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <param name="access_token"></param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public static List<UserVK> getVKFriends(string id, string access_token, int offset = 0)
        {
            List<UserVK> res = null;
            try
            {
                string request = String.Format("https://api.vk.com/method/friends.get.json?v={0}&access_token={1}&user_id={2}&offset={3}&fields=domain,photo_max_orig,followers_count,sex,bdate,relation,city,country,contacts,deactivated,is_closed,maiden_name,nickname,career,military,universities,schools,last_seen,verified",
                    VK_API_VERSION, access_token, id, offset);
                string resp = GetData(request);
                res = JsonConvert.DeserializeObject<RootObjectFriendsVK>(resp).response.items.ToList();
                if (res.Count() == 5000)
                    res.AddRange(getVKFriends(id, access_token, offset + 5000));
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка VKConnection.getVKFriends. Текст ошибки {0}", ex.ToString()));
            }

            return res;
        }

        /// <summary>
        /// Получить подписчиков ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <param name="access_token"></param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public static List<UserVK> getVKFollowers(string id, string access_token, int offset = 0, int count = 10000)
        {
            List<UserVK> res = null;
            try
            {
                string request = String.Format("https://api.vk.com/method/users.getFollowers.json?v={0}&access_token={1}&user_id={2}&offset={3}&fields=domain,photo_max_orig,followers_count,sex,bdate,relation,city,country,contacts,deactivated,is_closed,maiden_name,nickname,career,military,universities,schools,last_seen,verified&count=1000",
                    VK_API_VERSION, access_token, id, offset);
                string resp = GetData(request);
                res = JsonConvert.DeserializeObject<RootObjectFriendsVK>(resp).response.items.ToList();
                count = count - 1000;
                if (res.Count() == 1000 && count > 0)
                {
                    res.AddRange(getVKFollowers(id, access_token, offset + 1000, count));
                }
            }
            catch (Exception)
            {

            }

            return res;
        }

        /// <summary>
        /// Получить подписки ВКонтакте
        /// </summary>
        /// <param name="id"></param>
        /// <param name="access_token"></param>
        /// <param name="offset"></param>
        /// <returns></returns>
        public static IEnumerable<UserVK> getVKSubscriptions(string id, string access_token, int offset = 0)
        {
            IEnumerable<UserVK> res = null;
            try
            {
                string request = String.Format("https://api.vk.com/method/users.getSubscriptions.json?v={0}&access_token={1}&user_id={2}&extended=0",
                    VK_API_VERSION, access_token, id);
                string resp = GetData(request);

                var userIds = JsonConvert.DeserializeObject<RootObjectVKSubscriptions>(resp).response.users.items.ToArray();

                res = getVKUsers(userIds, access_token);
            }
            catch (Exception)
            {

            }

            return res;
        }

        /// <summary>
        /// Получить идентификаторы подписчиков
        /// </summary>
        /// <param name="id"></param>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static List<int> getFollowersIDs(string id, string access_token, int offset = 0)
        {
            Stopwatch sw = Stopwatch.StartNew();
            
            string request = String.Format("https://api.vk.com/method/execute.json");

            Dictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("v", VK_API_VERSION);
            parameters.Add("access_token", access_token);
            parameters.Add("code", String.Format(Properties.Resources.getFollowersCode, id, offset));

            string resp = SendPostRequest(request, parameters).Result;
            var ids = JsonConvert.DeserializeObject<RootObjectIDs>(resp).response;

            if (ids != null && ids.Count() == 25000)
            {
                if (sw.ElapsedMilliseconds < 333)
                    Thread.Sleep(333 - (int)sw.ElapsedMilliseconds);
                ids.AddRange(getFollowersIDs(id, access_token, offset + 25000));
            }

            return ids;
        }

        /// <summary>
        /// Класс для десериализации идентификаторов подписчиков
        /// </summary>
        public class RootObjectIDs
        {
            public List<int> response { get; set; }
        }

        #region Для десериализации ответа по подпискам
        public class UsersVKSubscriptions
        {
            public int count { get; set; }
            public List<int> items { get; set; }
        }

        public class GroupsVKSubscriptions
        {
            public int count { get; set; }
            public List<int> items { get; set; }
        }

        public class ResponseVKSubscriptions
        {
            public UsersVKSubscriptions users { get; set; }
            public GroupsVKSubscriptions groups { get; set; }
        }

        public class RootObjectVKSubscriptions
        {
            public ResponseVKSubscriptions response { get; set; }
        }
        #endregion

        /// <summary>
        /// Класс для десериализации ответа по пользователю ВКонтакте
        /// </summary>
        public class RootObjectUserVK
        {
            public IEnumerable<UserVK> response { get; set; }
        }

        /// <summary>
        /// Класс для десериализации вложенного ответа по друзьям вконтакте
        /// </summary>
        public class ResponseFriendsVK
        {
            public int count { get; set; }
            public IEnumerable<UserVK> items { get; set; }
        }

        /// <summary>
        /// Класс для десериализации ответа по друзьям ВКонтакте
        /// </summary>
        public class RootObjectFriendsVK
        {
            public ResponseFriendsVK response { get; set; }
        }
    }
}
