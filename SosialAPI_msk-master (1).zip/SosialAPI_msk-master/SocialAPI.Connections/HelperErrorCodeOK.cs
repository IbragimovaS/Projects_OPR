﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialAPI.Connections
{
    public static class HelperErrorCodeOK
    {
        public static string GetError(int code)
        {
            string result = "";
            StringBuilder sb = new StringBuilder();
            sb.Append(@"UNKNOWN	1	Неизвестная ошибка
                SERVICE 2   Сервис временно недоступен
                METHOD  3   Метод не существует
                REQUEST 4   Не удалось обработать запрос, так как он неверный
                ACTION_BLOCKED  7   Запрошенное действие временно заблокировано для текущего пользователя
                FLOOD_BLOCKED   8   Выполнение метода заблокировано вследствие флуда
                IP_BLOCKED  9   Выполнение метода заблокировано по IP - адресу вследствие подозрительных действий текущего пользователя или вследствие прочих ограничений, распространяющихся на конкретный метод
                PERMISSION_DENIED   10  Отказ в разрешении.Возможная причина - пользователь не авторизовал приложение на выполнение операции
                LIMIT_REACHED   11  Достигнут предел вызовов метода
                CANCELLED   12  Операция прервана пользователем
                NOT_MULTIPART   21  Не multi - part запрос при добавлении фотографий
                NOT_ACTIVATED   22  Пользователь должен активировать свой аккаунт
                NOT_YET_INVOLVED    23  Пользователь не вовлечён в приложение
                NOT_OWNER   24  Пользователь не является владельцем объекта
                NOT_ACTIVE  25  Ошибка рассылки нотификаций.Пользователь неактивен в приложении
                TOTAL_LIMIT_REACHED 26  Ошибка рассылки нотификаций.Достигнут лимит нотификаций для приложения
                NETWORK 30  Слишком большое тело запроса или проблема в обработке заголовков
                NETWORK_TIMEOUT 31  Клиент слишком долго передавал тело запроса
                NOT_ADMIN   50  У пользователя нет административных прав для выполнения данного метода
                PARAM   100 Отсутствующий или неверный параметр
                PARAM_API_KEY   101 Параметр application_key не указан или указан неверно
                PARAM_SESSION_EXPIRED   102 Истек срок действия ключа сессии
                PARAM_SESSION_KEY   103 Неверный ключ сессии
                PARAM_SIGNATURE 104 Неверная подпись
                PARAM_RESIGNATURE   105 Неверная повторная подпись
                PARAM_ENTITY_ID 106 Неверный идентификатор дискуссии
                PARAM_USER_ID   110 Неверный идентификатор пользователя
                PARAM_ALBUM_ID  120 Неверный идентификатор альбома
                PARAM_PHOTO_ID  121 Неверный идентификатор фотографии
                PARAM_WIDGET    130 Неверный идентификатор виджета
                PARAM_MESSAGE_ID    140 Неверный идентификатор сообщения
                PARAM_COMMENT_ID    141 Неверный идентификатор комментария
                PARAM_HAPPENING_ID  150 Неверный идентификатор события
                PARAM_HAPPENING_PHOTO_ID    151 Неверный идентификатор фотографии события
                PARAM_GROUP_ID  160 Неверный идентификатор группы
                PARAM_PERMISSION    200 Приложение не может выполнить операцию.В большинстве случаев причиной является попытка получения доступа к операции без авторизации от пользователя.
                PARAM_APPLICATION_DISABLED  210 Приложение отключено
                PARAM_DECISION  211 Неверный идентификатор выбора
                PARAM_BADGE_ID  212 Неверный идентификатор значка
                PARAM_PRESENT_ID    213 Неверный идентификатор подарка
                PARAM_RELATION_TYPE 214 Неверный идентификатор типа связи
                PARAM_FIELDSET  220 Неверный формат поля fields
                NOT_FOUND   300 Информация о запросе не найдена
                EDIT_PHOTO_FILE 324 Ошибка обработки multi - part запроса
                AUTH_LOGIN  401 Сбой аутентификации.Неверное имя пользователя / пароль или маркер аутентификации или пользователь удален / заблокирован
                AUTH_LOGIN_CAPTCHA  402 Сбой аутентификации.Требуется ввести капчу для проверки пользователя
                AUTH_LOGIN_WEB_HUMAN_CHECK  403 Сбой аутентификации
                NOT_SESSION_METHOD  451 Указан ключ сессии, но метод должен быть вызван вне сессии
                SESSION_REQUIRED    453 Ключ сессии не указан для метода, требующего сессии
                CENSOR_MATCH    454 Текст отклонен цензором
                FRIEND_RESTRICTION  455 Невозможно выполнить операцию, так как друг установил на нее ограничение(поместил в «черный список» или сделал свой аккаунт приватным)
                GROUP_RESTRICTION   456 Невозможно выполнить операцию, так как группа установила на нее ограничение
                UNAUTHORIZED_RESTRICTION    457 Неавторизованный доступ
                PRIVACY_RESTRICTION 458 То же, что и FRIEND_RESTRICTION
                PHOTO_SIZE_LIMIT_EXCEEDED   500 Размер двоичного содержимого изображения в байтах превышает предел
                PHOTO_SIZE_TOO_SMALL    501 Слишком маленький размер изображения в пикселях
                PHOTO_SIZE_TOO_BIG  502 Слишком большой размер изображения в пикселях
                PHOTO_INVALID_FORMAT    503 Невозможно распознать формат изображения
                PHOTO_IMAGE_CORRUPTED   504 Формат изображения распознан, но содержимое повреждено
                PHOTO_NO_IMAGE  505 В запросе не найдено изображение
                PHOTO_PIN_TOO_MUCH  508 Слишком много отметок на фотографии
                IDS_BLOCKED 511 Ошибка проверки антиспама
                PHOTO_ALBUM_NOT_BELONGS_TO_USER 512 Попытка залить фотографию в чужой альбом
                PHOTO_ALBUM_NOT_BELONGS_TO_GROUP    513 Попытка залить фотографию в альбом, не принадлежащий указанной группе
                IDS_SESSION_VERIFICATION_REQUIRED   514 Пользователю необходимо пройти верификацию
                MEDIA_TOPIC_BLOCK_LIMIT 600 Слишком много параметров “медиа”
                MEDIA_TOPIC_TEXT_LIMIT  601 Достигнут лимит длины текста
                MEDIA_TOPIC_POLL_QUESTION_TEXT_LIMIT    602 Достигнут лимит длины текста вопроса к голосованию
                MEDIA_TOPIC_POLL_ANSWERS_LIMIT  603 Слишком много ответов к голосованию
                MEDIA_TOPIC_POLL_ANSWER_TEXT_LIMIT  604 Достигнут лимит длины текста ответа к голосованию
                MEDIA_TOPIC_WITH_FRIENDS_LIMIT  605 Достигнут лимит количества отмечаемых друзей
                MEDIA_TOPIC_WITH_FRIENDS_USER_LIMIT 606 Достигнут лимит количества отмечаемых друзей(юзер - специфик)
                MEDIA_TOPIC_LINK_BAD_FORMAT 607 Неверный формат ссылки в медиатопике
                GROUP_DUPLICATE_JOIN_REQUEST    610 Запрос на вступление в группу уже зарегистрирован
                COMMENT_NOT_FOUND   700 Комментарий не найден
                INVALID_AUTHOR  701 Попытка отредактировать комментарий, не принадлежащий пользователю
                COMMENT_NOT_ACTIVE  702 Попытка отредактировать удалённый комментарий
                TIMEOUT_EXCEEDED    704 Время редактирования истекло
                CHAT_NOT_FOUND  705 Чат не найден
                MESSAGE_NOT_ACTIVE  706 Попытка отредактировать удалённое сообщение
                STICKER_SERVICE_UNAVAILABLE_TO_USER 707 Пользователю недоступны стикеры
                STICKER_MESSAGE_INVALID 708 Неверный формат стикеров
                GIF_SERVICE_UNAVAILABLE_TO_USER 709 Пользователю недоступен сервис GIF - анимаций
                CHAT_MAX_PARTICIPANT_COUNT_LIMIT    800 Достигнуто максимальное количество участников чата
                CHAT_PARTICIPANTS_EMPTY_BLOCKED_USERS   801 Указанный участник заблокировал текущего пользователя
                CHAT_PARTICIPANTS_EMPTY_NON_EXISTENT_USERS  802 Передан несуществующий пользователь
                NO_SUCH_APP 900 Возвращается при попытке получить открытую информацию для несуществующего приложения
                CALLBACK_INVALID_PAYMENT    1001    Ошибка возвращена сервером приложений для уведомления о неверной информации транзакции
                INVALID_PAYMENT 1003    Неверная платежная транзакция
                DUPLICATE_PAYMENT   1004    Слишком частые запросы платежа
                NOT_ENOUGH_MONEY    1005    У пользователя недостаточно денег на аккаунте
                VCHAT_SERVICE_DISABLED  1101    Видео - чат отключен
                TARGET_USER_UNAVAILABLE 1102    Пользователь недоступен для видео - чата или видео - сообщения
                FRIENDSHIP_REQUIRED 1103    Указанный пользователь должен быть другом
                BATCH   1200    Ошибка вызова батчинга
                APP_NO_PLATFORM_ALLOWED 1300    Платформы для приложения не установлены
                APP_DEVICE_NOT_ALLOWED  1301    Указанное устройство не доступно
                APP_DEVICE_NOT_SPECIFIED    1302    Устройство не указано
                APP_EMPTY_SEARCH_PARAMS 1400    Ошибка поиска мест
                APP_SEARCH_SCENARIO_DOES_NOT_EXIST  1401    Ошибка поиска мест
                GRAPH_PARAM_REQUEST: Wrong request format   2001    Неверный тип POST - контента(Graph API).Необходимо добавить заголовок Content - Type: application / json; charset = utf - 8
                INVALID_RESPONSE    5000    Недопустимый ответ(например, указан несуществующий формат)
                SYSTEM  9999    Критическая системная ошибка.Оповестите об этом службу поддержки");
            int i = sb.ToString().IndexOf(" " + code.ToString() + " ");
            if (i > 0)
            {
                if (code != 9999)
                {
                    int li = sb.ToString().IndexOf("\n",i);
                    result = sb.ToString().Substring(i, li - i);
                }
                else
                    result = sb.ToString().Substring(i, sb.ToString().Length - i);
            }
            return result;
        }
    }
}
