﻿using SocialAPI.Models.MsSQL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Абстрактный класс подключения к внешнему источнику данных
    /// </summary>
    public abstract class AbstractConnection
    {
        /// <summary>
        /// Закрыть подключение
        /// </summary>
        public virtual void Close() { }

        /// <summary>
        /// Запрос к серверу не более maxCount раз
        /// </summary>
        /// <param name="requestString">строка запроса</param>
        /// <param name="count">текущее количество запросов</param>
        /// <param name="maxCount">максимальное количество запросов</param>
        /// <param name="cookiesURI">ссылка для получения cookies</param>
        /// <returns></returns>
        protected static string GetData(string requestString, int count = 0, int maxCount = 3, string cookiesURI = null)
        {
            count++;
            string responseFromServer = string.Empty;
            Trace.TraceInformation(DateTime.Now + String.Format("Попытка выполнения запроса: {0}", requestString));
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestString);
                request.Proxy = HttpWebRequest.GetSystemWebProxy();
                request.Proxy.Credentials = CredentialCache.DefaultNetworkCredentials;
                request.UseDefaultCredentials = true;

                if (!string.IsNullOrEmpty(cookiesURI))
                    setCookies(request, cookiesURI);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream dataStream = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream, Encoding.GetEncoding("UTF-8"));
                    responseFromServer = reader.ReadToEnd();
                    reader.Close();
                    dataStream.Close();
                    response.Close();
                }
            }
            catch (WebException e)
            {
                if(e.Message.Contains("404") && requestString.Contains("instagram.com"))
                {
                    return string.Empty;
                }
                if (e.Message.Contains("429") && requestString.Contains("instagram.com"))
                {
                    throw new Exception("Превышен лимит запросов instagram - ошибка 429");
                }
                Trace.TraceError(DateTime.Now + String.Format("Ошибка метода AbstractConnection.GetData. Запрос {0}. Ответ {1}. Текст ошибки {2}",
                    requestString, responseFromServer, e.Message));
                Thread.Sleep(5000);//ждем 5 секунд восстановления сервиса
                if (count <= maxCount)
                    return GetData(requestString, count, maxCount, cookiesURI);
            }
            return responseFromServer;
        }

        /// <summary>
        /// Запрос к серверу не более maxCount раз
        /// </summary>
        /// <param name="requestString">строка запроса</param>
        /// <param name="count">текущее количество запросов</param>
        /// <param name="maxCount">максимальное количество запросов</param>
        /// <param name="cookiesURI">ссылка для получения cookies</param>
        /// <returns></returns>
        protected static string GetDataByProxy(string requestString, ref Proxy proxy, int count = 0, int maxCount = 3, string cookiesURI = null)
        {
            count++;
            string responseFromServer = string.Empty;
            Trace.TraceInformation(DateTime.Now + String.Format("Попытка выполнения запроса: {0}", requestString));
            try
            {
                WebProxy proxyObject = new WebProxy(proxy.host, proxy.port);
                proxyObject.Credentials = new NetworkCredential(proxy.login, proxy.password);
                proxyObject.BypassProxyOnLocal = false;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestString);
                request.Proxy = proxyObject;
                //request.Proxy.Credentials = CredentialCache.DefaultNetworkCredentials;
                //request.UseDefaultCredentials = true;

                if (!string.IsNullOrEmpty(cookiesURI))
                    setCookies(request, cookiesURI);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream dataStream = response.GetResponseStream();
                    
                    StreamReader reader = new StreamReader(dataStream, Encoding.GetEncoding("UTF-8"));
                    
                    responseFromServer = reader.ReadToEnd();
                    if(responseFromServer.Contains("meta name="))
                    {
                        proxy.is_good = false;
                    }
                    reader.Close();
                    dataStream.Close();
                    response.Close();

                    Thread.Sleep(500);
                }
            }
            catch (WebException e)
            {
                if (e.Message.Contains("404") && requestString.Contains("instagram.com"))
                {
                    return string.Empty;
                }
                if (e.Message.Contains("429") && requestString.Contains("instagram.com"))
                {
                    throw new Exception("Превышен лимит запросов instagram - ошибка 429");
                }
                if (e.ToString().Contains("System.Net.WebException"))
                {
                    proxy.is_good = false;
                }
                Trace.TraceError(DateTime.Now + String.Format("Ошибка метода AbstractConnection.GetData. Запрос {0}. Ответ {1}. Текст ошибки {2}",
                    requestString, responseFromServer, e.Message));
                //Thread.Sleep(5000);//ждем 5 секунд восстановления сервиса
                //if (count <= maxCount)
                //    return GetData(requestString, count, maxCount, cookiesURI);
               
            }
            return responseFromServer;
        }
        /// <summary>
        /// Добавить cookies к запросу
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cookiesURI"></param>
        private static void setCookies(HttpWebRequest request, string cookiesURI)
        {
            request.CookieContainer = new CookieContainer();
            string cookies = GetGlobalCookies(cookiesURI);
            var s = cookies.Split(';');

            foreach (var item in s)
            {
                var kvp = item.Split('=');
                var c = new Cookie(kvp[0].Trim(), kvp[1].Trim(), "/", cookiesURI.Replace("https://", ""));
                request.CookieContainer.Add(new Uri(cookiesURI), c);
            }
        }

        /// <summary>
        /// Получить глобальные Cookies для конкретной ссылки
        /// </summary>
        /// <param name="pchURL"></param>
        /// <param name="pchCookieName"></param>
        /// <param name="pchCookieData"></param>
        /// <param name="pcchCookieData"></param>
        /// <param name="dwFlags"></param>
        /// <param name="lpReserved"></param>
        /// <returns></returns>
        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool InternetGetCookieEx(string pchURL, string pchCookieName, StringBuilder pchCookieData, ref uint pcchCookieData, int dwFlags, IntPtr lpReserved);
        const int INTERNET_COOKIE_HTTPONLY = 0x00002000;
        public static string GetGlobalCookies(string uri)
        {
            uint datasize = 1024;
            StringBuilder cookieData = new StringBuilder((int)datasize);
            if (InternetGetCookieEx(uri, null, cookieData, ref datasize, INTERNET_COOKIE_HTTPONLY, IntPtr.Zero)
            && cookieData.Length > 0)
            {
                return cookieData.ToString();
            }
            else
            {
                return null;
            }
        }

        #region Члены IDisposable

        /// <summary>
        /// Реализация IDisposable - автоматически закрывать подключение при уничтожении
        /// </summary>
        public void Dispose()
        {
            Close();
        }

        #endregion

        /// <summary>
        /// Октрыть подключение
        /// </summary>        
        /// <param name="credential">Имя пользователя и пароль</param>        
        public virtual bool Open()
        {
            return false;
        }

        /// <summary>
        /// Событие - подключение в режиме ожидания (превышен лимит запросов)
        /// </summary>
        public EventHandler<PausedEventArgs> Paused;

        /// <summary>
        /// Вызвать событие - "Подключение в режиме ожидания"
        /// </summary>
        /// <param name="e"></param>
        protected void RaisePaused(PausedEventArgs e)
        {
            if (Paused != null)
                Paused(this, e);
        }

        /// <summary>
        /// Отправить Post-запрос к серверу
        /// </summary>
        /// <param name="requestString"></param>
        /// <param name="count"></param>
        /// <param name="maxCount"></param>
        /// <returns></returns>
        protected static string SendPostRequest(string requestString, int count = 0, int maxCount = 3)
        {
            count++;
            string responseFromServer = string.Empty;
            Trace.TraceInformation(DateTime.Now + String.Format("Попытка выполнения запроса: {0}", requestString));
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestString.Substring(0, requestString.IndexOf('?')));
                request.Proxy = HttpWebRequest.GetSystemWebProxy();
                request.Proxy.Credentials = CredentialCache.DefaultNetworkCredentials;
                request.UseDefaultCredentials = true;
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";

                string postData = requestString.Substring(requestString.IndexOf('?') + 1);
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                request.ContentLength = byteArray.Length;

                Stream dataStream = request.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream dataStream1 = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream1, Encoding.GetEncoding("UTF-8"));
                    responseFromServer = reader.ReadToEnd();
                    reader.Close();
                    dataStream1.Close();
                    response.Close();
                }
            }
            catch (WebException e)
            {
                if (e.Message.Contains("429") && requestString.Contains("instagram.com"))
                {
                    throw new Exception("Превышен лимит запросов instagram - ошибка 429");
                }
                Trace.TraceError(DateTime.Now + String.Format("Ошибка метода AbstractMapper.GetData. Запрос {0}. Ответ {1}. Текст ошибки {2}",
                    requestString, responseFromServer, e.Message));
                Thread.Sleep(5000);//ждем 5 секунд восстановления сервиса
                if (count <= maxCount)
                    return GetData(requestString, count, maxCount);
            }
            return responseFromServer;
        }

        /// <summary>
        /// Отправить пост-запрос к серверу
        /// </summary>
        /// <param name="requestString"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected static async System.Threading.Tasks.Task<string> SendPostRequest(string requestString, Dictionary<string, string> parameters)
        {
            HttpClient client = new HttpClient();
            var values = new Dictionary<string, string>();
            var content = new FormUrlEncodedContent(parameters);
            var response = await client.PostAsync(requestString, content);
           var  responseString = await response.Content.ReadAsStringAsync();
            return responseString;
        }
    }
}
