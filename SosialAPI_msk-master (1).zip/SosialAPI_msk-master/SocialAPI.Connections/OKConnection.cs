﻿using Newtonsoft.Json;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks.OK;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Класс подключения к веб-сервису Одноклассники
    /// </summary>
    public class OKConnection : AbstractConnection
    {
        /// <summary>
        /// идентификатор приложения
        /// </summary>
        public static string ApplicationID = "1254372864";

        /// <summary>
        /// открытый ключ приложения
        /// </summary>
        public static string PublicKey = "CBAHDFMLEBABABABA";

        /// <summary>
        /// закрытый ключ приложения
        /// </summary>
        public static string PrivateKey = "3D5D70A48E960B7913BFB8BE";

        /// <summary>
        /// Октрыть подключение
        /// </summary>          
        public override bool Open()
        {
            return true;
        }

        /// <summary>
        /// Получить текущего (авторизовавшегося) пользователя
        /// </summary>
        /// <returns></returns>
        public static UserOK GetCurrentOKUser(AccountManagerOK currentAccount)
        {
            UserOK res = null;
            try
            {
                string fields = "uid,age,first_name,last_name,pic_full,birthday,locale,gender,location,url_profile,current_status,current_status_date,last_online,registered_date";
                string s = String.Format("application_key={0}fields={2}format=jsonmethod=users.getCurrentUser{1}",
                                    PublicKey, currentAccount.session_secret_key, fields);
                string MD5Hash = GetMD5Hash(s);
                string StringGET = String.Format("https://api.ok.ru/fb.do?application_key={0}&fields={3}&format=json&method=users.getCurrentUser&sig={1}&access_token={2}", PublicKey, MD5Hash, currentAccount.token, fields.Replace(",", "%2C"));
                string response = GetData(StringGET);
                ErrorRootObject error = JsonConvert.DeserializeObject<ErrorRootObject>(response);
                res = JsonConvert.DeserializeObject<UserOK>(response);
                if (error != null && (res != null && res.uid == null))
                {
                    res = null;
                    throw new Exception(String.Format("Код ошибки API: {0}", HelperErrorCodeOK.GetError(error.error_code)));
                }

            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка OKConnection.GetCurrentUser. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }

        /// <summary>
        /// Возвращает список идентификаторов друзей
        /// </summary>
        /// <param name="uid">Идентификатор пользователя для которого возвращается список идентификаторов его друзей</param>
        /// <returns></returns>
        public static List<string> GetFriendsID(long uid, AccountManagerOK currentAccount)
        {
            List<string> res = new List<string>();
            try
            {
                string s = String.Format("application_key={0}fid={2}format=jsonmethod=friends.get{1}",
                                    PublicKey, currentAccount.session_secret_key, uid);
                string MD5Hash = GetMD5Hash(s);
                string StringGET = String.Format("https://api.ok.ru/fb.do?application_key={0}&fid={3}&format=json&method=friends.get&sig={1}&access_token={2}", PublicKey, MD5Hash, currentAccount.token, uid);
                string response = GetData(StringGET);
                if (!CheckError(response))
                    res = JsonConvert.DeserializeObject<string[]>(response).ToList();
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка OKConnection.GetCurrentUser. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }
        /// <summary>
        /// Проверяет ответ сервера на наличие ошибки
        /// </summary>
        /// <param name="response"></param>
        private static bool CheckError(string response)
        {
            ErrorRootObject error = null;
            try
            {
                error = JsonConvert.DeserializeObject<ErrorRootObject>(response);
                if (error != null && error.error_code > 0)
                {
                    Trace.TraceError(DateTime.Now + String.Format("Ошибка OKConnection.GetCurrentUser. Текст ошибки {0}",
                        String.Format("Код ошибки API: {0}", HelperErrorCodeOK.GetError(error.error_code))));
                    return true;
                }
            }
            catch { }

            return false;
        }



        /// <summary>
        /// Возвращает список  пользлователй по строке uidList содержащей uids пользователей через запятую (не более 100)
        /// </summary>
        /// <param name="uidList"></param>
        /// <param name="currentAccount"></param>
        /// <returns></returns>
        public static List<UserOK> getOKUsers(string uidList, AccountManagerOK currentAccount)
        {
            List<UserOK> res = new List<UserOK>();
            try
            {
                string fields = "uid,age,first_name,last_name,pic_full,birthday,locale,gender,location,url_profile,current_status,current_status_date,last_online,registered_date";
                string s = String.Format("application_key={0}fields={1}format=jsonmethod=users.getInfouids={2}{3}",
                    PublicKey, fields, uidList, currentAccount.session_secret_key);
                string MD5Hash = GetMD5Hash(s);
                string StringGET = String.Format("https://api.ok.ru/fb.do?application_key={0}&fields={1}&format=json&method=users.getInfo&uids={2}&sig={3}&access_token={4}", PublicKey, fields.Replace(",", "%2C"), uidList, MD5Hash, currentAccount.token);
                string response = GetData(StringGET);
                if (!CheckError(response))
                    res = JsonConvert.DeserializeObject<UserOK[]>(response).ToList();
            }
            catch (Exception ex)
            {
                Trace.TraceError(DateTime.Now + String.Format("Ошибка OKConnection.GetCurrentUser. Текст ошибки {0}", ex.ToString()));
            }
            return res;
        }

        /// <summary>
        /// Возвращает всех друзей для указанного uid
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="currentAccount"></param>
        /// <returns></returns>
        public static List<UserOK> getOKFriends(long uid, AccountManagerOK currentAccount)
        {
            List<string> idList = GetFriendsID(uid, currentAccount);
            List<UserOK> result = new List<UserOK>();
            string stringUid = String.Empty;
            int count = 0;
            foreach (string sss in idList)
            {
                if (count == 0)
                {
                    stringUid = sss;
                    count = 1;
                    continue;
                }
                stringUid = $"{stringUid},{sss}";
                count++;
                if (count == 99)
                {
                    result.AddRange(getOKUsers(stringUid, currentAccount));
                    count = 0;
                }
            }
            if (count > 0)
            {
                result.AddRange(getOKUsers(stringUid, currentAccount));
            }
            return result;
        }

        /// <summary>
        /// Рассчет MD5
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private static string GetMD5Hash(string input)
        {
            var x = new System.Security.Cryptography.MD5CryptoServiceProvider();
            var bs = Encoding.UTF8.GetBytes(input);
            bs = x.ComputeHash(bs);
            var s = new StringBuilder();
            foreach (var b in bs)
            {
                s.Append(b.ToString("x2").ToLower());
            }
            return s.ToString();
        }



        /// <summary>
        /// Класс для десериализации ответа по пользователю В ОК
        /// </summary>
        public class RootObjectUserOK
        {
            public UserOK response { get; set; }
        }

        /// <summary>
        /// Класс для сериализации ответа - Ошибка
        /// </summary>
        public class ErrorRootObject
        {
            public int error_code { get; set; }
            public string error_msg { get; set; }
            public object error_data { get; set; }
        }
    }
}
