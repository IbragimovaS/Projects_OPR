﻿using Newtonsoft.Json;
using SocialAPI.Models.MsSQL;
using SocialAPI.Models.MsSQL.AccountManager;
using SocialAPI.Models.SocialNetworks.OK;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;

namespace SocialAPI.Connections
{
    /// <summary>
    /// Класс подключения к прокси
    /// </summary>
    public class ProxyConnection : AbstractConnection
    {

        /// <summary>
        /// Октрыть подключение
        /// </summary>          
        public override bool Open()
        {
            return true;
        }

        /// <summary>
        /// Проверить работоспособность прокси сервера
        /// </summary>
        /// <returns></returns>
        public static bool TestingConnection(Proxy proxy)
        {
            var url = @"https://www.instagram.com/";
            bool result = false;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                WebProxy myproxy = new WebProxy(proxy.host, proxy.port);
                myproxy.Credentials = new NetworkCredential(proxy.login, proxy.password);

                myproxy.BypassProxyOnLocal = false;
                request.Proxy = myproxy;

                request.Method = "GET";
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                    result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }
    }
}
