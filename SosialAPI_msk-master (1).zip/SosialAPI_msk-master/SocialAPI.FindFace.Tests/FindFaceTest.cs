using Microsoft.AspNetCore.Mvc.Testing;
using SocialAPI;
using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xunit;

namespace Tests
{
    public class FindFaceTest : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly WebApplicationFactory<Startup> _factory;

        public FindFaceTest(WebApplicationFactory<Startup> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task Test1()
        {

            Guid user_token = new Guid("07dd29ff-1bf8-48da-0272-08d729f8df1b");

            byte[] image = File.ReadAllBytes(@"Data\image.jpg");
            int deph = 2;
            using (var client = _factory.CreateClient())
            {
                using (var content = new MultipartFormDataContent("Upload----" + DateTime.Now.ToString(CultureInfo.InvariantCulture)))
                {
                    content.Add(new StreamContent(new MemoryStream(image)), "bilddatei", "upload.jpg");


                    using (var message = await client.PostAsync(String.Format(@"/api/findface/postfindface?user_token={0}&deph={1}", user_token, deph), content))
                    {
                        var input = await message.Content.ReadAsStringAsync();
                    }
                }
            }
        }
    }
}