# CameraFrameExtractor
To extract camera frames continuously and display the camera preview onto the screen.
If you want to show camera continuously on the screen to your user.
And continuously get the frames from the camera in order to process it and show results according to your need.
Kindly, see this repo , the code is written in swift 4.2.
You will definitely get the optimized solution of your problem related to this.
With this, you can also show the camera preview properly into your view.
Do use your iphone or ipad to test this app. It will surely not work in the simulator of Xcode.
