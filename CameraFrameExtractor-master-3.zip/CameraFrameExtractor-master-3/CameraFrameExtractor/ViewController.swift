//
//  ViewController.swift
//  CameraFrameExtractor
//
//  Created by Anand Nigam on 11/10/18.
//  Copyright © 2018 Anand Nigam. All rights reserved.
//

import UIKit
import AVFoundation

typealias Parameters = [String: String]

protocol FrameExtractorDelegate: class {
    func captured(image: UIImage)
}
class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {

    
        
         @IBOutlet weak var cameraPreview: UIView!
         var StatusCodeRes = Int()
         let gradient = CAGradientLayer()
         var gradientSet = [[CGColor]]()
         var currentGradient: Int = 0
       
        var AIView2 = UIActivityIndicatorView(style: .whiteLarge)
        var label1 = UILabel()
        var label2 = UILabel()
         
         var imageView = UIImageView()
        var tlabel = UILabel()
         
        var NameJson = String()
         var videoDataOutput: AVCaptureVideoDataOutput!
         var videoDataOutputQueue: DispatchQueue!
         var previewLayer:AVCaptureVideoPreviewLayer!
         var captureDevice : AVCaptureDevice!
         let session = AVCaptureSession()
         let context = CIContext()
 
         var Nimage = 0
         weak var delegate: FrameExtractorDelegate?
         
         var timer = Timer()
         override func viewDidLoad() {
             super.viewDidLoad()
            let viewGR = UIView()
            viewGR.frame = CGRect(x:0 , y: 20, width: 770, height: 50)
            view.addSubview(viewGR)
             let gradient = CAGradientLayer()
             gradient.frame = viewGR.bounds
             gradient.startPoint = CGPoint(x:0.0, y:0.5)
             gradient.endPoint = CGPoint(x:1.0, y:0.5)
             gradient.colors = [UIColor.red.cgColor, /*UIColor.green.cgColor,*/ UIColor.blue.cgColor]
             gradient.locations =  [-0.5, 1.5]

           let animation = CABasicAnimation(keyPath: "colors")
           animation.fromValue = [UIColor.red.cgColor, /*UIColor.green.cgColor,*/ UIColor.green.cgColor]
           animation.toValue = [UIColor.blue.cgColor, /*UIColor.red.cgColor,*/ UIColor.red.cgColor]
           animation.duration = 3.0
           animation.autoreverses = true
           animation.repeatCount = Float.infinity

           // add the animation to the gradient
           gradient.add(animation, forKey: nil)

           // add the gradient to the view
           viewGR.layer.addSublayer(gradient)



            
            let label1 = UILabel()
            label1.frame = CGRect(x: 20, y: 200, width: 250, height: 100)
            label1.text = "Ожидайте"
            label1.font = UIFont(name: label1.font.fontName, size: 30)
            label1.textColor = .white
            label1.textAlignment = .left
            label1.backgroundColor = .black
            view.addSubview(label1)
            
            
            
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.label), userInfo: nil, repeats: true)
            
            
            
             // Do any additional setup after loading the view, typically from a nib.
            // imageView.transform = imageView.transform.rotated(by: CGFloat(M_PI_2));
             view.addSubview(cameraPreview)
             //imageView.image = cameraPreview
             self.setUpAVCapture()
             view3(n: 0)
            
            let AIView = UIActivityIndicatorView(style: .whiteLarge)
            AIView.frame = CGRect(x: 569, y: 551, width: 20, height: 20)
            AIView.translatesAutoresizingMaskIntoConstraints = false
            AIView.startAnimating()
            
            view.addSubview(AIView)
         }
         
    @objc func label(){
        
        label1.frame = CGRect(x: 20, y: 70, width: 200, height: 100)
        label1.text = ""+Date().dayOfWeek()!+"\n"+(DateFormatter.localizedString(from: Date(), dateStyle:.short, timeStyle: .none))
        
        label1.textColor = .gray
        label1.numberOfLines = 2
        label1.textAlignment = .left
        label1.backgroundColor = .black
        label1.font = UIFont(name: label1.font.fontName, size: 25)
        view.addSubview(label1)
        
        
        label2.frame = CGRect(x: 600, y: 70, width: 150, height: 100)
        label2.text = DateFormatter.localizedString(from: Date(), dateStyle:.none, timeStyle: .short)
        label2.textColor = .gray
        label2.textAlignment = .right
        label2.backgroundColor = .black
        label2.font = UIFont(name: label2.font.fontName, size: 50)
        view.addSubview(label2)
    }
    
    
    func view3(n:Int){
        let view3ui = UIView()
        view3ui.frame = CGRect(x: 60, y: 870, width: 650, height: 140)
        view3ui.layer.borderWidth = 1.0
        view3ui.layer.borderColor = UIColor.darkGray.cgColor
        view3ui.backgroundColor = .black
        view3ui.layer.cornerRadius = view3ui.frame.size.height/2
        view.addSubview(view3ui)
       // if n == 0 {
            //ActivityIndicatorView(view1234: view3ui)
       // }
       
    }
    func ActivityIndicatorView(view1234:UIView){
        
        let AIView = UIActivityIndicatorView(style: .whiteLarge)
        AIView.frame = CGRect(x: 315, y: 60, width: 20, height: 20)
        AIView.translatesAutoresizingMaskIntoConstraints = false
        AIView.startAnimating()
        
        view1234.addSubview(AIView)
       
    }
         
        
         override func viewWillDisappear(_ animated: Bool) {
             super.viewWillDisappear(animated)
             stopCamera()
         }

         // To add the layer of your preview
         override func viewDidLayoutSubviews() {
             super.viewDidLayoutSubviews()
             self.previewLayer.frame = self.cameraPreview.layer.bounds
         }
         
         // To set the camera and its position to capture
         func setUpAVCapture() {
            session.sessionPreset = AVCaptureSession.Preset.iFrame960x540//hd1920x1080 //vga640x480
             guard let device = AVCaptureDevice
                 .default(AVCaptureDevice.DeviceType.builtInWideAngleCamera,
                          for: .video,
                          position: AVCaptureDevice.Position.front) else {
                             return
             }
             captureDevice = device
             beginSession()
         }
         
         // Function to setup the beginning of the capture session
         func beginSession(){
             var deviceInput: AVCaptureDeviceInput!
             
             do {
                 deviceInput = try AVCaptureDeviceInput(device: captureDevice)
                 guard deviceInput != nil else {
                     print("error: cant get deviceInput")
                     return
                 }
                 
                 if self.session.canAddInput(deviceInput){
                     self.session.addInput(deviceInput)
                 }
                 
                 videoDataOutput = AVCaptureVideoDataOutput()
                 videoDataOutput.alwaysDiscardsLateVideoFrames=true
                 videoDataOutputQueue = DispatchQueue(label: "VideoDataOutputQueue")
                 videoDataOutput.setSampleBufferDelegate(self, queue:self.videoDataOutputQueue)
                 
                 if session.canAddOutput(self.videoDataOutput){
                     session.addOutput(self.videoDataOutput)
                 }
                 
                 videoDataOutput.connection(with: .video)?.isEnabled = true
                 
                 previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
                 previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
                 
                 let rootLayer :CALayer = self.cameraPreview.layer
                 rootLayer.masksToBounds = true
                 
                 rootLayer.addSublayer(self.previewLayer)
                 session.startRunning()
             } catch let error as NSError {
                 deviceInput = nil
                 print("error: \(error.localizedDescription)")
             }
         }
         
         // Function to capture the frames again and again
         func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
             // do stuff here
            // print("Got a frame")
             
             guard let uiImage = imageFromSampleBuffer(sampleBuffer: sampleBuffer) else { return };
             
                 DispatchQueue.main.async { [unowned self] in
                 guard self.imageFromSampleBuffer(sampleBuffer: sampleBuffer) != nil else { return }
                     self.delegate?.captured(image: uiImage)
                  
                    let rotateImage = uiImage.rotate(radians: .pi/2)
                    self.submit(image: rotateImage)
                    
                        //self.view1(n: 1)
                   
                
                     
             }
             usleep(1000000)
             
         }
         
         // Function to process the buffer and return UIImage to be used
         func imageFromSampleBuffer(sampleBuffer : CMSampleBuffer) -> UIImage? {
             guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return nil }
             
             let ciImage = CIImage(cvPixelBuffer: imageBuffer)
             
             guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return nil }
             
             return UIImage(cgImage: cgImage)
             
         }
         
         // To stop the session
         func stopCamera(){
             session.stopRunning()
         }
    
       func submit(image: UIImage) {
            print("POST")
             guard let mediaImage = Media(withImage: image, forKey: "file") else { return }
             guard let url = URL(string: "http://10.150.34.13:9001/get_red_people/") else { return }
             // http://10.180.13.89:9999/get_tengri_people/
             var request = URLRequest(url: url)
             request.httpMethod = "POST"
             
             let boundary = generateBoundary()
             
             request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
             let dataBody = createDataBody(withParameters: nil, media: [mediaImage], boundary: boundary)
             request.httpBody = dataBody
             
             let session = URLSession.shared
             session.dataTask(with: request) { (data, response, error) in
                if (response != nil) {
                    //print(response )
                     print("*****************************")
                 }
                 
                 if let data = data {
                     do {
                         let json = try JSONSerialization.jsonObject(with: data, options:JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                         print("Json",json)
                        
                        let asd = Array(json.allKeys)
                        print("ASD = ",asd[0])
                       
                        var arrn = [Any]()
                        if let dd = json["person"] as? NSArray{
                            print("COUNT = ",dd.count)
                            for qwe in (dd as Array){
                                arrn.append(qwe["fio"] as! String)
                                print(qwe["fio"] as! String)
                                self.NameJson = arrn[0] as! String
                                print(arrn[0])
                                 
                            }
                            
                            
                            if dd.count > 0{
                                print("11111111")
                                
                                DispatchQueue.main.async {
                                     self.getrec()
                                 }
                            }
                   
                            else {
                               print("NO GET")
                                DispatchQueue.main.async {
                                    self.imageView.image = nil
                                    self.view.addSubview(self.imageView)
                                     
                                    self.tlabel.text = ""
                                    self.tlabel.backgroundColor = .black
                                    self.view.addSubview(self.tlabel)
                                    
                                    self.AIView2.frame = CGRect(x: 375, y: 930, width: 20, height: 20)
                                    self.AIView2.translatesAutoresizingMaskIntoConstraints = false
                                    self.AIView2.startAnimating()
                                    self.view.addSubview(self.AIView2)
                                    
                                }
                                
                            }
                   
                      }
                    
                     }catch{
                         print("Error",error)
                     }
                 }
                 }.resume()
         }
        
     
     
         func generateBoundary() -> String {
             return "Boundary-\(NSUUID().uuidString)"
         }
         
         func createDataBody(withParameters params: Parameters?, media: [Media]?, boundary: String) -> Data {
             
             let lineBreak = "\r\n"
             var body = Data()
             
             if let media = media {
                 for photo in media {
                     body.append("--\(boundary + lineBreak)")
                     body.append("Content-Disposition: form-data; name=\"\(photo.key)\"; filename=\"\(photo.filename)\"\(lineBreak)")
                     body.append("Content-Type: \(photo.mimeType + lineBreak + lineBreak)")
                     body.append(photo.data)
                     body.append(lineBreak)
                 }
             }
             
             body.append("--\(boundary)--\(lineBreak)")
             
             return body
         }
    


    
    
    
    
    
     
    func getrec(){
     let session = URLSession(configuration: URLSessionConfiguration.default)
     guard let url = URL(string:"http://10.150.34.13:9001/get_photo_redbase/?data="+"\(0)") else { return }
        //http://10.180.13.89:9999/get_photo_crop/?data=
        var request = URLRequest(url: url)
     request.httpMethod = "GET"
     session.dataTask(with: request) { (data, response, error) in
         
         if let response = response {
             print(response)
            if let http = response as? HTTPURLResponse{
                print("123123123123 = ",http.statusCode)
                self.StatusCodeRes = http.statusCode
            }
           
            }
            

        if let data = data {
            
            
            if self.StatusCodeRes == 200{
            // self.imagearr1.append(UIImage(data: data)!)
            print("GETREC")
            DispatchQueue.main.async {
             
            //let imageview3 = UIImageView()
                print(data)
                
                    print("IMGAEVIEW1")
                
                self.imageView.image = (UIImage(data: data)!).flipHorizontally()
                self.imageView.contentMode = .scaleToFill
                self.imageView.frame = CGRect(x: 408, y: 279, width: 342, height: 564)
                //self.imageView.layer.cornerRadius = self.imageView.frame.size.width/2
                self.imageView.layer.masksToBounds = true
                self.imageView.imageWithFade = self.imageView.image
                self.view.addSubview(self.imageView)
                    
                self.tlabel.frame = CGRect(x: 200, y: 872, width: 400, height: 136)
               // self.tlabel.text = "добро пожаловать, \n"+self.NameJson
                self.tlabel.text = "Qosh keldіńіz, qurmettі \n"+self.NameJson //Қош келдіңіз, құрметті
                self.tlabel.lineBreakMode = .byWordWrapping
                self.tlabel.numberOfLines = 2
                self.tlabel.textColor = .white
                self.tlabel.textAlignment = .center
                self.tlabel.backgroundColor = .black
                self.tlabel.font = UIFont(name: self.tlabel.font.fontName, size: 20)
                self.view.addSubview(self.tlabel)
                
            }
            
        }
        }
    }.resume()
    

    
    }
    
    

}
extension UIImage {
    func flipHorizontally() -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(self.size, true, self.scale)
        let context = UIGraphicsGetCurrentContext()!

        context.translateBy(x: self.size.width/2, y: self.size.height/2)
        context.scaleBy(x: -1.0, y: 1.0)
        context.translateBy(x: -self.size.width/2, y: -self.size.height/2)

        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))

        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage
    }
}

extension Data {
    mutating func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}
  
     extension UIImage {
         func rotate(radians: CGFloat) -> UIImage {
             let rotatedSize = CGRect(origin: .zero, size: size)
                 .applying(CGAffineTransform(rotationAngle: CGFloat(radians)))
                 .integral.size
             UIGraphicsBeginImageContext(rotatedSize)
             if let context = UIGraphicsGetCurrentContext() {
                let origin = CGPoint(x: rotatedSize.width / 2.0,
                                      y: rotatedSize.height / 2.0)
                 context.translateBy(x: origin.x, y: origin.y)
                 context.rotate(by: radians)
                 draw(in: CGRect(x: -origin.y, y: -origin.x,
                                 width: size.width, height: size.height))
                 let rotatedImage = UIGraphicsGetImageFromCurrentImageContext()
                 UIGraphicsEndImageContext()

                 return rotatedImage ?? self
             }

             return self
         }
     }
extension UIImageView{
    var imageWithFade:UIImage?{
        get {
            return self.image
        }
        set{
            UIView.transition(with: self, duration: 0.7, options: .transitionCrossDissolve, animations: {self.image = newValue}, completion: nil)
        }
    }
}
extension Date{
    func dayOfWeek() -> String?{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: self).capitalized
    }
    
}
