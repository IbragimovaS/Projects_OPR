//
//  Media.swift
//  CameraFrameExtractor
//
//  Created by Sholpan Ibragimova on 12/15/19.
//  Copyright © 2019 Anand Nigam. All rights reserved.
//
import UIKit

struct Media {
    let key: String
    let filename: String
    let data: Data
    let mimeType: String
    
    init?(withImage image1: UIImage, forKey key: String) {
        self.key = key
        self.mimeType = "application/octet-stream"
        self.filename = "kyleleeheadiconimage234567.jpg"
        
        guard let data = image1.jpegData(compressionQuality:0.7) else { return nil }
        self.data = data
    }
    
}
