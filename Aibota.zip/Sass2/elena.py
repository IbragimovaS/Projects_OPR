import requests
import json
import cv2
import datetime

def upload_file(screen):
    try:
        url = "http://10.150.34.14:9000/get_red_people/"
        files = {'file': open(screen,'rb')}
        response = requests.post(url, files=files)
 #       print(response.text)
        newjson=json.loads(response.text)
        len_js =len(newjson["person"])
        if(len_js!=0):
            for i in range(len_js):
                name=newjson["person"][i]["fio"]
                print(name)
    except:
        a=0

def cap_online():
    cap = cv2.VideoCapture(0)
    framecounter = 0
    screen = 'screen.jpg'
    while(cap.isOpened()):
        framecounter += 1

        ret, frame = cap.read()
        frames = cv2.resize(frame, (950, 540))
        cv2.imshow('frame', frames)
        if framecounter%10==0:
            cv2.imwrite(screen,frame)
            upload_file(screen)
        if cv2.waitKey(50) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()