import cv2
import datetime

#cap = cv2.VideoCapture(0)
cap = cv2.VideoCapture('rtsp://admin:qwerty123456@10.180.13.28:554/Streaming/Channels/101')
framecounter = 0
while (cap.isOpened()):
    framecounter += 1
    if (framecounter % 10 == 0):
        ret, frame = cap.read()
        frames = cv2.resize(frame, (950, 540))
        cv2.imshow('frame', frames)


cap.release()

cv2.destroyAllWindows()