import PyQt5
from PyQt5 import QtCore, QtGui
from PyQt5.QtWidgets import QLabel, QApplication, QMainWindow, QSizePolicy
from PyQt5.QtWebEngineWidgets import *
import subprocess, re, os, bs4, requests, sys
import threading
import speech_recognition as sr
import signal
import pyttsx3
import apiai, json
import myfunc
import time
import wikipediaapi

#
# bot_name = {
#     "name": ('Бота', 'iboto', 'ibota', 'Айбота', 'ибота', 'bot', 'botik', "iphoto", "акбота", "бот", "работа")
# }
# конвертация библиотеки для текст-ту-спич
engine = pyttsx3.init()
# Голос для ассистента
voices = engine.getProperty('voices')
# Устанавливаем русский язык
engine.setProperty('voice', 'ru')

# Ищем голос Elena от RHVoice
# Тут есть еще но самый норм елена
# https://github.com/Olga-Yakovleva/RHVoice/wiki/Latest-version-%28Russian%29
for voice in voices:
    if voice.name == 'Elena':
        engine.setProperty('voice', voice.id)
# Скорость чтения
engine.setProperty('rate', 120)
# html шаблон для чата работает с QtWebEngineWidgets(я так понял он создает отдельные вебстранички для чата и картинки. P.S надо потом еще почитать про это
htmlcode = '<div class="robot">Чем я могу помочь?</div>'

f = open('index.html', 'r', encoding='UTF-8')
htmltemplate = f.read()
f.close()
# Открываем help html (Там сделаю список того что можеть бот + 2 экран где будет происходить все действие)
f = open('help.html', 'r', encoding='UTF-8')
htmlcode2 = f.read()
f.close()


# Функция, которая обращается к Dialogflow и получает ответ
def AiMessage(s):
    # Токен API к Dialogflow (надо натренить ее)


    request = apiai.ApiAI('25d1da9a276046a1aca9da670d3dd27b').text_request()
    # request = apiai.ApiAI('c74693bbf28a49d49c506ca147c066a8  ').text_request()
    # На каком языке будет послан запрос
    request.lang = 'ru'
    # ID Сессии диалога (нужно, чтобы потом учить бота)
    request.session_id = '3301megabot'
    # Посылаем запрос к ИИ с сообщением от юзера
    request.query = s
    responseJson = json.loads(request.getresponse().read().decode('utf-8'))
    # Разбираем JSON и вытаскиваем ответ
    response = ''
    response = responseJson['result']['fulfillment']['speech']
    # Если есть ответ от бота - выдаём его,
    # если нет - бот его не понял
    if response:
        return response
    else:
        return 'Я Вас не совсем поняла!'


otvet = ''
listen = ''
vopros = ''
dontlisten = ''
ispeak = ''

# Объявляем распознавалку речи от Google
r = sr.Recognizer()


# Отдельный поток (хз кака еще проще сделать)!
def thread(my_func):
    def wrapper(*args, **kwargs):
        my_thread = threading.Thread(target=my_func, args=args, kwargs=kwargs)
        my_thread.start()

    return wrapper


# Функции для сигналов между потоками
def signal_handler(signal, frame):
    global interrupted
    interrupted = True


def interrupt_callback():
    global interrupted
    return interrupted




# Функция активизирует Google Speech Recognition для распознавания команд(нашел в гугле надо потом изменить есть пару багов)
@thread
def listencommand():
    global listen
    global vopros
    global dontlisten
    # Следим за состоянием ассистента - слушает она или говорит
    listen.emit([1])
    # Слушаем микрофон
    with sr.Microphone() as source:
        # r.adjust_for_ambient_noise(source, duration=1)
        audio = r.listen(source)

    try:
        # Отправляем запись с микрофона гуглу, получаем распознанную фразу

        f = r.recognize_google(audio, language="ru-RU").lower()
        print("google rec: " + f)
        # Меняем состояние ассистента со слушания на ответ
        listen.emit([2])
        # Отправляем распознанную фразу на обработку в функцию myvopros
        vopros.emit([f])
    # В случае ошибки меняем состояние ассистента на "не расслышал"

    except sr.UnknownValueError:
        print("Робот не расслышал фразу")
        listen.emit([1])
        dontlisten.emit(['00'])

    except sr.RequestError as e:
        print("Ошибка сервиса; {0}".format(e))
        listen.emit([1])


signal.signal(signal.SIGINT, signal_handler)


# def main_method(self):
#     with sr.Microphone() as source:
#         audio = r.listen(source)
#         f = r.recognize_google(audio, language="ru-RU").lower()
#         print("google rec: " + f)
#
#         if f.startswith(bot_name("name")):
#             ot = "К вашим услугам!"
#             self.addyouphrasetohtml(ot)
#             self.speakphrase(ot)
#             b = 1
#         else:
#             b = 0
#     return b


# Графический интерфейс PyQt
class W(QMainWindow):
    # Объявляем сигналы, которые приходят от асинхронных функций
    my_signal = QtCore.pyqtSignal(list, name='my_signal')
    my_listen = QtCore.pyqtSignal(list, name='my_listen')
    my_vopros = QtCore.pyqtSignal(list, name='my_vopros')
    my_dontlisten = QtCore.pyqtSignal(list, name='my_dontlisten')

    def __init__(self, *args):
        super().__init__()
        self.setAnimated(False)
        self.flag = True
        self.centralwidget = QMainWindow()


        self.centralwidget.setObjectName("centralwidget")
        self.setCentralWidget(self.centralwidget)
        # self.setWindowIcon(QtGui.QIcon('C:\\Users\\tengri\\Documents\\Sass2\\img\\icon.png'))
        # Label в который мы загрузим картинку с кнопкой
        self.label = QLabel(self.centralwidget)
        # Прикрепляем к Label функцию обработки клика
        self.label.installEventFilter(self)
        # Настраиваем вид курсора на картинке
        self.label.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        # Позиционируем Label внутри окна
        self.label.setGeometry(QtCore.QRect(2, 2, 500, 350))
        # Объявляем элемент QWebEngineView для отображения html странички с чатом
        self.browser = QWebEngineView(self.centralwidget)
        # Объявляем элемент QWebEngineView для отображения видео с ютуба, текстов и веб страниц
        self.browser2 = QWebEngineView(self.centralwidget)
        # Позиционируем QWebEngineView внутри окна
        self.browser.setGeometry(QtCore.QRect(2, 400, 490, 610))
        self.browser2.setGeometry(QtCore.QRect(500, 2, 1410, 1010))
        # Загружаем в QWebEngineView html документ с чатом
        global htmltemplate
        global htmlcode
        global htmlcode2
        htmlresult = htmltemplate.replace('%code%', htmlcode)
        self.browser.setHtml(htmlresult, QtCore.QUrl("file://"));
        self.browser.show()
        self.browser2.setHtml(htmlcode2, QtCore.QUrl("file://"));
        self.browser2.show()
        self.label.setText("<center><img src='file:///"+ os.getcwd() +"/img/1.jpg'></center>")
        #self.label.setText("<center>"+os.getcwd()+"text""</center>")


        #Create active button
        #self.createBtn = QtWidgets.QPushButton(self.window)
        # self.createBtn.setText("<center>"+os.getcwd()+"text""</center>")
        # self.createBtn.setGeometry(25,510,250,40)


        # Соединяем сигналы и функции класса
        global otvet
        otvet = self.my_signal
        global listen
        listen = self.my_listen
        global dontlisten
        dontlisten = self.my_dontlisten
        global vopros
        vopros = self.my_vopros

        self.my_listen.connect(self.mylisten, QtCore.Qt.QueuedConnection)
        self.my_vopros.connect(self.myvopros, QtCore.Qt.QueuedConnection)
        self.my_dontlisten.connect(self.mydontlisten, QtCore.Qt.QueuedConnection)

#Обработка клика по войсу


    # def callback(recognizer, audio):
    #     try:
    #         voice = recognizer.recognize_google(audio, language="ru-RU").lower()
    #         print("[log] Распознано: " + voice)

    #         if voice.startswith(bot_name["name"]):

    #             self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/1.jpg'></center>")



    #             for x in bot_name['name']:
    #                 cmd = cmd.replace(x, "").strip()

    #             # распознаем и выполняем команду
    #             cmd = recognize_cmd(cmd)
    #             execute_cmd(cmd['cmd'])

    #     except sr.UnknownValueError:
    #         print("[log] Голос не распознан!")
    #     except sr.RequestError as e:
    #         print("[log] Неизвестная ошибка, проверьте интернет!")

    # Обработка клика по картинке c конопкой








    def eventFilter(self, obj, e):

        if e.type() == 2:
            btn = e.button()
            if btn == 1:
                #listen начало команды и
                listencommand()
            elif btn == 2:
                # self.main_method()
                 self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/1.jpg'></center>")
        return super(QMainWindow, self).eventFilter(obj, e)

    # def callback(self,recognizer,audio):
    #     try:
    #         f = r.recognize_google(audio, language="ru-RU").lower()
    #
    #         if f.startswith(bot_name["name"]):
    #             listencommand()
    #             self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/1.jpg'></center>")
    #      return super(QMainWindow, self).eventFilter(audio)


    # # Смена картинки кнопки в зависимости от того слушает она или говорит
    def mylisten(self, data):
        if (data[0] == 1):
            self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/2.jpg'></center>")
        if (data[0] == 2):
            self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/1.jpg'></center>")


    def icon(self):
        self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/2.jpg'></center>")
        listencommand()

    # Добавление в html чат фразы ассистента
    def addrobotphrasetohtml(self, phrase):
        global htmltemplate
        global htmlcode
        htmlcode = '<div class="robot">' + phrase + '</div>' + htmlcode
        htmlresult = htmltemplate.replace('%code%', htmlcode)
        self.browser.setHtml(htmlresult, QtCore.QUrl("file://"))
        self.browser.show()

    # Добавление в html чат фразы пользователя
    def addyouphrasetohtml(self, phrase):
        global htmltemplate
        global htmlcode
        htmlcode = '<div class="you">' + phrase + '</div>' + htmlcode
        htmlresult = htmltemplate.replace('%code%', htmlcode)
        self.browser.setHtml(htmlresult, QtCore.QUrl("file://"))
        self.browser.show()

    # Произносим ответ вслух синтезом речи
    def speakphrase(self, phrase):
        global engine
        engine.say(phrase)
        engine.runAndWait()
        engine.stop()

    # Функция в которой решаем что отвечать на фразы пользователя
    def myvopros(self, data):
        global predurls
        global predcmd
        # Получаем фразу от пользователя
        vp = data[0].lower()
        # Отображаем её в чате
        self.addrobotphrasetohtml(vp)
        # Ответ по умолчанию
        ot = 'Я не расслышала'
        # Выполняем разные действия в зависимости от наличия ключевых слов фо фразе

        if (vp == 'пока' or vp == 'выход' or vp == 'выйти' or vp == 'до свидания'):
            ot = 'Ещё увидимся!'
            self.addyouphrasetohtml(ot)
            self.speakphrase(ot)
            sys.exit(app.exec_())






        # #youTube
        # elif(((vp.find("youtube")!=-1 )or (vp.find("ютюб")!=-1) or (vp.find("ютуб")!=-1))):
        #     self.browser2.load(QtCore.QUrl(myfunc.findyoutube(vp)))
        #     ot = "Вот видео которое вы искали"


        #Face Recognition
        elif ((vp.find("кто я") != -1) or (vp.find("узнай меня") != -1) or (vp.find("найди меня") != -1)):
            self.browser2.load(QtCore.QUrl(myfunc.cap_online()))
            name = myfunc.cap_online()
            if name == "Извините я вас не узнала...":
                ot = name
            elif name == "Извините я вас не узнала... Попробуйте ещё раз.":
                ot = name
            else:
                ot = " Вас зовут, " + name
                if name == "Yerbol" or name == "Zein" or name == "Yelnar":
                    self.addyouphrasetohtml(ot)
                    # Читаем ответ вслух
                    self.speakphrase(ot)
                    ot = "Я вас нашла в инстаграмме."
                    if name == "Yerbol":
                        self.browser2.load(QtCore.QUrl("https://www.instagram.com/ushkempir08/"))
                    if name == "Yelnar":
                        self.browser2.load(QtCore.QUrl("https://www.instagram.com/yelnar__/"))
                    if name == "Zein":
                        self.browser2.load(QtCore.QUrl("https://www.instagram.com/i_am_z888_kz/"))
                    if name == "Kaysar":
                        self.browser2.load(QtCore.QUrl("https://vk.com/id282782058"))


        #Википедия
        elif (vp.find("википедия") != -1):
            print(vp)
            self.browser2.load(QtCore.QUrl(myfunc.wik(vp)))
            ot = myfunc.wik(vp)

        else:
            # Если ключевых слов не нашли, используем Dialogflow!
            ot = AiMessage(vp)

        # Добавляем ответ в чат
        self.addyouphrasetohtml(ot)
        # Читаем ответ вслух
        self.speakphrase(ot)
        self.icon()

        # self.my_listen.connect(self.mylisten, QtCore.Qt.QueuedConnection)

    # Функция меняет картинку если ассистент тебя не расслышал
    def mydontlisten(self, data):

        # self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/3.jpg'></center>")
        # ot = "Я вас не совсем поняла, повторите ещё раз"
        # self.addyouphrasetohtml(ot)
        # # Читаем ответ вслух
        # self.speakphrase(ot)
        #time.sleep(1.5)
        self.label.setText("<center><img src='file:///" + os.getcwd() + "/img/2.jpg'></center>")
        listencommand()

#Функция для триггера




# Запускаем программу на выполнение

app = QApplication([2,1,0.5])

# app = QApplication([])
w = W()
# Размер окна
#w.resize(1350, 615)
w.showMaximized()
w.setWindowIcon(QtGui.QIcon('icon.png'))
w.setWindowTitle("Айбота")

w.show()
app.exec_()


