import requests, bs4, re, webbrowser
import os, sys, subprocess
from urllib import request
from urllib.parse import quote
import urllib.request
import html2text
import requests
import json
import cv2
import wikipediaapi



# Чистит фразу от ключевых слов
def cleanphrase(statement, spisok):
    for x in spisok:
        statement=statement.replace(x, '')
    statement=statement.strip()
    return statement

# Открыть сайт во внешнем браузере
def openurl(url):
    webbrowser.open(url)

# Запускает внешнюю команду ОС
def osrun(cmd):
    PIPE = subprocess.PIPE
    p = subprocess.Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=subprocess.STDOUT)

#Youtube
# def findyoutube(x):
#     x=cleanphrase(x, ['хочу', 'на ютубе', 'на ютюбе', 'на ютуб', 'ютюб', 'на youtube', 'на you tube', 'на youtub', 'youtube', 'ютуб', 'ютубе', 'посмотреть', 'смотреть'])
#     zz=[]
#     sq='http://www.youtube.com/results?search_query='+quote(x)
#     doc = urllib.request.urlopen(sq).read().decode('cp1251',errors='ignore')
#     match = re.findall("\?v\=(.+?)\"", doc)
#     if not(match is None):
#         for ii in match:
#             if(len(ii)<25):
#                 zz.append(ii)
#     zz2=dict(zip(zz,zz)).values()
#     zz3=[]
#     for qq in zz2: zz3.append(qq)
#     s=zz3[0]
#     s='https://www.youtube.com/watch?v='+s+'?autoplay=1'
#     return s
    
    
    
#Face Recognition
def upload_file(screen):
    name = ''
    try:
        url = "http://10.150.34.13:9003/get_red_people/"
        files = {'file': open(screen, 'rb')}
        response = requests.post(url, files=files)
        #       print(response.text)

        newjson = json.loads(response.text)
        len_js = len(newjson["person"])

        if (len_js != 0):
            for i in range(len_js):
                name = newjson["person"][0]["fio"]

        if name == '':
            name = "Извините я вас не узнала..."
        return name
    except:
        name = "Извините я вас не узнала... Попробуйте ещё раз."
        return name


def cap_online():
    cap = cv2.VideoCapture(0)
    framecounter = 0
    screen = 'screen.jpg'

    framecounter += 1

    ret, frame = cap.read()
    frames = cv2.resize(frame, (950, 540))
    #    cv2.imshow('frame', frames)

    cv2.imwrite(screen, frame)
    name = upload_file(screen)

    cap.release()
    cv2.destroyAllWindows()
    return name
#
# def mysearch(z):
#     doc = urllib.request.urlopen('http://go.mail.ru/search?fm=1&q='+quote(z)).read().decode('unicode-escape',errors='ignore')
#     sp=re.compile('title":"(.*?)orig').findall(doc)
#     mas1=[]
#     mas2=[]
#     for x in sp:
#         if((x.rfind('an.yandex')==-1) and (x.rfind('otvet.mail.ru')==-1) and (x.rfind('youtube')==-1) and(x.rfind('.jpg')==-1) and (x.rfind('.png')==-1) and (x.rfind('.gif')==-1)):
#             a=x.replace(',','')
#             a=a.replace('"','')
#             a=a.replace('<b>','')
#             a=a.replace('</b>','')
#             a=a.split('url:')
#             if(len(a)>1):
#                 z=a[0].split('}')
#                 mas1.append(z[0])
#                 z=a[1].split('}')
#                 z=z[0].split('title')
#                 mas2.append(z[0])
#     return mas2

#Wikipedia
def wik(w):
    wiki_wiki = wikipediaapi.Wikipedia('ru')
    w1 = w.replace("википедия", " ").replace(" ", " ")
    try:
        page_py = wiki_wiki.page(w1)
        text = page_py.summary
        if page_py.exists():
            list_text = []
            for i in range(0, 70):
                try:
                    list_text.append(text[i])
                except:
                    break
            for i in range(71, len(text)):
                list_text.append(text[i])
                if text[i] == ".":
                    break
            maintext = "".join(list_text)
            return maintext
            print(maintext)
        if not page_py.exists():
            print("Такой статьи не найдено")
            return "Такой статьи не найдено"
    except:
        return "Попробуйте произнести внятнее"



